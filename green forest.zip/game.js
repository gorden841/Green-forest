let phaserGame = null;
let phaserPlayer = null;

const GRID_SIZE = 50;

function initPhaserGame() {
    const config = {
        type: Phaser.AUTO,
        width: window.innerWidth,
        height: window.innerHeight,
        parent: 'game-container',
        canvas: document.getElementById('game-canvas'),
        pixelArt: true,
        physics: {
            default: 'arcade',
            arcade: {
                gravity: { y: 0 },
                debug: false
            }
        },
        scene: {
            preload: preload,
            create: create,
            update: update
        }
    };

    phaserGame = new Phaser.Game(config);
}

function preload() {
    this.load.image('player', 'assets/images/sprites/player.jpg');
    this.load.image('treeLeaf', 'assets/images/sprites/tree_canopy.jpg');
    this.load.image('treeTrunk', 'assets/images/sprites/tree_trunk.jpg');
    this.load.image('stone', 'assets/images/sprites/stone.jpg');
    this.load.image('animal', 'assets/images/sprites/animal.jpg');
    this.load.image('craftingTable', 'assets/images/sprites/crafting_table.jpg');
    this.load.image('furnace', 'assets/images/sprites/furnace.jpg');
    this.load.image('hole', 'assets/images/sprites/hole.jpg');
    this.load.image('ladder', 'assets/images/sprites/ladder.jpg');
}

function create() {
    this.physics.world.setBounds(0, 0, window.innerWidth, window.innerHeight);
    
    phaserPlayer = this.physics.add.sprite(window.innerWidth / 2, window.innerHeight / 2, 'player');
    phaserPlayer.setDisplaySize(150, 150);
    phaserPlayer.setVisible(false);
    phaserPlayer.setCollideWorldBounds(true);
    
    gameState.playerX = phaserPlayer.x;
    gameState.playerY = phaserPlayer.y;
}

function updatePlayerPosition() {
    if (phaserPlayer && gameState.playerX !== undefined) {
        phaserPlayer.setPosition(gameState.playerX, gameState.playerY);
    }
    
    const playerDiv = document.getElementById('phaser-player');
    if (playerDiv && gameState.playerX !== undefined) {
        playerDiv.style.left = gameState.playerX - 73 + 'px';
        playerDiv.style.top = gameState.playerY - 73 + 'px';
    }
}

function update() {
    if (!gameState.isRunning) return;
    
    updatePlayerPosition();
}

function getPlayerBounds() {
    const size = 28;
    const halfSize = size / 2;
    return {
        left: gameState.playerX - halfSize + 48,
        top: gameState.playerY - halfSize + 48,
        right: gameState.playerX + halfSize + 48,
        bottom: gameState.playerY + halfSize + 48,
        width: size,
        height: size
    };
}

function getElementBounds(el) {
    const rect = el.getBoundingClientRect();
    if (el.classList.contains('tree-leaf') || el.classList.contains('bush') || el.classList.contains('animal')) {
        const cx = rect.left + rect.width / 2;
        const cy = rect.top + rect.height / 2;
        const half = 25;
        return {
            left: cx - half,
            top: cy - half,
            right: cx + half,
            bottom: cy + half,
            width: 50,
            height: 50
        };
    }
    return {
        left: rect.left,
        top: rect.top,
        right: rect.right,
        bottom: rect.bottom,
        width: rect.width,
        height: rect.height
    };
}

function checkPlayerCollision() {
    if (!gameState.collisionEnabled) return null;

    const playerBounds = getPlayerBounds();

    let container;
    if (gameState.currentMap === 'surface') {
        container = document.getElementById('game-container');
    } else if (gameState.currentMap === 'underground' && gameState.currentHole && gameState.currentHole.underground) {
        container = gameState.currentHole.underground.container;
    }

    if (!container) return null;

    if (gameState.currentMap === 'surface') {
        const blocks = container.querySelectorAll('.tree-trunk, .tree-leaf, .bush, .stone, .crafting-table, .furnace, .hole');

        for (const el of blocks) {
            const blockBounds = getElementBounds(el);
            if (isOverlapping(playerBounds, blockBounds)) {
                return { el, blockBounds };
            }
        }
    } else if (gameState.currentMap === 'underground') {
        const ug = gameState.currentHole.underground;
        if (ug && ug.grid) {
            const tile = ug.tile;
            const startCol = Math.floor(playerBounds.left / tile);
            const startRow = Math.floor(playerBounds.top / tile);
            const endCol = Math.floor((playerBounds.right - 1) / tile);
            const endRow = Math.floor((playerBounds.bottom - 1) / tile);

            for (let r = startRow; r <= endRow; r++) {
                for (let c = startCol; c <= endCol; c++) {
                    if (r < 0 || r >= ug.rows || c < 0 || c >= ug.cols) continue;
                    const cell = ug.grid[r][c];
                    if (cell.type !== 'empty' && cell.type !== 'chest') {
                        const blockBounds = {
                            left: c * tile,
                            top: r * tile,
                            right: (c + 1) * tile,
                            bottom: (r + 1) * tile,
                            width: tile,
                            height: tile
                        };
                        if (isOverlapping(playerBounds, blockBounds)) {
                            return { el: null, blockBounds };
                        }
                    }
                }
            }
        }

        const domBlocks = container.querySelectorAll('.crafting-table, .furnace');
        for (const el of domBlocks) {
            const blockBounds = getElementBounds(el);
            if (isOverlapping(playerBounds, blockBounds)) {
                return { el, blockBounds };
            }
        }
    }

    return null;
}

function isOverlapping(a, b) {
    return a.left < b.right && a.right > b.left && a.top < b.bottom && a.bottom > b.top;
}

function resolveCollision() {
    const maxIterations = 10;
    let iterations = 0;
    
    while (iterations < maxIterations) {
        const collision = checkPlayerCollision();
        if (!collision) break;
        
        const { blockBounds } = collision;
        const playerBounds = getPlayerBounds();
        
        const overlapLeft = playerBounds.right - blockBounds.left;
        const overlapRight = blockBounds.right - playerBounds.left;
        const overlapTop = playerBounds.bottom - blockBounds.top;
        const overlapBottom = blockBounds.bottom - playerBounds.top;
        
        const minOverlapX = Math.min(overlapLeft, overlapRight);
        const minOverlapY = Math.min(overlapTop, overlapBottom);
        
        let newX = gameState.playerX;
        let newY = gameState.playerY;
        
        if (minOverlapX < minOverlapY) {
            if (overlapLeft < overlapRight) {
                newX = blockBounds.left - playerBounds.width / 2 - 1;
            } else {
                newX = blockBounds.right + playerBounds.width / 2 + 1;
            }
        } else {
            if (overlapTop < overlapBottom) {
                newY = blockBounds.top - playerBounds.height / 2 - 1;
            } else {
                newY = blockBounds.bottom + playerBounds.height / 2 + 1;
            }
        }
        
        const size = playerBounds.width;
        newX = Math.max(size / 2, Math.min(window.innerWidth - size / 2, newX));
        newY = Math.max(size / 2, Math.min(window.innerHeight - size / 2, newY));
        
        gameState.playerX = newX;
        gameState.playerY = newY;
        
        if (phaserPlayer) {
            phaserPlayer.setPosition(newX, newY);
        }
        
        const playerDiv = document.getElementById('phaser-player');
        if (playerDiv) {
            playerDiv.style.left = newX - 73 + 'px';
            playerDiv.style.top = newY - 73 + 'px';
        }

        iterations++;
    }
}

function movePhaserPlayer(dx, dy) {
    if (!phaserPlayer || !gameState.isRunning) return;
    
    const baseStep = 15;
    
    if (dx !== 0 && dy !== 0) {
        const inv = 1 / Math.SQRT2;
        dx *= inv;
        dy *= inv;
    }
    
    let newX = phaserPlayer.x + Math.round(dx * baseStep);
    let newY = phaserPlayer.y + Math.round(dy * baseStep);
    
    const size = 50;
    newX = Math.max(25, Math.min(window.innerWidth - 25, newX));
    newY = Math.max(25, Math.min(window.innerHeight - 25, newY));

    const currentX = phaserPlayer.x;
    const currentY = phaserPlayer.y;

    if (isBlockedAt(newX - 25, newY - 25, size, size)) {
        if (dx !== 0 && !isBlockedAt(newX - 25, currentY - 25, size, size)) {
            newY = currentY;
        } else if (dy !== 0 && !isBlockedAt(currentX - 25, newY - 25, size, size)) {
            newX = currentX;
        } else {
            phaserPlayer.setPosition(currentX, currentY);
            gameState.playerX = currentX;
            gameState.playerY = currentY;
            const playerDiv = document.getElementById('phaser-player');
            if (playerDiv) {
                playerDiv.style.left = currentX - 73 + 'px';
                playerDiv.style.top = currentY - 73 + 'px';
            }
            resolveCollision();
            return;
        }
    }
    
    phaserPlayer.setPosition(newX, newY);
    
    gameState.playerX = newX;
    gameState.playerY = newY;
    
    const playerDiv = document.getElementById('phaser-player');
    if (playerDiv) {
        playerDiv.style.left = newX - 73 + 'px';
        playerDiv.style.top = newY - 73 + 'px';
    }

    resolveCollision();
}

function movePhaserPlayerByDirection(direction) {
    let dx = 0, dy = 0;
    if (direction === 'up') dy = -1;
    if (direction === 'down') dy = 1;
    if (direction === 'left') dx = -1;
    if (direction === 'right') dx = 1;
    movePhaserPlayer(dx, dy);
}

const SPRITE = 'assets/images/sprites/';
const TILE = 'assets/images/tiles/';
const ITEM = 'assets/images/items/';
const RESOURCES = [
    { name: '破碎藤蔓', key: 'vine', color: '#8FBC8F', icon: ITEM + 'item_vine.jpg' },
    { name: '木棍', key: 'branch', color: '#A0522D', icon: ITEM + 'item_stick.jpg' },
    { name: '完整藤蔓', key: 'fullVine', color: '#2E8B57', icon: ITEM + 'item_vine.jpg' },
    { name: '石子', key: 'stone', color: '#808080', icon: SPRITE + 'stone.jpg' },
    { name: '木材', key: 'wood', color: '#A0522D', icon: ITEM + 'item_wood.jpg' },
    { name: '碎石斧', key: 'axe', color: '#D2691E', durability: 'axeDurability', max: 10, icon: ITEM + 'item_axe.jpg' },
    { name: '木镐', key: 'pickaxe', color: '#654321', durability: 'pickaxeDurability', max: 10, icon: ITEM + 'item_pickaxe.jpg' },
    { name: '树枝', key: 'twig', color: '#8B5A2B', icon: ITEM + 'item_stick.jpg' },
    { name: '木剑', key: 'woodenSword', color: '#FF8C00', durability: 'woodenSwordDurability', max: 30, icon: ITEM + 'item_sword.jpg' },
    { name: '合成台', key: 'craftingTable', color: '#654321', icon: SPRITE + 'crafting_table.jpg' },
    { name: '生肉', key: 'rawMeat', color: '#e06666', icon: ITEM + 'item_raw_meat.jpg' },
    { name: '熔炉', key: 'furnace', color: '#555555', icon: SPRITE + 'furnace.jpg' },
    { name: '熟肉', key: 'cookedMeat', color: '#b8860b', icon: ITEM + 'item_cooked_meat.jpg' },
    { name: '石块', key: 'stoneBlock', color: '#9E9E9E', icon: TILE + 'stone_block.jpg' },
    { name: '硬石矿', key: 'hardStoneOre', color: '#666666', icon: TILE + 'hard_stone_ore.jpg' },
    { name: '燃矿', key: 'fuelOre', color: '#ff8800', icon: TILE + 'fuel_ore.jpg' },
    { name: '硬石块', key: 'hardStoneBlock', color: '#555555', icon: ITEM + 'item_hard_stone_block.jpg' },
    { name: '梯子', key: 'ladder', color: '#D2B48C', icon: SPRITE + 'ladder.jpg' },
    { name: '石镐', key: 'stonePickaxe', color: '#999999', durability: 'stonePickaxeDurability', max: 30, icon: ITEM + 'item_pickaxe.jpg' },
    { name: '硬石镐', key: 'hardStonePickaxe', color: '#7f7f7f', durability: 'hardStonePickaxeDurability', max: 100, icon: ITEM + 'item_pickaxe.jpg' },
    { name: '硬石剑', key: 'hardStoneSword', color: '#b0b0b0', durability: 'hardStoneSwordDurability', max: 150, icon: ITEM + 'item_sword.jpg' },
    { name: '硬石斧', key: 'hardStoneAxe', color: '#b0662e', durability: 'hardStoneAxeDurability', max: 50, icon: ITEM + 'item_axe.jpg' },
    { name: '金币', key: 'gold', color: '#FFD700', icon: ITEM + 'item_gold.jpg' },
];

const RECIPES = [
    { id: 'axe', title: '碎石斧', category: 'global', ingredients: [{k:'stone',q:1},{k:'branch',q:1},{k:'vine',q:1}], func: 'craftAxe', desc: '无需工作台' },
    { id: 'branch', title: '木棍', category: 'global', ingredients: [{k:'twig',q:1}], func: 'craftBranch', desc: '无需工作台' },
    { id: 'vine', title: '破碎藤蔓', category: 'global', ingredients: [{k:'fullVine',q:1}], func: 'craftVine', desc: '无需工作台' },
    { id: 'table', title: '合成台', category: 'global', ingredients: [{k:'wood',q:1}], func: 'craftTable', desc: '放置合成台' },
    { id: 'woodenSword', title: '木剑', category: 'workbench', ingredients: [{k:'fullVine',q:1},{k:'twig',q:1},{k:'wood',q:1}], func: 'craftWoodenSword', desc: '需要工作台' },
    { id: 'pickaxe', title: '木镐', category: 'workbench', ingredients: [{k:'fullVine',q:1},{k:'twig',q:1},{k:'wood',q:1}], func: 'craftPickaxe', desc: '木镐耐久10' },
    { id: 'stonePickaxe', title: '石镐', category: 'workbench', ingredients: [{k:'fullVine',q:1},{k:'twig',q:1},{k:'stoneBlock',q:1}], func: 'craftStonePickaxe', desc: '耐久30，挖掘速度2.5倍' },
    { id: 'ladder', title: '梯子', category: 'workbench', ingredients: [{k:'branch',q:7}], func: 'craftLadder', desc: '需要合成台' },
    { id: 'furnace', title: '熔炉', category: 'workbench', ingredients: [{k:'stone',q:10}], func: 'craftFurnace', desc: '需要合成台' },
    { id: 'stonePickaxe_hard', title: '硬石镐', category: 'workbench', ingredients: [{k:'hardStoneBlock',q:3},{k:'twig',q:1},{k:'fullVine',q:1}], func: 'craftHardStonePickaxe', desc: '耐久100，需合成台' },
    { id: 'hardStoneSword', title: '硬石剑', category: 'workbench', ingredients: [{k:'hardStoneBlock',q:2},{k:'twig',q:1},{k:'fullVine',q:1}], func: 'craftHardStoneSword', desc: '强力武器' },
    { id: 'hardStoneAxe', title: '硬石斧', category: 'workbench', ingredients: [{k:'hardStoneBlock',q:2},{k:'branch',q:1}], func: 'craftHardStoneAxe', desc: '耐久强，砍树更快' },
    { id: 'smeltMeat', title: '熟肉', category: 'furnace', ingredients: [{k:'rawMeat',q:1}], func: 'smeltCookedMeat', desc: '需要靠近熔炉并消耗燃料' },
    { id: 'smeltHard', title: '烧制硬石块', category: 'furnace', ingredients: [{k:'hardStoneOre',q:1}], func: 'smeltHardStone', desc: '需要靠近熔炉并消耗燃料' }
];

const gameState = {
    resources: {},
    axeDurability: 0,
    pickaxeDurability: 0,
    woodenSwordDurability: 0,
    stonePickaxeDurability: 0,
    hardStonePickaxeDurability: 0,
    hardStoneSwordDurability: 0,
    hardStoneAxeDurability: 0,
    controlMode: 'keyboard',
    isRunning: false,
    health: 20,
    craftingPage: 1,
    refreshCooldown: false,
    attack: 1,
    furnaceFuel: 0,
    holes: [],
    undergroundOpen: false,
    currentHole: null,
    nearCraftingTable: false,
    keysPressed: new Set(),
    cheatModeEnabled: false,
    animals: [],
    gridOccupied: new Set(),
    currentMap: 'surface',
    unlockedMaps: ['surface'],
    surfaceSnapshot: null,
    refreshCounts: {
        surface: 0,
        underground: 0
    },
    collisionEnabled: true,
    uiPanelOpen: false,
    messageVisible: false,
    buttonsHidden: false,
    gamePaused: false,
};

RESOURCES.forEach(r => {
    gameState.resources[r.key] = 0;
});

function bindBtn(id, fn) {
    const el = document.getElementById(id);
    if (el) {
        el.addEventListener('touchstart', e => { e.preventDefault(); fn(); }, { passive: false });
        el.addEventListener('click', fn);
    }
}

function updateResource(key, delta) {
    gameState.resources[key] = Math.max(0, (gameState.resources[key] || 0) + delta);
}

function updateDurability(durKey, max) {
    gameState[durKey]--;
    if (gameState[durKey] <= 0) {
        const toolKey = durKey.replace('Durability', '');
        updateResource(toolKey, -1);
        if (gameState.resources[toolKey] > 0) gameState[durKey] = max;
    }
}

function checkNear(selector, threshold = 100) {
    const elements = Array.from(document.querySelectorAll(selector));
    const playerPos = { x: gameState.playerX || window.innerWidth / 2, y: gameState.playerY || window.innerHeight / 2 };
    return elements.some(el => {
        const rect = el.getBoundingClientRect();
        const centerX = rect.left + rect.width / 2;
        const centerY = rect.top + rect.height / 2;
        const dist = Math.hypot(centerX - playerPos.x, centerY - playerPos.y);
        return dist < threshold;
    });
}

const craftingPagination = {
    totalPages: 4,
    nextPage() { 
        if (gameState.craftingPage < this.totalPages) { 
            gameState.craftingPage++; 
            this.updatePageDisplay(); 
        } 
    },
    prevPage() { 
        if (gameState.craftingPage > 1) { 
            gameState.craftingPage--; 
            this.updatePageDisplay(); 
        } 
    },
    updatePageDisplay() {
        const el = document.getElementById('crafting-page');
        if (el) el.textContent = `${gameState.craftingPage}/${this.totalPages}`;
        document.querySelectorAll('.recipe-page').forEach((page, idx) => {
            page.style.display = (idx === gameState.craftingPage - 1) ? 'block' : 'none';
        });
    }
};

function updateInventoryPanel() {
    const fuelEl = document.getElementById('inventory-fuel-value');
    if (fuelEl) fuelEl.textContent = gameState.furnaceFuel;
    
    const grid = document.getElementById('inventory-grid');
    if (!grid) return;
    
    grid.innerHTML = '';
    RESOURCES.filter(item => gameState.resources[item.key] > 0).forEach(item => {
        const div = document.createElement('div');
        div.className = 'inventory-item';
        div.style.cursor = ['craftingTable', 'furnace', 'rawMeat', 'cookedMeat'].includes(item.key) ? 'pointer' : 'default';
        div.innerHTML = `
            <div class="inventory-icon" style="background-image: url('${item.icon}')">${item.name}</div>
            <span>数量: ${gameState.resources[item.key]}</span>
            ${item.durability && gameState[item.durability] > 0 ? `<span>耐久: ${gameState[item.durability]}/${item.max}</span>` : ''}
        `;
        div.onclick = () => handleInventoryItemClick(item);
        grid.appendChild(div);
    });
}

function handleInventoryItemClick(item) {
    if (item.key === 'craftingTable') {
        closeAllPopups();
        const pos = findNearbyFreePosition(60, 60);
        if (!pos) {
            showMessage('周围没有空位，无法放置！');
            restoreGameButtons();
            return;
        }
        createCraftingTable(pos.x, pos.y);
        updateResource('craftingTable', -1);
        updateInventoryPanel();
        restoreGameButtons();
    } else if (item.key === 'furnace') {
        closeAllPopups();
        const pos = findNearbyFreePosition(60, 60);
        if (!pos) {
            showMessage('周围没有空位，无法放置！');
            restoreGameButtons();
            return;
        }
        const f = createElement('furnace', pos.x, pos.y, 60, 60);
        f.textContent = '熔炉';
        updateResource('furnace', -1);
        updateInventoryPanel();
        restoreGameButtons();
        resolveCollision();
    } else if (item.key === 'rawMeat') {
        if (gameState.health >= 20) return;
        if (gameState.resources.rawMeat > 0) {
            updateResource('rawMeat', -1);
            const add = Math.min(2, 20 - gameState.health);
            gameState.health += add;
            updateInventoryPanel();
            updateHealthBar();
        }
    } else if (item.key === 'cookedMeat') {
        if (gameState.health >= 20) return;
        if (gameState.resources.cookedMeat > 0) {
            updateResource('cookedMeat', -1);
            const add = Math.min(5, 20 - gameState.health);
            gameState.health += add;
            updateInventoryPanel();
            updateHealthBar();
        }
    }
}

function updateHealthBar() {
    const bar = document.getElementById('player-health-fill');
    const text = document.getElementById('player-health-text');
    const percent = Math.max(0, Math.min(20, gameState.health));
    if (bar) bar.style.width = (percent / 20 * 100) + '%';
    if (text) text.textContent = `${percent} / 20`;
}

function hideGameButtons() {
    if (gameState.controlMode !== 'button') return;
    
    const buttons = ['inventory-btn', 'touch-crafting', 'refresh-button', 'touch-joystick-area', 'touch-controls', 'map-btn'];
    buttons.forEach(id => {
        const el = document.getElementById(id);
        if (el) el.style.display = 'none';
    });
    
    const commandBtn = document.getElementById('command-btn');
    if (commandBtn) commandBtn.style.display = 'none';
    
    const actionButtons = ['dig-hole', 'place-ladder', 'open-chest-btn', 'reclaim-table-btn', 'reclaim-furnace-btn'];
    actionButtons.forEach(id => {
        const el = document.getElementById(id);
        if (el) el.style.display = 'none';
    });
}

function toggleAllButtons() {
    if (gameState.controlMode !== 'button') return;
    if (gameState.uiPanelOpen || gameState.messageVisible) return;
    
    gameState.buttonsHidden = !gameState.buttonsHidden;
    
    if (gameState.buttonsHidden) {
        hideGameButtons();
    } else {
        restoreGameButtons();
    }
}

function restoreGameButtons() {
    if (gameState.controlMode !== 'button') return;
    if (gameState.buttonsHidden) return;
    
    const inventoryBtn = document.getElementById('inventory-btn');
    if (inventoryBtn) inventoryBtn.style.display = 'flex';
    
    const touchCrafting = document.getElementById('touch-crafting');
    if (touchCrafting) touchCrafting.style.display = 'flex';
    
    const refreshButton = document.getElementById('refresh-button');
    if (refreshButton) refreshButton.style.display = 'flex';
    
    const touchJoystickArea = document.getElementById('touch-joystick-area');
    if (touchJoystickArea) touchJoystickArea.style.display = 'block';
    
    const touchControls = document.getElementById('touch-controls');
    if (touchControls) touchControls.style.display = 'flex';
    
    const mapBtn = document.getElementById('map-btn');
    if (mapBtn) mapBtn.style.display = 'flex';
    
    const commandBtn = document.getElementById('command-btn');
    if (commandBtn && gameState.cheatModeEnabled) commandBtn.style.display = 'flex';
    
    updateHoleButtons();
    updateReclaimTableBtn();
    updateReclaimFurnaceBtn();
}

let messageAutoCloseTimer = null;

// ===== 特效工具函数 =====
function screenShake(intensity = 6, duration = 200) {
    const container = document.getElementById('game-container');
    if (!container) return;
    const startTime = Date.now();
    const originalTransform = container.style.transform || '';
    function shake() {
        const elapsed = Date.now() - startTime;
        if (elapsed >= duration) {
            container.style.transform = originalTransform;
            return;
        }
        const progress = 1 - elapsed / duration;
        const dx = (Math.random() - 0.5) * intensity * 2 * progress;
        const dy = (Math.random() - 0.5) * intensity * 2 * progress;
        container.style.transform = `translate(${dx}px, ${dy}px)`;
        requestAnimationFrame(shake);
    }
    shake();
}

function spawnParticles(x, y, color = '#FFD700', count = 12, speed = 4, sizeRange = [4, 8]) {
    const container = document.getElementById('game-container') || document.body;
    for (let i = 0; i < count; i++) {
        const p = document.createElement('div');
        const size = sizeRange[0] + Math.random() * (sizeRange[1] - sizeRange[0]);
        const angle = Math.random() * Math.PI * 2;
        const dist = Math.random() * speed * 30 + 10;
        const duration = 400 + Math.random() * 400;
        p.style.cssText = `position:absolute;left:${x - size / 2}px;top:${y - size / 2}px;width:${size}px;height:${size}px;background:${color};border-radius:50%;pointer-events:none;z-index:9999;box-shadow:0 0 ${size}px ${color};opacity:1;transition:transform ${duration}ms cubic-bezier(0.1,0.7,0.3,1),opacity ${duration}ms ease-out;`;
        container.appendChild(p);
        requestAnimationFrame(() => {
            p.style.transform = `translate(${Math.cos(angle) * dist}px, ${Math.sin(angle) * dist - 20}px) scale(0.3)`;
            p.style.opacity = '0';
        });
        setTimeout(() => p.remove(), duration + 50);
    }
}

function floatingText(x, y, text, color = '#fff', fontSize = 20) {
    const container = document.getElementById('game-container') || document.body;
    const el = document.createElement('div');
    el.textContent = text;
    el.style.cssText = `position:absolute;left:${x}px;top:${y}px;transform:translate(-50%,0);color:${color};font-size:${fontSize}px;font-weight:bold;text-shadow:0 0 8px rgba(0,0,0,0.9),2px 2px 4px rgba(0,0,0,0.8);pointer-events:none;z-index:9999;opacity:1;transition:transform 800ms cubic-bezier(0.1,0.8,0.3,1),opacity 800ms ease-out;white-space:nowrap;`;
    container.appendChild(el);
    requestAnimationFrame(() => {
        el.style.transform = 'translate(-50%, -60px)';
        el.style.opacity = '0';
    });
    setTimeout(() => el.remove(), 850);
}

function hitFlash(element, color = 'rgba(255,255,255,0.8)', duration = 150) {
    if (!element) return;
    const originalFilter = element.style.filter;
    element.style.filter = 'brightness(2.5) saturate(0.5)';
    setTimeout(() => {
        element.style.filter = originalFilter;
    }, duration);
}

function showMessage(text) {
    const content = document.getElementById('message-content');
    const popup = document.getElementById('message-popup');
    
    if (content) {
        content.textContent = text;
    }
    
    if (popup) {
        popup.style.display = 'block';
        popup.style.zIndex = '2000';
        popup.style.visibility = 'visible';
        popup.style.opacity = '1';
        popup.style.position = 'fixed';
        popup.style.top = '50%';
        popup.style.left = '50%';
        popup.style.transform = 'translate(-50%, -50%)';
        popup.style.background = 'rgba(0, 0, 0, 0.9)';
        popup.style.padding = '20px';
        popup.style.borderRadius = '15px';
        popup.style.color = '#fff';
        popup.style.maxWidth = '90%';
        popup.style.boxShadow = '0 0 20px rgba(0,0,0,0.7)';
        popup.style.pointerEvents = 'auto';
        
        gameState.messageVisible = true;
        gameState.gamePaused = true;
        
        if (messageAutoCloseTimer) clearTimeout(messageAutoCloseTimer);
        messageAutoCloseTimer = setTimeout(() => {
            popup.style.display = 'none';
            gameState.messageVisible = false;
            messageAutoCloseTimer = null;

            gameState.uiPanelOpen = isAnyPanelOpen();

            if (!isAnyPanelOpen()) {
                gameState.gamePaused = false;
                if (gameState.controlMode === 'button') {
                    restoreGameButtons();
                }
                updateReclaimTableBtn();
                updateReclaimFurnaceBtn();
                updateHoleButtons();
            } else {
                gameState.gamePaused = true;
            }
        }, 3000);
    }
    
    if (gameState.controlMode === 'button') {
        hideGameButtons();
    }
}

function openPanel(panelId) {
    gameState.uiPanelOpen = true;
    
    if (gameState.controlMode === 'button') {
        hideGameButtons();
        
        if (panelId === 'inventory-panel') {
            const inventoryBtn = document.getElementById('inventory-btn');
            if (inventoryBtn) {
                inventoryBtn.style.display = 'flex';
                inventoryBtn.style.zIndex = '100';
            }
        } else if (panelId === 'map-ui') {
            const mapBtn = document.getElementById('map-btn');
            if (mapBtn) {
                mapBtn.style.display = 'flex';
                mapBtn.style.zIndex = '100';
            }
        } else if (panelId === 'crafting-ui') {
            const touchBtn = document.getElementById('touch-crafting');
            if (touchBtn) {
                touchBtn.style.display = 'flex';
                touchBtn.style.zIndex = '100';
            }
        }
    }
    
    gameState.gamePaused = true;
}

function closePanel(panelId) {
    const panel = document.getElementById(panelId);
    if (panel) {
        panel.style.display = 'none';
    }
    
    gameState.uiPanelOpen = isAnyPanelOpen();
    
    if (!isAnyPanelOpen()) {
        gameState.gamePaused = false;
        if (gameState.controlMode === 'button') {
            restoreGameButtons();
        }
    } else if (gameState.controlMode === 'button') {
        const crafting = document.getElementById('crafting-ui');
        if (crafting && crafting.style.display === 'block') {
            const touchBtn = document.getElementById('touch-crafting');
            if (touchBtn) {
                touchBtn.style.display = 'flex';
                touchBtn.style.zIndex = '100';
            }
        }
        
        const inventoryPanel = document.getElementById('inventory-panel');
        if (inventoryPanel && inventoryPanel.style.display === 'flex') {
            const inventoryBtn = document.getElementById('inventory-btn');
            if (inventoryBtn) {
                inventoryBtn.style.display = 'flex';
                inventoryBtn.style.zIndex = '100';
            }
        }
        
        const mapUI = document.getElementById('map-ui');
        if (mapUI && mapUI.style.display === 'block') {
            const mapBtn = document.getElementById('map-btn');
            if (mapBtn) {
                mapBtn.style.display = 'flex';
                mapBtn.style.zIndex = '100';
            }
        }
    }
}

function closeAllPopups() {
    gameState.uiPanelOpen = false;
    gameState.messageVisible = false;
    gameState.gamePaused = false;
    
    if (messageAutoCloseTimer) {
        clearTimeout(messageAutoCloseTimer);
        messageAutoCloseTimer = null;
    }
    
    const inventoryPanel = document.getElementById('inventory-panel');
    const crafting = document.getElementById('crafting-ui');
    const message = document.getElementById('message-popup');
    const fuel = document.getElementById('fuel-popup');
    const commandContainer = document.getElementById('command-container');
    const mapUI = document.getElementById('map-ui');
    
    if (inventoryPanel) {
        inventoryPanel.style.display = 'none';
    }
    if (crafting) crafting.style.display = 'none';
    if (message) message.style.display = 'none';
    if (fuel) fuel.style.display = 'none';
    if (commandContainer) commandContainer.style.display = 'none';
    if (mapUI) mapUI.style.display = 'none';
    
    if (gameState.controlMode === 'button') {
        restoreGameButtons();
    }
}

function toggleInventory() {
    const panel = document.getElementById('inventory-panel');
    const isOpen = panel && panel.style.display === 'flex';
    
    if (isOpen) {
        closePanel('inventory-panel');
    } else {
        closeAllPopups();
        panel.style.display = 'flex';
        updateInventoryPanel();
        openPanel('inventory-panel');
    }
}

function togglePopup(popup) {
    const willOpen = popup.style.display !== 'block';
    
    if (willOpen) {
        closeAllPopups();
        popup.style.display = 'block';
        if (popup.id === 'crafting-ui') updateCraftingButtons();
        openPanel(popup.id);
    } else {
        closePanel(popup.id);
    }
}

function updateCraftingButtons() {
    const nearTable = checkNear('.crafting-table');
    const nearFurnace = checkNear('.furnace');
    
    const safeToggle = (id, cond) => { 
        const el = document.getElementById(id); 
        if (el) el.classList.toggle('disabled', !cond); 
    };
    
    safeToggle('craft-axe', gameState.resources.stone >= 1 && gameState.resources.branch >= 1 && gameState.resources.vine >= 1);
    safeToggle('craft-table', gameState.resources.wood >= 1);
    safeToggle('craft-pickaxe', gameState.resources.fullVine >= 1 && gameState.resources.twig >= 1 && gameState.resources.wood >= 1 && nearTable);
    safeToggle('craft-vine', gameState.resources.fullVine >= 1);
    safeToggle('craft-branch', gameState.resources.twig >= 1);
    safeToggle('craft-wooden-sword', gameState.resources.fullVine >= 1 && gameState.resources.twig >= 1 && gameState.resources.wood >= 1 && nearTable);
    safeToggle('craft-furnace', gameState.resources.stone >= 10 && nearTable);
    safeToggle('craft-ladder', gameState.resources.branch >= 7 && nearTable);
    safeToggle('craft-stone-pickaxe', gameState.resources.fullVine >= 1 && gameState.resources.twig >= 1 && gameState.resources.stoneBlock >= 1 && nearTable);
    safeToggle('smelt-cooked-meat', gameState.resources.rawMeat >= 1 && nearFurnace && gameState.furnaceFuel >= 100);
    safeToggle('smelt-hardstone', (gameState.resources.hardStoneOre || 0) >= 1 && nearFurnace && gameState.furnaceFuel >= 200);
    
    updateFurnaceFuelUI();
    
    const crafting = document.getElementById('crafting-ui');
    if (crafting && crafting.style.display === 'block') renderCraftingUI();
}

function renderCraftingUI() {
    const container = document.getElementById('recipe-pages');
    if (!container) return;
    
    if (gameState.controlMode === 'button') {
        hideGameButtons();
        const touchBtn = document.getElementById('touch-crafting');
        if (touchBtn) {
            touchBtn.style.display = 'flex';
            touchBtn.style.zIndex = '100';
        }
    }
    
    const nearTable = checkNear('.crafting-table');
    const nearFurnace = checkNear('.furnace');
    
    const visible = RECIPES.filter(r => {
        if (r.category === 'global') return true;
        if (r.category === 'workbench') return nearTable;
        if (r.category === 'furnace') return nearFurnace;
        return false;
    });
    
    const perPage = 3;
    let pages = Math.max(1, Math.ceil(visible.length / perPage));
    
    if (nearFurnace) {
        pages++;
    }
    
    craftingPagination.totalPages = pages;
    if (!gameState.craftingPage || gameState.craftingPage < 1) gameState.craftingPage = 1;
    if (gameState.craftingPage > pages) gameState.craftingPage = pages;
    
    container.innerHTML = '';
    
    for (let p = 0; p < pages; p++) {
        if (nearFurnace && p === pages - 1) {
            continue;
        }
        
        const pageDiv = document.createElement('div');
        pageDiv.className = 'recipe-page';
        pageDiv.style.display = (p === gameState.craftingPage - 1) ? 'block' : 'none';
        
        const slice = visible.slice(p * perPage, p * perPage + perPage);
        
        slice.forEach(rec => {
            const row = document.createElement('div');
            row.className = 'recipe';
            
            const itemsDiv = document.createElement('div');
            itemsDiv.className = 'recipe-items';
            
            rec.ingredients.forEach(it => {
                const itemDiv = document.createElement('div');
                itemDiv.className = 'recipe-item';
                
                const icon = document.createElement('div');
                icon.className = 'recipe-icon';
                const res = RESOURCES.find(r => r.key === it.k);
                if (res && res.icon) {
                    icon.style.backgroundImage = `url('${res.icon}')`;
                } else {
                    icon.style.backgroundColor = res ? res.color : '#888';
                }
                icon.textContent = res ? res.name : it.k;
                
                itemDiv.appendChild(icon);
                itemDiv.appendChild(document.createElement('span')).textContent = `×${it.q}`;
                itemsDiv.appendChild(itemDiv);
            });
            
            row.appendChild(itemsDiv);
            
            const actionDiv = document.createElement('div');
            actionDiv.className = 'recipe-item';
            
            const iconOut = document.createElement('div');
            iconOut.className = 'recipe-icon';
            const outRes = RESOURCES.find(r => r.name === rec.title);
            if (outRes && outRes.icon) {
                iconOut.style.backgroundImage = `url('${outRes.icon}')`;
            } else {
                iconOut.style.backgroundColor = '#FF8C00';
            }
            iconOut.textContent = rec.title;
            
            actionDiv.appendChild(iconOut);
            
            const btn = document.createElement('button');
            btn.className = 'btn';
            btn.id = `dyn-craft-${rec.id}`;
            btn.textContent = '制作';
            
            const canCraft = rec.ingredients.every(it => (gameState.resources[it.k] || 0) >= it.q) && 
                           (rec.category !== 'workbench' || nearTable) && 
                           (rec.category !== 'furnace' || nearFurnace);
            
            if (!canCraft) btn.classList.add('disabled');
            
            btn.onclick = () => {
                if (btn.classList.contains('disabled')) {
                    showMessage('无法制作：条件不满足或距离不足');
                    return;
                }
                if (typeof window[rec.func] === 'function') {
                    const ok = window[rec.func]();
                    if (ok === false) return;
                } else {
                    showMessage('制作函数未实现');
                    return;
                }
                updateInventoryPanel();
                renderCraftingUI();
            };
            
            btn.addEventListener('touchstart', (e) => { 
                e.preventDefault(); 
                e.stopPropagation(); 
                btn.click(); 
            }, { passive: false });
            
            actionDiv.appendChild(btn);
            
            const desc = document.createElement('div');
            desc.className = 'recipe-requirement';
            desc.innerHTML = rec.desc || '';
            actionDiv.appendChild(desc);
            
            row.appendChild(actionDiv);
            pageDiv.appendChild(row);
        });
        
        container.appendChild(pageDiv);
    }
    
    craftingPagination.updatePageDisplay();
    updateFurnaceFuelUI();
    
    addFuelPage(nearFurnace);
}

function addFuelPage(nearFurnace) {
    const container = document.getElementById('recipe-pages');
    if (!container) return;
    
    let fuelPage = document.getElementById('fuel-page');
    if (fuelPage) {
        container.removeChild(fuelPage);
    }
    
    if (!nearFurnace) return;
    
    fuelPage = document.createElement('div');
    fuelPage.className = 'recipe-page';
    fuelPage.id = 'fuel-page';
    fuelPage.style.display = (gameState.craftingPage === craftingPagination.totalPages) ? 'block' : 'none';
    
    const row = document.createElement('div');
    row.className = 'recipe';
    
    const itemsDiv = document.createElement('div');
    itemsDiv.className = 'recipe-items';
    
    const rawMeatItem = document.createElement('div');
    rawMeatItem.className = 'recipe-item';
    rawMeatItem.innerHTML = '<div class="recipe-icon" style="background-image: url(\'assets/images/items/item_raw_meat.jpg\');">生肉</div><span>×1</span>';
    itemsDiv.appendChild(rawMeatItem);
    
    const fuelItem = document.createElement('div');
    fuelItem.className = 'recipe-item';
    fuelItem.innerHTML = '<div class="recipe-icon" style="background-image: url(\'assets/images/tiles/fuel_ore.jpg\');">燃料</div><span id="furnace-fuel-value">0</span>';
    itemsDiv.appendChild(fuelItem);
    
    row.appendChild(itemsDiv);
    
    const actionDiv = document.createElement('div');
    actionDiv.className = 'recipe-item';
    
    const cookedMeatIcon = document.createElement('div');
    cookedMeatIcon.className = 'recipe-icon';
    cookedMeatIcon.style.backgroundImage = "url('assets/images/items/item_cooked_meat.jpg')";
    cookedMeatIcon.textContent = '熟肉';
    actionDiv.appendChild(cookedMeatIcon);
    
    const smeltMeatBtn = document.createElement('button');
    smeltMeatBtn.className = 'btn';
    smeltMeatBtn.id = 'smelt-cooked-meat';
    smeltMeatBtn.textContent = '熔炼';
    if (gameState.resources.rawMeat < 1 || gameState.furnaceFuel < 100) {
        smeltMeatBtn.classList.add('disabled');
    }
    smeltMeatBtn.onclick = smeltCookedMeat;
    actionDiv.appendChild(smeltMeatBtn);
    
    const smeltHardBtn = document.createElement('button');
    smeltHardBtn.className = 'btn';
    smeltHardBtn.id = 'smelt-hardstone';
    smeltHardBtn.textContent = '烧制硬石块';
    if ((gameState.resources.hardStoneOre || 0) < 1 || gameState.furnaceFuel < 200) {
        smeltHardBtn.classList.add('disabled');
    }
    smeltHardBtn.onclick = smeltHardStone;
    actionDiv.appendChild(smeltHardBtn);
    
    const addFuelBtn = document.createElement('button');
    addFuelBtn.className = 'btn';
    addFuelBtn.id = 'add-fuel-btn';
    addFuelBtn.style.marginTop = '5px';
    addFuelBtn.textContent = '添加燃料';
    addFuelBtn.onclick = () => {
        showFuelPopup();
    };
    actionDiv.appendChild(addFuelBtn);
    
    const desc = document.createElement('div');
    desc.className = 'recipe-requirement';
    desc.innerHTML = '需要靠近熔炉<br>木棍20燃料，树枝60燃料，木材200燃料，燃矿1000燃料';
    actionDiv.appendChild(desc);
    
    row.appendChild(actionDiv);
    fuelPage.appendChild(row);
    container.appendChild(fuelPage);
    
    craftingPagination.updatePageDisplay();
}

function craftAxe() {
    if (gameState.resources.stone >= 1 && gameState.resources.branch >= 1 && gameState.resources.vine >= 1) {
        updateResource('stone', -1);
        updateResource('branch', -1);
        updateResource('vine', -1);
        updateResource('axe', 1);
        gameState.axeDurability = 10;
        updateInventoryPanel();
        showMessage("制作了一把粗制碎石斧！");
        updateCraftingButtons();
        const crafting = document.getElementById('crafting-ui');
        if (crafting) {
            crafting.style.display = 'block';
            renderCraftingUI();
            openPanel('crafting-ui');
        }
        return true;
    } else {
        showMessage("材料不足！需要1个石子、1个木棍和1个破碎藤蔓");
        return false;
    }
}

function craftTable() {
    if (gameState.resources.wood >= 1) {
        const pos = findNearbyFreePosition(60, 60);
        if (!pos) {
            showMessage('周围没有空位，无法放置！');
            return false;
        }
        updateResource('wood', -1);
        createCraftingTable(pos.x, pos.y);
        updateInventoryPanel();
        checkNearCraftingTable();
        updateCraftingButtons();
        checkRefreshButtonPosition();
        
        const crafting = document.getElementById('crafting-ui');
        if (crafting && crafting.style.display === 'block') {
            closePanel('crafting-ui');
        }
        updateReclaimTableBtn();
        showMessage("制作了一个合成台！");
        return true;
    } else {
        showMessage("材料不足！需要1个木材");
        return false;
    }
}

function craftPickaxe() {
    if (gameState.resources.fullVine >= 1 && gameState.resources.twig >= 1 && gameState.resources.wood >= 1) {
        if (gameState.nearCraftingTable) {
            updateResource('fullVine', -1);
            updateResource('twig', -1);
            updateResource('wood', -1);
            updateResource('pickaxe', 1);
            gameState.pickaxeDurability = 10;
            updateInventoryPanel();
            showMessage("制作了一把木镐（耐久10）！");
            updateCraftingButtons();
            const crafting = document.getElementById('crafting-ui');
            if (crafting) {
                crafting.style.display = 'block';
                renderCraftingUI();
                openPanel('crafting-ui');
            }
            return true;
        } else {
            showMessage("需要靠近合成台才能制作木镐！");
            return false;
        }
    } else {
        showMessage("材料不足！需要1个完整藤蔓、1个树枝和1个木材");
        return false;
    }
}

function craftStonePickaxe() {
    if (gameState.resources.fullVine >= 1 && gameState.resources.twig >= 1 && gameState.resources.stoneBlock >= 1) {
        if (gameState.nearCraftingTable) {
            updateResource('fullVine', -1);
            updateResource('twig', -1);
            updateResource('stoneBlock', -1);
            gameState.resources.stonePickaxe = (gameState.resources.stonePickaxe || 0) + 1;
            gameState.stonePickaxeDurability = 30;
            updateInventoryPanel();
            showMessage("制作了一把石镐（耐久30）！");
            updateCraftingButtons();
            const crafting = document.getElementById('crafting-ui');
            if (crafting) {
                crafting.style.display = 'block';
                renderCraftingUI();
                openPanel('crafting-ui');
            }
            return true;
        } else {
            showMessage("需要靠近合成台才能制作石镐！");
            return false;
        }
    } else {
        showMessage("材料不足！需要1个完整藤蔓、1个树枝和1个石块");
        return false;
    }
}

function craftHardStonePickaxe() {
    if ((gameState.resources.hardStoneBlock||0) >= 3 && (gameState.resources.twig||0) >= 1 && (gameState.resources.fullVine||0) >= 1) {
        if (gameState.nearCraftingTable) {
            updateResource('hardStoneBlock', -3);
            updateResource('twig', -1);
            updateResource('fullVine', -1);
            gameState.resources.hardStonePickaxe = (gameState.resources.hardStonePickaxe||0) + 1;
            gameState.hardStonePickaxeDurability = 100;
            updateInventoryPanel();
            showMessage('制作了一把硬石镐（耐久100）！');
            updateCraftingButtons();
            const crafting = document.getElementById('crafting-ui');
            if (crafting) {
                crafting.style.display = 'block';
                renderCraftingUI();
                openPanel('crafting-ui');
            }
            return true;
        } else {
            showMessage('需要靠近合成台才能制作硬石镐！');
            return false;
        }
    } else {
        showMessage('材料不足！需要3个硬石块、1个树枝和1个完整藤蔓');
        return false;
    }
}

function craftHardStoneSword() {
    if ((gameState.resources.hardStoneBlock||0) >= 2 && (gameState.resources.twig||0) >= 1 && (gameState.resources.fullVine||0) >= 1) {
        if (gameState.nearCraftingTable) {
            updateResource('hardStoneBlock', -2);
            updateResource('twig', -1);
            updateResource('fullVine', -1);
            gameState.resources.hardStoneSword = (gameState.resources.hardStoneSword||0) + 1;
            gameState.hardStoneSwordDurability = 150;
            updateInventoryPanel();
            showMessage('制作了一把硬石剑！');
            updateCraftingButtons();
            updateAttack();
            const crafting = document.getElementById('crafting-ui');
            if (crafting) {
                crafting.style.display = 'block';
                renderCraftingUI();
                openPanel('crafting-ui');
            }
            return true;
        } else {
            showMessage('需要靠近合成台才能制作硬石剑！');
            return false;
        }
    } else {
        showMessage('材料不足！需要2个硬石块、1个树枝和1个完整藤蔓');
        return false;
    }
}

function craftHardStoneAxe() {
    if ((gameState.resources.hardStoneBlock||0) >= 2 && (gameState.resources.branch||0) >= 1) {
        if (gameState.nearCraftingTable) {
            updateResource('hardStoneBlock', -2);
            updateResource('branch', -1);
            gameState.resources.hardStoneAxe = (gameState.resources.hardStoneAxe||0) + 1;
            gameState.hardStoneAxeDurability = 50;
            updateInventoryPanel();
            showMessage('制作了一把硬石斧！');
            updateCraftingButtons();
        const crafting = document.getElementById('crafting-ui');
        if (crafting) {
            crafting.style.display = 'block';
            renderCraftingUI();
            openPanel('crafting-ui');
        }
        return true;
        } else {
            showMessage('需要靠近合成台才能制作硬石斧！');
            return false;
        }
    } else {
        showMessage('材料不足！需要2个硬石块和1个木棍');
        return false;
    }
}

function craftFurnace() {
    if (gameState.resources.stone >= 10 && checkNearCraftingTable()) {
        const pos = findNearbyFreePosition(60, 60);
        if (!pos) {
            showMessage('周围没有空位，无法放置！');
            return false;
        }
        updateResource('stone', -10);
        const f = createElement('furnace', pos.x, pos.y, 60, 60);
        f.textContent = '熔炉';
        updateInventoryPanel();
        updateCraftingButtons();
        resolveCollision();
        
        const crafting = document.getElementById('crafting-ui');
        if (crafting && crafting.style.display === 'block') {
            closePanel('crafting-ui');
        }
        updateReclaimFurnaceBtn();
        showMessage('制作了一个熔炉！');
        return true;
    } else if (gameState.resources.stone < 10) {
        showMessage('材料不足！需要10个石子');
        return false;
    } else {
        showMessage('需要靠近合成台才能制作熔炉！');
        return false;
    }
}

function craftLadder() {
    if (gameState.resources.branch >= 7) {
        if (gameState.nearCraftingTable) {
            updateResource('branch', -7);
            gameState.resources.ladder = (gameState.resources.ladder || 0) + 1;
            updateInventoryPanel();
            showMessage("制作了一个梯子！");
            updateCraftingButtons();
            const crafting = document.getElementById('crafting-ui');
            if (crafting) {
                crafting.style.display = 'block';
                renderCraftingUI();
                openPanel('crafting-ui');
            }
            return true;
        } else {
            showMessage("需要靠近合成台才能制作梯子！");
            return false;
        }
    } else {
        showMessage("材料不足！需要7个木棍");
        return false;
    }
}

function craftWoodenSword() {
    if (gameState.resources.fullVine >= 1 && gameState.resources.twig >= 1 && gameState.resources.wood >= 1) {
        if (gameState.nearCraftingTable) {
            updateResource('fullVine', -1);
            updateResource('twig', -1);
            updateResource('wood', -1);
            gameState.resources.woodenSword++;
            gameState.woodenSwordDurability = 30;
            updateInventoryPanel();
            showMessage("制作了一把木剑！");
            updateCraftingButtons();
            updateAttack();
            const crafting = document.getElementById('crafting-ui');
            if (crafting) {
                crafting.style.display = 'block';
                renderCraftingUI();
                openPanel('crafting-ui');
            }
            return true;
        } else {
            showMessage("需要靠近合成台才能制作木剑！");
            return false;
        }
    } else {
        showMessage("材料不足！需要1个完整藤蔓、1个树枝和1个木材");
        return false;
    }
}

function craftBranch() {
    if (gameState.resources.twig < 1) {
        showMessage("没有树枝可分解！");
        return false;
    }
    updateResource('twig', -1);
    updateResource('branch', 3);
    updateInventoryPanel();
    showMessage("将1个树枝分解为3个木棍！");
    updateCraftingButtons();
    const crafting = document.getElementById('crafting-ui');
    if (crafting) {
        crafting.style.display = 'block';
        renderCraftingUI();
        openPanel('crafting-ui');
    }
    return true;
}

function craftVine() {
    if (gameState.resources.fullVine < 1) {
        showMessage("没有完整藤蔓可分解！");
        return false;
    }
    updateResource('fullVine', -1);
    updateResource('vine', 3);
    updateInventoryPanel();
    showMessage("将1个完整藤蔓分解为3个破碎藤蔓！");
    updateCraftingButtons();
    const crafting = document.getElementById('crafting-ui');
    if (crafting) {
        crafting.style.display = 'block';
        renderCraftingUI();
        openPanel('crafting-ui');
    }
    return true;
}

function updateAttack() {
    gameState.attack = 1 + (gameState.resources.hardStoneSword > 0 ? 3 : (gameState.resources.woodenSword > 0 ? 1 : 0));
}

function gridKey(col, row) {
    return `${col},${row}`;
}

function isGridCellOccupied(col, row, width, height) {
    const cols = Math.ceil(width / GRID_SIZE);
    const rows = Math.ceil(height / GRID_SIZE);
    
    for (let c = col; c < col + cols; c++) {
        for (let r = row; r < row + rows; r++) {
            if (gameState.gridOccupied.has(gridKey(c, r))) {
                return true;
            }
        }
    }
    return false;
}

function occupyGridCells(col, row, width, height) {
    const cols = Math.ceil(width / GRID_SIZE);
    const rows = Math.ceil(height / GRID_SIZE);
    
    for (let c = col; c < col + cols; c++) {
        for (let r = row; r < row + rows; r++) {
            gameState.gridOccupied.add(gridKey(c, r));
        }
    }
}

function freeGridCells(col, row, width, height) {
    const cols = Math.ceil(width / GRID_SIZE);
    const rows = Math.ceil(height / GRID_SIZE);
    
    for (let c = col; c < col + cols; c++) {
        for (let r = row; r < row + rows; r++) {
            gameState.gridOccupied.delete(gridKey(c, r));
        }
    }
}

function findFreePosition(width, height, attempts = 100) {
    const cols = Math.ceil(width / GRID_SIZE);
    const rows = Math.ceil(height / GRID_SIZE);
    const maxCol = Math.floor(window.innerWidth / GRID_SIZE) - cols;
    const maxRow = Math.floor(window.innerHeight / GRID_SIZE) - rows;
    
    if (maxCol < 0 || maxRow < 0) {
        return { x: 0, y: 0 };
    }
    
    const tried = new Set();
    
    for (let i = 0; i < attempts; i++) {
        const col = Math.floor(Math.random() * (maxCol + 1));
        const row = Math.floor(Math.random() * (maxRow + 1));
        
        if (tried.has(gridKey(col, row))) continue;
        tried.add(gridKey(col, row));
        
        if (!isGridCellOccupied(col, row, width, height)) {
            occupyGridCells(col, row, width, height);
            return { x: col * GRID_SIZE, y: row * GRID_SIZE };
        }
    }
    
    for (let col = 0; col <= maxCol; col++) {
        for (let row = 0; row <= maxRow; row++) {
            if (!isGridCellOccupied(col, row, width, height)) {
                occupyGridCells(col, row, width, height);
                return { x: col * GRID_SIZE, y: row * GRID_SIZE };
            }
        }
    }
    
    return { x: 0, y: 0 };
}

function findNearbyFreePosition(width, height) {
    const playerX = gameState.playerX || window.innerWidth / 2;
    const playerY = gameState.playerY || window.innerHeight / 2;
    const playerCol = Math.floor(playerX / GRID_SIZE);
    const playerRow = Math.floor(playerY / GRID_SIZE);
    
    const cols = Math.ceil(width / GRID_SIZE);
    const rows = Math.ceil(height / GRID_SIZE);
    const maxCol = Math.floor(window.innerWidth / GRID_SIZE) - cols;
    const maxRow = Math.floor(window.innerHeight / GRID_SIZE) - rows;
    
    const offsets = [
        {dc:-1,dr:0},{dc:1,dr:0},{dc:0,dr:-1},{dc:0,dr:1}
    ];
    
    for (const off of offsets) {
        const col = playerCol + off.dc;
        const row = playerRow + off.dr;
        
        if (col < 0 || row < 0 || col > maxCol || row > maxRow) continue;
        if (!isGridCellOccupied(col, row, width, height)) {
            occupyGridCells(col, row, width, height);
            return { x: col * GRID_SIZE, y: row * GRID_SIZE };
        }
    }
    
    return null;
}

function isBlockedAt(x, y, w = 50, h = 50, excludeEl = null) {
    if (!gameState.collisionEnabled) return false;
    
    let surfaceContainer, undergroundContainer;
    if (gameState.currentMap === 'surface') {
        surfaceContainer = document.getElementById('game-container');
    } else if (gameState.currentMap === 'underground' && gameState.currentHole && gameState.currentHole.underground) {
        undergroundContainer = gameState.currentHole.underground.container;
    }
    
    if (surfaceContainer) {
        const blocks = surfaceContainer.querySelectorAll('.tree-trunk, .tree-leaf, .bush, .stone, .crafting-table, .furnace, .animal');
        for (const el of blocks) {
            if (el === excludeEl) continue;
            
            const blockBounds = getElementBounds(el);
            
            if (x < blockBounds.right && x + w > blockBounds.left && y < blockBounds.bottom && y + h > blockBounds.top) {
                return true;
            }
        }
    }
    
    if (undergroundContainer) {
        if (gameState.currentHole && gameState.currentHole.underground) {
            const ug = gameState.currentHole.underground;
            if (ug.grid) {
                const tile = ug.tile;
                const startCol = Math.floor(x / tile);
                const startRow = Math.floor(y / tile);
                const endCol = Math.floor((x + w - 1) / tile);
                const endRow = Math.floor((y + h - 1) / tile);

                for (let r = startRow; r <= endRow; r++) {
                    for (let c = startCol; c <= endCol; c++) {
                        if (r < 0 || r >= ug.rows || c < 0 || c >= ug.cols) continue;
                        const cell = ug.grid[r][c];
                        if (cell.type !== 'empty' && cell.type !== 'chest') {
                            return true;
                        }
                    }
                }
            }
        }

        const domBlocks = undergroundContainer.querySelectorAll('.crafting-table, .furnace');
        for (const el of domBlocks) {
            const blockBounds = getElementBounds(el);
            if (x < blockBounds.right && x + w > blockBounds.left && y < blockBounds.bottom && y + h > blockBounds.top) {
                return true;
            }
        }
    }
    
    return false;
}

function createElement(className, x, y, width, height) {
    const el = document.createElement('div');
    el.className = `${className} game-element`;
    
    const w = width || (className === 'tree-trunk' ? 20 : (className === 'crafting-table' ? 60 : (className === 'stone' ? 50 : 50)));
    const h = height || (className === 'tree-trunk' ? 70 : (className === 'crafting-table' ? 60 : (className === 'stone' ? 50 : 50)));
    
    el.style.width = w + 'px';
    el.style.height = h + 'px';
    
    if (x == null || y == null) {
        const pos = findFreePosition(w, h);
        el.style.left = pos.x + 'px';
        el.style.top = pos.y + 'px';
    } else {
        el.style.left = x + 'px';
        el.style.top = y + 'px';
    }
    
    if (className === 'tree-trunk') {
        const bar = document.createElement('div');
        bar.className = 'progress-bar';
        bar.innerHTML = '<div class="progress-fill"></div>';
        el.appendChild(bar);
    }

    let container = document.getElementById('game-container');
    if (gameState.currentMap === 'underground' && gameState.currentHole && gameState.currentHole.underground) {
        container = gameState.currentHole.underground.container;
    }
    if (container) container.appendChild(el);
    
    if (['tree-leaf', 'bush', 'stone', 'tree-trunk'].includes(className)) {
        attachLongPress(el, () => {
            if (!isWithinInteractRange(el, 2)) {
                showMessage('太远了！靠近后长按以采集。');
                return;
            }
            if (className === 'tree-leaf' || className === 'bush') collectLeaf(el);
            else if (className === 'stone') collectStone(el);
            else if (className === 'tree-trunk') {
                const leaf = el.previousElementSibling;
                chopTree(el, leaf?.classList.contains('tree-leaf') ? leaf : null);
            }
        }, 400, (element) => {
            if (breakingElements.has(element)) {
                resetBreakingProgress(element);
            }
        });
    }
    
    return el;
}

function createCraftingTable(x, y) {
    const table = createElement('crafting-table', x, y, 60, 60);
    table.textContent = '合成台';
    resolveCollision();
    return table;
}

function attachLongPress(el, callback, holdMs = 400, onCancel = null) {
    let timer = null;
    let started = false;
    let touchId = null;
    
    const start = (e) => { 
        e.preventDefault && e.preventDefault(); 
        started = false;
        if (e.type === 'touchstart') {
            touchId = e.changedTouches[0].identifier;
        }
        timer = setTimeout(() => { 
            timer = null; 
            started = true;
            callback(); 
        }, holdMs); 
    };
    
    const cancel = () => { 
        if (timer) { 
            clearTimeout(timer); 
            timer = null; 
        }
        if (started && onCancel) {
            onCancel(el);
            started = false;
        }
        touchId = null;
    };
    
    el.addEventListener('mousedown', start);
    el.addEventListener('touchstart', start, { passive: false });
    el.addEventListener('mouseup', cancel);
    el.addEventListener('mouseleave', cancel);
    el.addEventListener('touchend', cancel);
    el.addEventListener('touchcancel', cancel);
    el.addEventListener('touchmove', (e) => {
        if (touchId === null) return;
        
        for (let i = 0; i < e.changedTouches.length; i++) {
            if (e.changedTouches[i].identifier === touchId) {
                const touch = e.changedTouches[i];
                const rect = el.getBoundingClientRect();
                if (touch.clientX < rect.left || touch.clientX > rect.right ||
                    touch.clientY < rect.top || touch.clientY > rect.bottom) {
                    cancel();
                }
                break;
            }
        }
    }, { passive: false });
}

function isWithinInteractRange(el, multiplier = 2) {
    const playerX = gameState.playerX || window.innerWidth / 2;
    const playerY = gameState.playerY || window.innerHeight / 2;
    
    const rect = el.getBoundingClientRect();
    const centerX = rect.left + rect.width / 2;
    const centerY = rect.top + rect.height / 2;
    
    const dist = Math.hypot(centerX - playerX, centerY - playerY);
    const elRadius = Math.max(el.offsetWidth, el.offsetHeight) / 2;
    const playerRadius = 25;
    
    return dist <= elRadius * multiplier + playerRadius;
}

function collectLeaf(leaf) {
    if (!isWithinInteractRange(leaf, 2)) return;
    if (gameState.resources.axe > 0 && gameState.axeDurability > 0) {
        startBreaking(leaf, 'twig');
        setTimeout(() => { 
            updateResource('fullVine', 1); 
            updateResource('twig', 1);
            updateInventoryPanel(); 
        }, 600);
    } else {
        startBreaking(leaf, Math.random() < 0.5 ? 'vine' : 'branch');
    }
}

function collectStone(stone) {
    if (!isWithinInteractRange(stone, 2)) return;
    startBreaking(stone, 'stone');
}

function chopTree(trunk, leaf) {
    if (!isWithinInteractRange(trunk, 2)) {
        showMessage('太远了！靠近后长按以砍树。');
        return;
    }
    if (gameState.resources.axe > 0 && gameState.axeDurability > 0) {
        if (!breakingElements.has(trunk)) startBreaking(trunk, 'wood', true, leaf);
    } else {
        showMessage('需要斧头才能砍树！');
    }
}

const breakingElements = new Map();

function startBreaking(element, resourceType, isTree = false, attachedLeaf = null) {
    if (breakingElements.has(element)) return;
    
    for (const [el] of breakingElements) {
        resetBreakingProgress(el);
    }
    
    let breakTime = isTree ? 5000 : 500;
    let toolUsed = null;
    
    if (isTree) {
        if (gameState.resources.hardStoneAxe > 0 && gameState.hardStoneAxeDurability > 0) {
            toolUsed = 'hardStoneAxe';
        } else if (gameState.resources.axe > 0 && gameState.axeDurability > 0) {
            toolUsed = 'axe';
        }
        const speedFactor = (toolUsed === 'hardStoneAxe') ? 3 : (toolUsed === 'axe' ? 1 : 1);
        breakTime = Math.max(200, breakTime / speedFactor);
    }
    
    let progress = 0;
    let progressBar = element.querySelector('.progress-fill');
    
    if (!progressBar) {
        const barContainer = document.createElement('div');
        barContainer.className = 'progress-bar';
        barContainer.style.position = 'absolute';
        barContainer.style.bottom = '0';
        barContainer.style.left = '0';
        barContainer.style.width = '100%';
        barContainer.style.height = '6px';
        barContainer.style.background = '#333';
        barContainer.style.borderRadius = '3px';
        
        progressBar = document.createElement('div');
        progressBar.className = 'progress-fill';
        progressBar.style.height = '100%';
        progressBar.style.width = '0%';
        progressBar.style.background = '#FF8C00';
        progressBar.style.borderRadius = '3px';
        
        barContainer.appendChild(progressBar);
        element.appendChild(barContainer);
    }
    
    breakingElements.set(element, {
        progress: 0,
        interval: setInterval(() => {
            const playerX = gameState.playerX || window.innerWidth / 2;
            const playerY = gameState.playerY || window.innerHeight / 2;
            const rect = element.getBoundingClientRect();
            const centerX = rect.left + rect.width / 2;
            const centerY = rect.top + rect.height / 2;
            const dist = Math.hypot(centerX - playerX, centerY - playerY);
            
            if (dist > 80) {
                resetBreakingProgress(element);
                return;
            }
            
            progress += 100;
            const percent = Math.min(100, (progress / breakTime) * 100);
            breakingElements.get(element).progress = percent;
            if (progressBar) progressBar.style.width = `${percent}%`;

            // 采集敲击微粒子
            if (Math.random() < 0.6) {
                const px = centerX + (Math.random() - 0.5) * rect.width * 0.6;
                const py = centerY + (Math.random() - 0.5) * rect.height * 0.6;
                const miniP = document.createElement('div');
                const miniSize = 2 + Math.random() * 3;
                const miniColor = isTree ? '#8B4513' : (resourceType === 'stone' ? '#a0a0a0' : '#228B22');
                miniP.style.cssText = `position:absolute;left:${px - miniSize / 2}px;top:${py - miniSize / 2}px;width:${miniSize}px;height:${miniSize}px;background:${miniColor};border-radius:50%;pointer-events:none;z-index:999;box-shadow:0 0 ${miniSize}px ${miniColor};opacity:1;transition:transform 250ms ease-out,opacity 250ms ease-out;`;
                const container = document.getElementById('game-container');
                if (container) container.appendChild(miniP);
                const ma = -Math.PI / 2 + (Math.random() - 0.5) * Math.PI * 0.7;
                const md = 8 + Math.random() * 15;
                requestAnimationFrame(() => {
                    miniP.style.transform = `translate(${Math.cos(ma) * md}px, ${Math.sin(ma) * md}px) scale(0.2)`;
                    miniP.style.opacity = '0';
                });
                setTimeout(() => miniP.remove(), 280);
            }

            if (progress >= breakTime) finishBreaking(element, resourceType, isTree, toolUsed, attachedLeaf);
        }, 100),
        isTree,
        toolUsed,
        attachedLeaf
    });
    
    element.classList.add('breaking');
}

function finishBreaking(element, resourceType, isTree, toolUsed, attachedLeaf = null) {
    const info = breakingElements.get(element) || {};
    resetBreakingProgress(element);
    element.classList.add('broken');
    
    const rect = element.getBoundingClientRect();
    const centerX = rect.left + rect.width / 2;
    const centerY = rect.top + rect.height / 2;
    const col = Math.floor(rect.left / GRID_SIZE);
    const row = Math.floor(rect.top / GRID_SIZE);
    
    screenShake(isTree ? 5 : 3, isTree ? 200 : 120);
    
    let particleColor = '#8B4513';
    let resourceName = resourceType;
    if (resourceType === 'stone') { particleColor = '#a0a0a0'; resourceName = '石子'; }
    else if (resourceType === 'twig') { particleColor = '#8B4513'; resourceName = '树枝'; }
    else if (resourceType === 'vine') { particleColor = '#228B22'; resourceName = '藤蔓'; }
    else if (resourceType === 'branch') { particleColor = '#A0522D'; resourceName = '树枝'; }
    else if (resourceType === 'fullVine') { particleColor = '#32CD32'; resourceName = '完整藤蔓'; }
    else if (resourceType === 'wood') { particleColor = '#8B4513'; resourceName = '木头'; }
    
    setTimeout(() => {
        element.remove();
        freeGridCells(col, row, rect.width, rect.height);
        
        if (isTree) {
            updateResource('wood', 1);
            if (info.toolUsed === 'hardStoneAxe' && gameState.hardStoneAxeDurability > 0) {
                updateDurability('hardStoneAxeDurability', 50);
            } else if (info.toolUsed === 'axe' && gameState.axeDurability > 0) {
                updateDurability('axeDurability', 10);
            }
            
            spawnParticles(centerX, centerY, '#8B4513', 18, 4, [4, 8]);
            spawnParticles(centerX, centerY, '#A0522D', 10, 3, [3, 5]);
            floatingText(centerX, centerY, '+1 木头', '#CD853F', 18);
            
            const leaf = attachedLeaf || info.attachedLeaf;
            if (leaf && leaf.parentNode && leaf.classList.contains('tree-leaf')) {
                    leaf.classList.add('broken');
                    const leafRect = leaf.getBoundingClientRect();
                    const leafCol = Math.floor(leafRect.left / GRID_SIZE);
                    const leafRow = Math.floor(leafRect.top / GRID_SIZE);
                    const leafCx = leafRect.left + leafRect.width / 2;
                    const leafCy = leafRect.top + leafRect.height / 2;
                    setTimeout(() => {
                        leaf.remove();
                        freeGridCells(leafCol, leafRow, leafRect.width, leafRect.height);
                        spawnParticles(leafCx, leafCy, '#228B22', 20, 4, [5, 10]);
                        spawnParticles(leafCx, leafCy, '#32CD32', 12, 3, [3, 6]);
                        if (gameState.resources.axe > 0 && gameState.axeDurability > 0) {
                            updateResource('fullVine', 1);
                            updateResource('twig', 1);
                            floatingText(leafCx, leafCy, '+完整藤蔓 +树枝', '#90EE90', 16);
                        } else {
                            const got = Math.random() < 0.5 ? 'vine' : 'branch';
                            updateResource(got);
                            floatingText(leafCx, leafCy, got === 'vine' ? '+1 藤蔓' : '+1 树枝', '#90EE90', 16);
                        }
                        updateInventoryPanel();
                    }, 500);
                }
        } else if (resourceType === 'fullVine') {
            updateResource('fullVine', 1);
            spawnParticles(centerX, centerY, '#32CD32', 15, 4, [4, 8]);
            floatingText(centerX, centerY, '+1 完整藤蔓 +1 树枝', '#90EE90', 16);
        } else {
            updateResource(resourceType, 1);
            spawnParticles(centerX, centerY, particleColor, 12, 3.5, [4, 7]);
            floatingText(centerX, centerY, `+1 ${resourceName}`, particleColor, 18);
        }
        updateInventoryPanel();
    }, 500);
}

function resetBreakingProgress(element) {
    if (breakingElements.has(element)) {
        const d = breakingElements.get(element);
        clearInterval(d.interval);
        element.classList.remove('breaking');
        const bars = element.querySelectorAll('.progress-fill');
        for (const bar of bars) {
            bar.remove();
        }
        breakingElements.delete(element);
    }
}

function digHole() {
    let pickaxeType = null;
    let durabilityKey = null;
    let durabilityCost = 0;
    
    if (gameState.resources.hardStonePickaxe > 0 && gameState.hardStonePickaxeDurability >= 1) {
        pickaxeType = 'hardStonePickaxe';
        durabilityKey = 'hardStonePickaxeDurability';
        durabilityCost = 1;
    } else if (gameState.resources.stonePickaxe > 0 && gameState.stonePickaxeDurability >= 1) {
        pickaxeType = 'stonePickaxe';
        durabilityKey = 'stonePickaxeDurability';
        durabilityCost = 1;
    } else if (gameState.resources.pickaxe > 0 && gameState.pickaxeDurability >= 2) {
        pickaxeType = 'pickaxe';
        durabilityKey = 'pickaxeDurability';
        durabilityCost = 2;
    }
    
    if (!pickaxeType) {
        showMessage('需要镐来挖洞！');
        return;
    }
    
    const playerX = gameState.playerX || window.innerWidth / 2;
    const playerY = gameState.playerY || window.innerHeight / 2;
    const hx = playerX - 20;
    const hy = playerY - 20;
    
    for (const h of gameState.holes) {
        const dist = Math.hypot(h.x - hx, h.y - hy);
        if (dist < 30) {
            showMessage('这里已经有洞了');
            return;
        }
    }
    
    gameState[durabilityKey] -= durabilityCost;
    if (gameState[durabilityKey] <= 0) {
        updateResource(pickaxeType, -1);
        if (gameState.resources[pickaxeType] > 0) {
            if (pickaxeType === 'hardStonePickaxe') {
                gameState[durabilityKey] = 200;
            } else if (pickaxeType === 'stonePickaxe') {
                gameState[durabilityKey] = 100;
            } else {
                gameState[durabilityKey] = 10;
            }
        }
    }
    
    const hole = { x: hx, y: hy, hasLadder: false, underground: null, id: Date.now() };
    gameState.holes.push(hole);
    
    const holeEl = document.createElement('div');
    holeEl.className = 'hole game-element';
    holeEl.style.left = hx + 'px';
    holeEl.style.top = hy + 'px';
    holeEl.style.width = '40px';
    holeEl.style.height = '40px';
    holeEl.style.background = "url('assets/images/sprites/hole.jpg') center / 100% 100% no-repeat";
    holeEl.style.borderRadius = '6px';
    holeEl.dataset.holeId = hole.id;
    
    const container = document.getElementById('game-container');
    if (container) container.appendChild(holeEl);
    
    updateInventoryPanel();
    showMessage('挖好了一个洞！');
}

function placeLadder() {
    let nearHole = null;
    const playerX = gameState.playerX || window.innerWidth / 2;
    const playerY = gameState.playerY || window.innerHeight / 2;
    
    for (const h of gameState.holes) {
        const d = Math.hypot(h.x - playerX, h.y - playerY);
        if (d < 80) {
            nearHole = h;
            break;
        }
    }
    
    if (!nearHole) {
        showMessage('附近没有可放置梯子的洞！');
        return;
    }
    if (!gameState.resources.ladder) {
        showMessage('没有梯子可放置！');
        return;
    }
    if (nearHole.hasLadder) {
        showMessage('该洞已有梯子！');
        return;
    }
    
    nearHole.hasLadder = true;
    updateResource('ladder', -1);
    updateInventoryPanel();
    unlockUndergroundMap();
    
    const ladderEl = document.createElement('div');
    ladderEl.className = 'ladder game-element';
    ladderEl.style.left = (nearHole.x + 10) + 'px';
    ladderEl.style.top = nearHole.y + 'px';
    ladderEl.style.width = '20px';
    ladderEl.style.height = '40px';
    ladderEl.style.background = "url('assets/images/sprites/ladder.jpg') center / 100% 100% no-repeat";
    ladderEl.dataset.holeId = nearHole.id;
    
    const container = document.getElementById('game-container');
    if (container) container.appendChild(ladderEl);
    
    showMessage('放置了梯子，现在可以进入矿洞');
}

function openMapUI() {
    const mapUI = document.getElementById('map-ui');
    const mapItems = document.querySelectorAll('.map-item');
    
    mapItems.forEach(item => {
        const mapId = item.dataset.map;
        const statusEl = item.querySelector('.map-status');
        
        item.classList.remove('disabled');
        
        if (gameState.currentMap === mapId) {
            statusEl.textContent = '当前';
            statusEl.className = 'map-status current';
            item.classList.add('disabled');
        } else if (gameState.unlockedMaps.includes(mapId)) {
            statusEl.textContent = '已解锁';
            statusEl.className = 'map-status available';
        } else {
            statusEl.textContent = '未解锁';
            statusEl.className = 'map-status locked';
            item.classList.add('disabled');
        }
    });
    
    mapUI.style.display = 'block';
    openPanel('map-ui');
}

function closeMapUI() {
    closePanel('map-ui');
}

function unlockUndergroundMap() {
    if (!gameState.unlockedMaps.includes('underground')) {
        gameState.unlockedMaps.push('underground');
        showMessage('地下矿洞已解锁！');
    }
}

function switchMap(mapId) {
    if (gameState.currentMap === mapId) return;
    if (!gameState.unlockedMaps.includes(mapId)) return;
    
    const canSwitch = checkCanSwitchMap();
    if (!canSwitch) {
        showMessage('请回到地图刷新区域再切换地图！');
        return;
    }
    
    saveCurrentMapState();
    
    if (mapId === 'surface') {
        loadSurfaceMap();
    } else if (mapId === 'underground') {
        loadUndergroundMap();
    }
    
    closeMapUI();
}

function checkCanSwitchMap() {
    const playerX = gameState.playerX || window.innerWidth / 2;
    const playerY = gameState.playerY || window.innerHeight / 2;
    
    const refreshRadius = 150;
    const centerX = window.innerWidth - 120;
    const centerY = 100;
    
    const distance = Math.hypot(playerX - centerX, playerY - centerY);
    return distance < refreshRadius;
}

function saveCurrentMapState() {
    if (gameState.currentMap === 'surface') {
        const container = document.getElementById('game-container');
        gameState.surfaceSnapshot = {
            innerHTML: container.innerHTML,
            playerX: gameState.playerX,
            playerY: gameState.playerY
        };
    } else if (gameState.currentMap === 'underground' && gameState.currentHole) {
        const hole = gameState.currentHole;
        hole.playerX = gameState.playerX;
        hole.playerY = gameState.playerY;
    }
}

function loadSurfaceMap() {
    gameState.collisionEnabled = false;
    
    const container = document.getElementById('game-container');
    const player = document.getElementById('phaser-player');
    
    if (gameState.currentHole && gameState.currentHole.underground) {
        gameState.currentHole.underground.container.style.display = 'none';
        if (player) container.appendChild(player);
    }
    
    if (gameState.surfaceSnapshot) {
        container.innerHTML = gameState.surfaceSnapshot.innerHTML;
    }
    
    gameState.playerX = window.innerWidth - 70;
    gameState.playerY = 50;
    
    container.style.display = 'block';
    gameState.currentMap = 'surface';
    gameState.undergroundOpen = false;
    
    const hasLadderHole = gameState.holes.some(h => h.hasLadder);
    if (hasLadderHole) {
        unlockUndergroundMap();
    }
    
    if (!isAnyPanelOpen()) {
        updateHoleButtons();
    }
    updateCraftingButtons();
    updatePlayerPosition();
    
    setTimeout(() => {
        gameState.collisionEnabled = true;
        resolveCollision();
    }, 100);
}

function loadUndergroundMap() {
    gameState.collisionEnabled = false;
    
    let hole = gameState.currentHole;
    
    if (!hole) {
        for (const h of gameState.holes) {
            if (h.hasLadder) {
                hole = h;
                break;
            }
        }
    }
    
    if (!hole) {
        if (gameState.cheatModeEnabled) {
            hole = { 
                x: window.innerWidth / 2, 
                y: window.innerHeight / 2, 
                hasLadder: true, 
                underground: null, 
                id: Date.now(),
                playerX: undefined,
                playerY: undefined
            };
            gameState.holes.push(hole);
        } else {
            showMessage('没有可进入的矿洞');
            gameState.collisionEnabled = true;
            return false;
        }
    }
    
    if (!hole.surfaceSnapshot) saveSurfaceSnapshot(hole);
    if (!hole.underground) hole.underground = generateUndergroundForHole(hole);
    
    const container = document.getElementById('game-container');
    const undergroundData = hole.underground;
    const ug = undergroundData.container;
    
    container.style.display = 'none';
    ug.style.display = 'block';
    ug.style.zIndex = 90;
    
    const player = document.getElementById('phaser-player');
    if (player) ug.appendChild(player);
    
    gameState.playerX = (undergroundData.cols - 0.5) * undergroundData.tile;
    gameState.playerY = undergroundData.tile / 2;
    
    gameState.currentMap = 'underground';
    gameState.currentHole = hole;
    gameState.undergroundOpen = true;
    
    if (!isAnyPanelOpen()) {
        updateHoleButtons();
    }
    updateCraftingButtons();
    updatePlayerPosition();
    
    setTimeout(() => {
        gameState.collisionEnabled = true;
        resolveCollision();
    }, 100);
    
    return true;
}

function enterUnderground(hole) {
    const surfaceRefreshCount = gameState.refreshCounts.surface || 0;
    if (surfaceRefreshCount < 5) {
        showMessage(`需要主世界刷新 5 次才能进入地下！当前刷新次数: ${surfaceRefreshCount}/5`);
        return;
    }
    
    unlockUndergroundMap();
    saveCurrentMapState();
    loadUndergroundMap();
    showMessage('已进入地下矿洞！');
}

function exitUnderground() {
    saveCurrentMapState();
    loadSurfaceMap();
    showMessage('已回到地面世界！');
}

function saveSurfaceSnapshot(hole) {
    const snapshot = [];
    const container = document.getElementById('game-container');
    if (!container) return;
    
    container.querySelectorAll('.game-element').forEach(el => {
        if (el.id === 'phaser-player') return;
        
        const ds = {};
        for (const k in el.dataset) ds[k] = el.dataset[k];
        
        snapshot.push({
            className: el.className.replace(' game-element', ''),
            left: el.style.left,
            top: el.style.top,
            width: el.style.width,
            height: el.style.height,
            innerHTML: el.innerHTML,
            text: el.textContent,
            dataset: ds
        });
        
        el.remove();
    });
    
    hole.surfaceSnapshot = snapshot;
}

function generateUndergroundForHole(hole) {
    const tile = 80;
    const cols = Math.ceil(window.innerWidth / tile);
    const rows = Math.ceil(window.innerHeight / tile);

    const container = document.createElement('div');
    container.className = 'underground-container';
    container.style.position = 'fixed';
    container.style.left = '0';
    container.style.top = '0';
    container.style.width = '100vw';
    container.style.height = '100vh';
    container.style.background = "url('assets/images/backgrounds/underground_bg.jpg') #222 center / 100% 100% no-repeat";
    container.style.display = 'none';
    container.style.zIndex = 90;
    container.style.overflow = 'hidden';
    document.body.appendChild(container);

    const oreCanvas = document.createElement('canvas');
    oreCanvas.width = cols * tile;
    oreCanvas.height = rows * tile;
    oreCanvas.style.cssText = 'position:absolute;top:0;left:0;pointer-events:none;z-index:91;';
    container.appendChild(oreCanvas);

    const rockCanvas = document.createElement('canvas');
    rockCanvas.width = cols * tile;
    rockCanvas.height = rows * tile;
    rockCanvas.style.cssText = 'position:absolute;top:0;left:0;z-index:92;';
    container.appendChild(rockCanvas);

    const grid = [];
    for (let r = 0; r < rows; r++) {
        grid[r] = [];
        for (let c = 0; c < cols; c++) {
            grid[r][c] = { type: 'stoneBlock' };
        }
    }

    const exitCol = cols - 1;
    const exitRow = 0;
    grid[exitRow][exitCol].type = 'empty';
    if (exitCol - 1 >= 0) grid[exitRow][exitCol - 1].type = 'empty';
    if (exitRow + 1 < rows) grid[exitRow + 1][exitCol].type = 'empty';

    const chestRow = Math.floor(Math.random() * (rows - 2)) + 1;
    const chestCol = Math.floor(Math.random() * (cols - 2)) + 1;
    grid[chestRow][chestCol].type = 'chest';

    for (let r = 0; r < rows; r++) {
        for (let c = 0; c < cols; c++) {
            if (grid[r][c].type !== 'stoneBlock') continue;
            const rand = Math.random();
            if (rand < 0.05) grid[r][c].type = 'fuelOre';
            else if (rand < 0.15) grid[r][c].type = 'hardStoneOre';
        }
    }

    hole.underground = { grid, container, oreCanvas, rockCanvas, cols, rows, tile, chestRow, chestCol, imagesLoaded: false };

    const rockBgImg = new Image();
    rockBgImg.src = 'assets/images/tiles/stone_block_bg.jpg';
    const fuelOreImg = new Image();
    fuelOreImg.src = 'assets/images/tiles/fuel_ore.jpg';
    const hardStoneOreImg = new Image();
    hardStoneOreImg.src = 'assets/images/tiles/hard_stone_ore.jpg';

    const allImages = [rockBgImg, fuelOreImg, hardStoneOreImg];
    let loadedCount = 0;

    function renderWhenReady() {
        loadedCount++;
        if (loadedCount < allImages.length) return;

        const ug = hole.underground;
        if (!ug) return;
        const oreCtx = ug.oreCanvas.getContext('2d');
        const rockCtx = ug.rockCanvas.getContext('2d');
        oreCtx.imageSmoothingEnabled = false;
        rockCtx.imageSmoothingEnabled = false;

        for (let r = 0; r < ug.rows; r++) {
            for (let c = 0; c < ug.cols; c++) {
                const cell = ug.grid[r][c];
                const x = c * ug.tile;
                const y = r * ug.tile;

                if (cell.type === 'fuelOre') {
                    oreCtx.drawImage(fuelOreImg, x, y, ug.tile, ug.tile);
                } else if (cell.type === 'hardStoneOre') {
                    oreCtx.drawImage(hardStoneOreImg, x, y, ug.tile, ug.tile);
                }
            }
        }

        rockCtx.drawImage(rockBgImg, 0, 0, ug.rockCanvas.width, ug.rockCanvas.height);

        for (let r = 0; r < ug.rows; r++) {
            for (let c = 0; c < ug.cols; c++) {
                const cell = ug.grid[r][c];
                if (cell.type === 'stoneBlock') continue;
                const x = c * ug.tile;
                const y = r * ug.tile;
                rockCtx.clearRect(x, y, ug.tile, ug.tile);
            }
        }

        ug.imagesLoaded = true;
        ug._rockBgImg = rockBgImg;
        ug._fuelOreImg = fuelOreImg;
        ug._hardStoneOreImg = hardStoneOreImg;

        const chestEl = document.createElement('div');
        chestEl.className = 'ug-tile';
        chestEl.dataset.type = 'chest';
        chestEl.dataset.opened = 'false';
        chestEl.style.cssText = `position:absolute;left:${ug.chestCol * ug.tile}px;top:${ug.chestRow * ug.tile}px;width:${ug.tile}px;height:${ug.tile}px;background:url('assets/images/sprites/chest.jpg') center/100% 100% no-repeat;border:3px solid #FFD700;border-radius:8px;display:flex;align-items:center;justify-content:center;font-size:2rem;z-index:10;box-sizing:border-box;`;
        ug.container.appendChild(chestEl);
        ug.chestEl = chestEl;

        attachUndergroundLongPress(ug.rockCanvas, ug);
    }

    allImages.forEach(img => {
        if (img.complete) renderWhenReady();
        else img.onload = renderWhenReady;
    });

    return hole.underground;
}

function attachUndergroundLongPress(canvas, ug) {
    let timer = null;
    let started = false;
    let touchId = null;
    let currentCell = null;

    const start = (e) => {
        if (e.preventDefault) e.preventDefault();
        started = false;

        const rect = canvas.getBoundingClientRect();
        let clientX, clientY;
        if (e.type === 'touchstart') {
            touchId = e.changedTouches[0].identifier;
            clientX = e.changedTouches[0].clientX;
            clientY = e.changedTouches[0].clientY;
        } else {
            clientX = e.clientX;
            clientY = e.clientY;
        }

        const x = clientX - rect.left;
        const y = clientY - rect.top;
        const col = Math.floor(x / ug.tile);
        const row = Math.floor(y / ug.tile);

        if (row < 0 || row >= ug.rows || col < 0 || col >= ug.cols) return;

        const cell = ug.grid[row][col];
        if (cell.type === 'empty' || cell.type === 'chest') return;

        currentCell = { row, col };

        timer = setTimeout(() => {
            timer = null;
            started = true;
            if (currentCell) {
                startMiningCanvas(ug, currentCell.row, currentCell.col);
            }
        }, 400);
    };

    const cancel = () => {
        if (timer) {
            clearTimeout(timer);
            timer = null;
        }
        if (started && currentCell) {
            const key = `ug:${currentCell.row},${currentCell.col}`;
            if (breakingElements.has(key)) {
                resetBreakingProgressByKey(key);
            }
        }
        started = false;
        touchId = null;
        currentCell = null;
    };

    canvas.addEventListener('mousedown', start);
    canvas.addEventListener('touchstart', start, { passive: false });
    canvas.addEventListener('mouseup', cancel);
    canvas.addEventListener('mouseleave', cancel);
    canvas.addEventListener('touchend', cancel);
    canvas.addEventListener('touchcancel', cancel);
    canvas.addEventListener('touchmove', (e) => {
        if (touchId === null) return;
        for (let i = 0; i < e.changedTouches.length; i++) {
            if (e.changedTouches[i].identifier === touchId) {
                const touch = e.changedTouches[i];
                const rect = canvas.getBoundingClientRect();
                if (touch.clientX < rect.left || touch.clientX > rect.right ||
                    touch.clientY < rect.top || touch.clientY > rect.bottom) {
                    cancel();
                }
                break;
            }
        }
    }, { passive: false });
}

function startMiningCanvas(ug, row, col) {
    const cell = ug.grid[row][col];
    if (!cell || cell.type === 'empty' || cell.type === 'chest') return;

    const type = cell.type;
    const cellKey = `ug:${row},${col}`;

    const cellCx = col * ug.tile + ug.tile / 2;
    const cellCy = row * ug.tile + ug.tile / 2;
    const playerX = gameState.playerX || window.innerWidth / 2;
    const playerY = gameState.playerY || window.innerHeight / 2;
    const dist = Math.hypot(cellCx - playerX, cellCy - playerY);

    if (dist > 120) {
        showMessage('太远了，靠近后长按以挖掘。');
        return;
    }

    let tool = null, durField = null;

    if (type === 'stoneBlock') {
        if (gameState.resources.hardStonePickaxe > 0 && gameState.hardStonePickaxeDurability > 0) {
            tool = 'hardStonePickaxe';
            durField = 'hardStonePickaxeDurability';
        } else if (gameState.resources.stonePickaxe > 0 && gameState.stonePickaxeDurability > 0) {
            tool = 'stonePickaxe';
            durField = 'stonePickaxeDurability';
        } else if (gameState.resources.pickaxe > 0 && gameState.pickaxeDurability > 0) {
            tool = 'pickaxe';
            durField = 'pickaxeDurability';
        } else {
            showMessage('需要镐来挖掘石块！');
            return;
        }
    } else {
        if (gameState.resources.hardStonePickaxe > 0 && gameState.hardStonePickaxeDurability > 0) {
            tool = 'hardStonePickaxe';
            durField = 'hardStonePickaxeDurability';
        } else if (gameState.resources.stonePickaxe > 0 && gameState.stonePickaxeDurability > 0) {
            tool = 'stonePickaxe';
            durField = 'stonePickaxeDurability';
        } else {
            showMessage('需要石镐来挖掘地底矿石！');
            return;
        }
    }

    const base = (type === 'stoneBlock') ? 5000 : 10000;
    const speedFactor = (tool === 'hardStonePickaxe') ? 10 : ((tool === 'stonePickaxe') ? 2.5 : 1);
    const time = Math.max(200, base / speedFactor);

    if (breakingElements.has(cellKey)) return;

    for (const [key] of breakingElements) {
        if (key !== cellKey) {
            resetBreakingProgressByKey(key);
        } else {
            return;
        }
    }

    for (const [el] of breakingElements) {
        if (el instanceof HTMLElement) {
            resetBreakingProgress(el);
        }
    }

    const progressDiv = document.createElement('div');
    progressDiv.style.cssText = `position:absolute;left:${col * ug.tile}px;top:${row * ug.tile + ug.tile - 6}px;width:0px;height:6px;background:${(type === 'fuelOre') ? '#00FF00' : '#FF8C00'};border-radius:3px;z-index:95;`;
    ug.container.appendChild(progressDiv);

    let progress = 0;
    breakingElements.set(cellKey, {
        interval: setInterval(() => {
            const playerX = gameState.playerX || window.innerWidth / 2;
            const playerY = gameState.playerY || window.innerHeight / 2;
            const cellCx = col * ug.tile + ug.tile / 2;
            const cellCy = row * ug.tile + ug.tile / 2;
            const dist = Math.hypot(cellCx - playerX, cellCy - playerY);

            if (dist > 120) {
                resetBreakingProgressByKey(cellKey);
                return;
            }

            progress += 100;
            progressDiv.style.width = Math.min(ug.tile, (progress / time) * ug.tile) + 'px';

            // 挖掘敲击粒子
            const tickCx = col * ug.tile + ug.tile / 2 + (Math.random() - 0.5) * ug.tile * 0.6;
            const tickCy = row * ug.tile + ug.tile / 2 + (Math.random() - 0.5) * ug.tile * 0.6;
            const spark = document.createElement('div');
            const sparkSize = 3 + Math.random() * 4;
            const sparkColor = type === 'fuelOre' ? '#00FF00' : (type === 'hardStoneOre' ? '#888888' : '#aaaaaa');
            spark.style.cssText = `position:absolute;left:${tickCx - sparkSize / 2}px;top:${tickCy - sparkSize / 2}px;width:${sparkSize}px;height:${sparkSize}px;background:${sparkColor};border-radius:50%;pointer-events:none;z-index:96;box-shadow:0 0 ${sparkSize * 2}px ${sparkColor};opacity:1;transition:transform 300ms ease-out,opacity 300ms ease-out;`;
            ug.container.appendChild(spark);
            const sparkAngle = -Math.PI / 2 + (Math.random() - 0.5) * Math.PI * 0.8;
            const sparkDist = 10 + Math.random() * 20;
            requestAnimationFrame(() => {
                spark.style.transform = `translate(${Math.cos(sparkAngle) * sparkDist}px, ${Math.sin(sparkAngle) * sparkDist}px) scale(0.2)`;
                spark.style.opacity = '0';
            });
            setTimeout(() => spark.remove(), 320);

            if (progress >= time) {
                clearInterval(breakingElements.get(cellKey).interval);
                breakingElements.delete(cellKey);
                progressDiv.remove();

                const rockCtx = ug.rockCanvas.getContext('2d');
                const oreCtx = ug.oreCanvas.getContext('2d');
                rockCtx.clearRect(col * ug.tile, row * ug.tile, ug.tile, ug.tile);
                oreCtx.clearRect(col * ug.tile, row * ug.tile, ug.tile, ug.tile);

                ug.grid[row][col].type = 'empty';

                const breakCx = col * ug.tile + ug.tile / 2;
                const breakCy = row * ug.tile + ug.tile / 2;
                let breakColor = '#aaaaaa';
                let breakName = '石块';
                if (type === 'fuelOre') { breakColor = '#00FF00'; breakName = '燃矿'; }
                else if (type === 'hardStoneOre') { breakColor = '#888888'; breakName = '硬石矿'; }

                for (let i = 0; i < 18; i++) {
                    const p = document.createElement('div');
                    const ps = 4 + Math.random() * 6;
                    const pa = Math.random() * Math.PI * 2;
                    const pd = 20 + Math.random() * 50;
                    const pdur = 500 + Math.random() * 400;
                    p.style.cssText = `position:absolute;left:${breakCx - ps / 2}px;top:${breakCy - ps / 2}px;width:${ps}px;height:${ps}px;background:${breakColor};border-radius:50%;pointer-events:none;z-index:96;box-shadow:0 0 ${ps}px ${breakColor};opacity:1;transition:transform ${pdur}ms cubic-bezier(0.1,0.7,0.3,1),opacity ${pdur}ms ease-out;`;
                    ug.container.appendChild(p);
                    requestAnimationFrame(() => {
                        p.style.transform = `translate(${Math.cos(pa) * pd}px, ${Math.sin(pa) * pd - 15}px) scale(0.3)`;
                        p.style.opacity = '0';
                    });
                    setTimeout(() => p.remove(), pdur + 50);
                }

                const floatEl = document.createElement('div');
                floatEl.textContent = `+1 ${breakName}`;
                floatEl.style.cssText = `position:absolute;left:${breakCx}px;top:${breakCy}px;transform:translate(-50%,0);color:${breakColor};font-size:16px;font-weight:bold;text-shadow:0 0 6px rgba(0,0,0,0.9),1px 1px 3px rgba(0,0,0,0.8);pointer-events:none;z-index:97;opacity:1;transition:transform 800ms cubic-bezier(0.1,0.8,0.3,1),opacity 800ms ease-out;white-space:nowrap;`;
                ug.container.appendChild(floatEl);
                requestAnimationFrame(() => {
                    floatEl.style.transform = 'translate(-50%, -50px)';
                    floatEl.style.opacity = '0';
                });
                setTimeout(() => floatEl.remove(), 850);

                if (type === 'stoneBlock') updateResource('stoneBlock', 1);
                else if (type === 'hardStoneOre') updateResource('hardStoneOre', 1);
                else if (type === 'fuelOre') updateResource('fuelOre', 1);

                if (durField) {
                    updateDurability(durField, (tool === 'hardStonePickaxe') ? 100 : 30);
                }

                updateInventoryPanel();
            }
        }, 100),
        progressBar: progressDiv
    });
}

function resetBreakingProgressByKey(key) {
    const info = breakingElements.get(key);
    if (!info) return;
    if (info.interval) clearInterval(info.interval);
    if (info.progressBar) info.progressBar.remove();
    breakingElements.delete(key);
}

function renderUndergroundCanvases(ug) {
    if (!ug || !ug._rockBgImg) return;

    const fuelOreImg = ug._fuelOreImg || null;
    const hardStoneOreImg = ug._hardStoneOreImg || null;

    const oreCtx = ug.oreCanvas.getContext('2d');
    const rockCtx = ug.rockCanvas.getContext('2d');
    oreCtx.imageSmoothingEnabled = false;
    rockCtx.imageSmoothingEnabled = false;
    oreCtx.clearRect(0, 0, ug.oreCanvas.width, ug.oreCanvas.height);
    rockCtx.clearRect(0, 0, ug.rockCanvas.width, ug.rockCanvas.height);

    for (let r = 0; r < ug.rows; r++) {
        for (let c = 0; c < ug.cols; c++) {
            const cell = ug.grid[r][c];
            const x = c * ug.tile;
            const y = r * ug.tile;

            if (cell.type === 'fuelOre' && fuelOreImg && fuelOreImg.complete) {
                oreCtx.drawImage(fuelOreImg, x, y, ug.tile, ug.tile);
            } else if (cell.type === 'hardStoneOre' && hardStoneOreImg && hardStoneOreImg.complete) {
                oreCtx.drawImage(hardStoneOreImg, x, y, ug.tile, ug.tile);
            }
        }
    }

    rockCtx.drawImage(ug._rockBgImg, 0, 0, ug.rockCanvas.width, ug.rockCanvas.height);

    for (let r = 0; r < ug.rows; r++) {
        for (let c = 0; c < ug.cols; c++) {
            const cell = ug.grid[r][c];
            if (cell.type === 'stoneBlock') continue;
            const x = c * ug.tile;
            const y = r * ug.tile;
            rockCtx.clearRect(x, y, ug.tile, ug.tile);
        }
    }

    ug.imagesLoaded = true;

    if (ug.chestEl) {
        ug.chestEl.remove();
        ug.chestEl = null;
    }

    if (ug.grid[ug.chestRow] && ug.grid[ug.chestRow][ug.chestCol] && ug.grid[ug.chestRow][ug.chestCol].type === 'chest') {
        const chestEl = document.createElement('div');
        chestEl.className = 'ug-tile';
        chestEl.dataset.type = 'chest';
        chestEl.dataset.opened = 'false';
        chestEl.style.cssText = `position:absolute;left:${ug.chestCol * ug.tile}px;top:${ug.chestRow * ug.tile}px;width:${ug.tile}px;height:${ug.tile}px;background:url('assets/images/sprites/chest.jpg') center/100% 100% no-repeat;border:3px solid #FFD700;border-radius:8px;display:flex;align-items:center;justify-content:center;font-size:2rem;z-index:10;box-sizing:border-box;`;
        ug.container.appendChild(chestEl);
        ug.chestEl = chestEl;
    }

    attachUndergroundLongPress(ug.rockCanvas, ug);
}

let resizeTimeout = null;

function resizeUnderground() {
    if (resizeTimeout) clearTimeout(resizeTimeout);

    resizeTimeout = setTimeout(() => {
        if (!gameState.currentHole || !gameState.currentHole.underground) return;

        const underground = gameState.currentHole.underground;
        const tile = underground.tile;
        const newCols = Math.ceil(window.innerWidth / tile);
        const newRows = Math.ceil(window.innerHeight / tile);

        if (newCols === underground.cols && newRows === underground.rows) return;

        const oldGrid = underground.grid;
        const oldCols = underground.cols;
        const oldRows = underground.rows;

        const newGrid = [];
        for (let r = 0; r < newRows; r++) {
            newGrid[r] = [];
            for (let c = 0; c < newCols; c++) {
                if (r < oldRows && c < oldCols) {
                    newGrid[r][c] = oldGrid[r][c];
                } else {
                    const exitCol = newCols - 1;
                    const exitRow = 0;
                    if (r === exitRow && c === exitCol) {
                        newGrid[r][c] = { type: 'empty' };
                    } else if (r === exitRow && c === exitCol - 1) {
                        newGrid[r][c] = { type: 'empty' };
                    } else if (r === exitRow + 1 && c === exitCol) {
                        newGrid[r][c] = { type: 'empty' };
                    } else {
                        const rand = Math.random();
                        if (rand < 0.05) newGrid[r][c] = { type: 'fuelOre' };
                        else if (rand < 0.15) newGrid[r][c] = { type: 'hardStoneOre' };
                        else newGrid[r][c] = { type: 'stoneBlock' };
                    }
                }
            }
        }

        underground.grid = newGrid;
        underground.cols = newCols;
        underground.rows = newRows;
        underground.oreCanvas.width = newCols * tile;
        underground.oreCanvas.height = newRows * tile;
        underground.rockCanvas.width = newCols * tile;
        underground.rockCanvas.height = newRows * tile;

        if (underground.imagesLoaded && underground._rockBgImg) {
            const oreCtx = underground.oreCanvas.getContext('2d');
            const rockCtx = underground.rockCanvas.getContext('2d');
            oreCtx.imageSmoothingEnabled = false;
            rockCtx.imageSmoothingEnabled = false;
            const fuelOreImg = underground._fuelOreImg || new Image();
            const hardStoneOreImg = underground._hardStoneOreImg || new Image();

            for (let r = 0; r < newRows; r++) {
                for (let c = 0; c < newCols; c++) {
                    const cell = newGrid[r][c];
                    const x = c * tile;
                    const y = r * tile;

                    if (cell.type === 'fuelOre' && fuelOreImg.complete) {
                        oreCtx.drawImage(fuelOreImg, x, y, tile, tile);
                    } else if (cell.type === 'hardStoneOre' && hardStoneOreImg.complete) {
                        oreCtx.drawImage(hardStoneOreImg, x, y, tile, tile);
                    }
                }
            }

            rockCtx.drawImage(underground._rockBgImg, 0, 0, underground.rockCanvas.width, underground.rockCanvas.height);

            for (let r = 0; r < newRows; r++) {
                for (let c = 0; c < newCols; c++) {
                    const cell = newGrid[r][c];
                    if (cell.type === 'stoneBlock') continue;
                    const x = c * tile;
                    const y = r * tile;
                    rockCtx.clearRect(x, y, tile, tile);
                }
            }
        }

        if (underground.chestEl) {
            underground.chestEl.style.left = (underground.chestCol * tile) + 'px';
            underground.chestEl.style.top = (underground.chestRow * tile) + 'px';
        }

        const player = document.getElementById('phaser-player');
        if (player) {
            gameState.playerX = Math.min(gameState.playerX, window.innerWidth - 50);
            gameState.playerY = Math.min(gameState.playerY, window.innerHeight - 50);
            player.style.left = gameState.playerX - 73 + 'px';
            player.style.top = gameState.playerY - 73 + 'px';
        }

        updateHoleButtons();
    }, 200);
}

function startMiningUnderground(tileEl) {
    const type = tileEl.dataset.type;
    if (!type) return;
    
    if (type === 'chest') {
        const playerX = gameState.playerX || window.innerWidth / 2;
        const playerY = gameState.playerY || window.innerHeight / 2;
        
        const rect = tileEl.getBoundingClientRect();
        const centerX = rect.left + rect.width / 2;
        const centerY = rect.top + rect.height / 2;
        const dist = Math.hypot(centerX - playerX, centerY - playerY);
        
        if (dist > 120) {
            showMessage('太远了，靠近后按 F 打开宝箱。');
            return;
        }
        
        if (tileEl.dataset.opened === 'true') {
            showMessage('宝箱已经被打开了！');
            return;
        }
        
        tileEl.dataset.opened = 'true';
        tileEl.remove();

        const ug = gameState.currentHole && gameState.currentHole.underground;
        if (ug && ug.grid && ug.chestRow != null && ug.chestCol != null) {
            if (ug.grid[ug.chestRow] && ug.grid[ug.chestRow][ug.chestCol]) {
                ug.grid[ug.chestRow][ug.chestCol].type = 'empty';
            }
        }

        gameState.resources.gold = (gameState.resources.gold || 0) + 1;
        updateInventoryPanel();
        showMessage('获得了 1 金币！');
        updateHoleButtons();
        return;
    }
    
    const playerX = gameState.playerX || window.innerWidth / 2;
    const playerY = gameState.playerY || window.innerHeight / 2;
    
    const rect = tileEl.getBoundingClientRect();
    const centerX = rect.left + rect.width / 2;
    const centerY = rect.top + rect.height / 2;
    const dist = Math.hypot(centerX - playerX, centerY - playerY);
    
    if (dist > 120) {
        showMessage('太远了，靠近后长按以挖掘。');
        return;
    }
    
    let tool = null, durField = null;
    
    if (type === 'stoneBlock') {
        if (gameState.resources.hardStonePickaxe > 0 && gameState.hardStonePickaxeDurability > 0) {
            tool = 'hardStonePickaxe';
            durField = 'hardStonePickaxeDurability';
        } else if (gameState.resources.stonePickaxe > 0 && gameState.stonePickaxeDurability > 0) {
            tool = 'stonePickaxe';
            durField = 'stonePickaxeDurability';
        } else if (gameState.resources.pickaxe > 0 && gameState.pickaxeDurability > 0) {
            tool = 'pickaxe';
            durField = 'pickaxeDurability';
        } else {
            showMessage('需要镐来挖掘石块！');
            return;
        }
    } else {
        if (gameState.resources.hardStonePickaxe > 0 && gameState.hardStonePickaxeDurability > 0) {
            tool = 'hardStonePickaxe';
            durField = 'hardStonePickaxeDurability';
        } else if (gameState.resources.stonePickaxe > 0 && gameState.stonePickaxeDurability > 0) {
            tool = 'stonePickaxe';
            durField = 'stonePickaxeDurability';
        } else {
            showMessage('需要石镐来挖掘地底矿石！');
            return;
        }
    }
    
    const base = (type === 'stoneBlock') ? 5000 : 10000;
    const speedFactor = (tool === 'hardStonePickaxe') ? 10 : ((tool === 'stonePickaxe') ? 2.5 : 1);
    const time = Math.max(200, base / speedFactor);
    
    if (breakingElements.has(tileEl)) return;
    
    for (const [el] of breakingElements) {
        if (el !== tileEl) {
            resetBreakingProgress(el);
        }
    }
    
    let progress = 0;
    const progressDiv = document.createElement('div');
    progressDiv.className = 'progress-fill';
    progressDiv.style.position = 'absolute';
    progressDiv.style.left = '0';
    progressDiv.style.bottom = '0';
    progressDiv.style.height = '6px';
    progressDiv.style.background = (type === 'fuelOre') ? '#00FF00' : '#FF8C00';
    progressDiv.style.width = '0%';
    progressDiv.style.borderRadius = '3px';
    tileEl.appendChild(progressDiv);
    
    breakingElements.set(tileEl, {
        interval: setInterval(() => {
            const playerX = gameState.playerX || window.innerWidth / 2;
            const playerY = gameState.playerY || window.innerHeight / 2;
            const rect = tileEl.getBoundingClientRect();
            const centerX = rect.left + rect.width / 2;
            const centerY = rect.top + rect.height / 2;
            const dist = Math.hypot(centerX - playerX, centerY - playerY);
            
            if (dist > 120) {
                resetBreakingProgress(tileEl);
                return;
            }
            
            progress += 100;
            progressDiv.style.width = Math.min(100, (progress / time) * 100) + '%';
            
            if (progress >= time) {
                clearInterval(breakingElements.get(tileEl).interval);
                breakingElements.delete(tileEl);
                tileEl.remove();
                
                if (type === 'stoneBlock') updateResource('stoneBlock', 1);
                else if (type === 'hardStoneOre') updateResource('hardStoneOre', 1);
                else if (type === 'fuelOre') updateResource('fuelOre', 1);
                
                if (durField) {
                    updateDurability(durField, (tool === 'hardStonePickaxe') ? 100 : 30);
                }
                
                updateInventoryPanel();
            }
        }, 100)
    });
}

function smeltHardStone() {
    if (!checkNear('.furnace')) {
        showMessage('需要靠近熔炉才能烧制硬石块！');
        return;
    }
    if ((gameState.resources.hardStoneOre || 0) < 1) {
        showMessage('没有硬石矿可烧制！');
        return;
    }
    if (gameState.furnaceFuel < 200) {
        showMessage('燃料不足，至少需要200燃料！');
        return;
    }
    
    gameState.resources.hardStoneOre--;
    gameState.resources.hardStoneBlock = (gameState.resources.hardStoneBlock || 0) + 1;
    gameState.furnaceFuel -= 200;
    
    updateFurnaceFuelUI();
    updateInventoryPanel();
    showMessage('烧制成功，获得1个硬石块！');
}

function smeltCookedMeat() {
    if (!checkNear('.furnace')) {
        showMessage('需要靠近熔炉才能熔炼！');
        return;
    }
    if (gameState.resources.rawMeat < 1) {
        showMessage("没有生肉可熔炼！");
        return;
    }
    if (gameState.furnaceFuel < 100) {
        showMessage("燃料不足！需要至少100燃料");
        return;
    }
    
    updateResource('rawMeat', -1);
    gameState.furnaceFuel -= 100;
    updateResource('cookedMeat', 1);
    
    updateInventoryPanel();
    updateFurnaceFuelUI();
    showMessage("熔炼成功，获得1个熟肉！");
    updateCraftingButtons();
}

function updateFurnaceFuelUI() {
    const el = document.getElementById('furnace-fuel-value');
    if (el) el.textContent = String(gameState.furnaceFuel || 0);
}

function showFuelPopup() {
    const popup = document.getElementById('fuel-popup');
    const options = document.getElementById('fuel-options');
    
    if (!popup || !options) {
        console.warn('showFuelPopup: required DOM elements missing');
        return;
    }
    
    options.innerHTML = '';
    
    const fuels = [
        { key: 'fuelOre', name: '燃矿', value: 1000, color: '#ff8800' },
        { key: 'branch', name: '木棍', value: 20, color: '#A0522D' },
        { key: 'twig', name: '树枝', value: 60, color: '#8B5A2B' },
        { key: 'wood', name: '木材', value: 200, color: '#A0522D' }
    ];
    
    let hasFuel = false;
    
    fuels.forEach(fuel => {
        if ((gameState.resources[fuel.key] || 0) > 0) {
            hasFuel = true;
            const btn = document.createElement('button');
            btn.className = 'btn';
            btn.style.margin = '5px';
            btn.innerHTML = `<span style="background:${fuel.color};color:#fff;padding:4px 10px;border-radius:8px;">${fuel.name}</span> ×1 → <span style="color:#FF8C00;">+${fuel.value}燃料</span>`;
            
            btn.onclick = () => {
                updateResource(fuel.key, -1);
                gameState.furnaceFuel += fuel.value;
                updateFurnaceFuelUI();
                updateInventoryPanel();
                showMessage(`${fuel.name} 已添加，获得 +${fuel.value} 燃料`);
                showFuelPopup();
                updateCraftingButtons();
            };
            
            options.appendChild(btn);
        }
    });
    
    if ((gameState.resources.fuelOre || 0) > 0) {
        const bulk = document.createElement('button');
        bulk.className = 'btn';
        bulk.style.margin = '5px';
        bulk.textContent = '全部转换燃矿';
        
        bulk.onclick = () => {
            const cnt = gameState.resources.fuelOre;
            if (cnt <= 0) return;
            updateResource('fuelOre', -cnt);
            gameState.furnaceFuel += cnt * 1000;
            updateFurnaceFuelUI();
            updateInventoryPanel();
            showMessage(`已转换 ${cnt} 个燃矿，获得 +${cnt * 1000} 燃料`);
            showFuelPopup();
            updateCraftingButtons();
        };
        
        options.appendChild(bulk);
    }
    
    if (!hasFuel) {
        options.innerHTML = '<div style="color:#fff;text-align:center;">没有可用燃料物品</div>';
    }
    
    popup.style.display = 'block';
    openPanel('fuel-popup');
}

function checkNearCraftingTable() {
    gameState.nearCraftingTable = checkNear('.crafting-table');
    return gameState.nearCraftingTable;
}

function checkRefreshButtonPosition() {
    if (gameState.controlMode !== 'button') {
        document.getElementById('refresh-button').style.display = 'none';
        return;
    }
    
    const playerX = gameState.playerX || window.innerWidth / 2;
    const playerY = gameState.playerY || window.innerHeight / 2;
    
    const nearLeft = playerX < 100;
    const nearBottom = (window.innerHeight - playerY) < 100;
    
    document.getElementById('refresh-button').style.display = (nearLeft && nearBottom) ? 'flex' : 'none';
}

function updateActionButtonHighlight() {
    const actionButtons = ['dig-hole', 'place-ladder', 'open-chest-btn', 'reclaim-table-btn', 'reclaim-furnace-btn'];
    const visibleButtons = actionButtons.filter(id => {
        const btn = document.getElementById(id);
        return btn && btn.style.display !== 'none';
    });
    
    actionButtons.forEach(id => {
        const btn = document.getElementById(id);
        if (btn) {
            btn.style.outline = '';
            btn.style.transform = '';
        }
    });
    
    if (visibleButtons.length > 0) {
        let highlightedId = gameState.highlightedActionBtn;
        
        if (!highlightedId || !visibleButtons.includes(highlightedId)) {
            highlightedId = visibleButtons[0];
            gameState.highlightedActionBtn = highlightedId;
        }
        
        const btn = document.getElementById(highlightedId);
        if (btn) {
            btn.style.outline = '3px solid #FFD700';
            btn.style.outlineOffset = '3px';
            btn.style.transform = 'scale(1.1)';
            btn.style.transition = 'transform 0.1s, outline 0.1s';
        }
    }
}

function updateHoleButtons() {
    const digBtn = document.getElementById('dig-hole');
    const placeBtn = document.getElementById('place-ladder');
    
    if (isAnyPanelOpen()) {
        if (digBtn) digBtn.style.display = 'none';
        if (placeBtn) placeBtn.style.display = 'none';
        const chestBtn = document.getElementById('open-chest-btn');
        if (chestBtn) chestBtn.style.display = 'none';
        return;
    }
    
    const hasPickaxe = gameState.resources.hardStonePickaxe > 0 && gameState.hardStonePickaxeDurability >= 1 ||
                       gameState.resources.stonePickaxe > 0 && gameState.stonePickaxeDurability >= 1 ||
                       gameState.resources.pickaxe > 0 && gameState.pickaxeDurability >= 2;
    
    if (gameState.controlMode === 'button' && hasPickaxe && !gameState.undergroundOpen) {
        digBtn.style.display = 'block';
    } else {
        digBtn.style.display = 'none';
    }
    
    let nearHole = null;
    const playerX = gameState.playerX || window.innerWidth / 2;
    const playerY = gameState.playerY || window.innerHeight / 2;
    
    for (const h of gameState.holes) {
        const d = Math.hypot(h.x - playerX, h.y - playerY);
        if (d < 80) {
            nearHole = h;
            break;
        }
    }
    
    if (nearHole && !nearHole.hasLadder && gameState.resources.ladder > 0 && !gameState.undergroundOpen) {
        placeBtn.style.display = 'block';
    } else {
        placeBtn.style.display = 'none';
    }
    
    const chestBtn = document.getElementById('open-chest-btn');
    if (gameState.undergroundOpen && gameState.currentHole && gameState.currentHole.underground) {
        const chests = gameState.currentHole.underground.container.querySelectorAll('.ug-tile[data-type="chest"][data-opened="false"]');
        let nearChest = null;
        let minDist = 120;
        chests.forEach(chest => {
            const rect = chest.getBoundingClientRect();
            const centerX = rect.left + rect.width / 2;
            const centerY = rect.top + rect.height / 2;
            const dist = Math.hypot(centerX - playerX, centerY - playerY);
            if (dist < minDist) {
                minDist = dist;
                nearChest = chest;
            }
        });
        if (nearChest) {
            chestBtn.style.display = 'block';
            chestBtn.onclick = () => startMiningUnderground(nearChest);
        } else {
            chestBtn.style.display = 'none';
        }
    } else {
        if (chestBtn) chestBtn.style.display = 'none';
    }
    
    updateActionButtonHighlight();
}

function refreshMap() {
    if (gameState.refreshCooldown) return;
    gameState.refreshCooldown = true;
    setTimeout(() => { gameState.refreshCooldown = false; }, 1000);
    
    gameState.collisionEnabled = false;
    
    if (gameState.currentMap === 'surface') {
        gameState.refreshCounts.surface++;
        
        const container = document.getElementById('game-container');
        if (container) {
            container.querySelectorAll('.game-element').forEach(el => {
                if (el.id !== 'phaser-player') el.remove();
            });
        }
        
        gameState.gridOccupied.clear();
        generateRandomSurfaceElements();
        
        gameState.playerX = window.innerWidth - 70;
        gameState.playerY = 50;
    } else if (gameState.currentMap === 'underground' && gameState.currentHole) {
        gameState.refreshCounts.underground = (gameState.refreshCounts.underground || 0) + 1;

        const undergroundData = gameState.currentHole.underground;
        const player = document.getElementById('phaser-player');
        if (undergroundData) {
            if (player) player.remove();

            undergroundData.container.innerHTML = '';

            const tile = undergroundData.tile;
            const cols = undergroundData.cols;
            const rows = undergroundData.rows;

            const newGrid = [];
            for (let r = 0; r < rows; r++) {
                newGrid[r] = [];
                for (let c = 0; c < cols; c++) {
                    newGrid[r][c] = { type: 'stoneBlock' };
                }
            }

            const exitCol = cols - 1;
            const exitRow = 0;
            newGrid[exitRow][exitCol].type = 'empty';
            if (exitCol - 1 >= 0) newGrid[exitRow][exitCol - 1].type = 'empty';
            if (exitRow + 1 < rows) newGrid[exitRow + 1][exitCol].type = 'empty';

            const newChestRow = Math.floor(Math.random() * (rows - 2)) + 1;
            const newChestCol = Math.floor(Math.random() * (cols - 2)) + 1;
            newGrid[newChestRow][newChestCol].type = 'chest';

            for (let r = 0; r < rows; r++) {
                for (let c = 0; c < cols; c++) {
                    if (newGrid[r][c].type !== 'stoneBlock') continue;
                    const rand = Math.random();
                    if (rand < 0.05) newGrid[r][c].type = 'fuelOre';
                    else if (rand < 0.15) newGrid[r][c].type = 'hardStoneOre';
                }
            }

            undergroundData.grid = newGrid;
            undergroundData.chestRow = newChestRow;
            undergroundData.chestCol = newChestCol;

            const newOreCanvas = document.createElement('canvas');
            newOreCanvas.width = cols * tile;
            newOreCanvas.height = rows * tile;
            newOreCanvas.style.cssText = 'position:absolute;top:0;left:0;pointer-events:none;z-index:91;';
            undergroundData.container.appendChild(newOreCanvas);

            const newRockCanvas = document.createElement('canvas');
            newRockCanvas.width = cols * tile;
            newRockCanvas.height = rows * tile;
            newRockCanvas.style.cssText = 'position:absolute;top:0;left:0;z-index:92;';
            undergroundData.container.appendChild(newRockCanvas);

            undergroundData.oreCanvas = newOreCanvas;
            undergroundData.rockCanvas = newRockCanvas;
            undergroundData.imagesLoaded = false;

            if (undergroundData._rockBgImg && undergroundData._rockBgImg.complete) {
                renderUndergroundCanvases(undergroundData);
            } else {
                const rockBgImg = new Image();
                rockBgImg.src = 'assets/images/tiles/stone_block_bg.jpg';
                const fuelOreImg = new Image();
                fuelOreImg.src = 'assets/images/tiles/fuel_ore.jpg';
                const hardStoneOreImg = new Image();
                hardStoneOreImg.src = 'assets/images/tiles/hard_stone_ore.jpg';
                const allImages = [rockBgImg, fuelOreImg, hardStoneOreImg];
                let loadedCount = 0;
                allImages.forEach(img => {
                    if (img.complete) {
                        loadedCount++;
                    } else {
                        img.onload = () => {
                            loadedCount++;
                            if (loadedCount === allImages.length) {
                                undergroundData._rockBgImg = rockBgImg;
                                undergroundData._fuelOreImg = fuelOreImg;
                                undergroundData._hardStoneOreImg = hardStoneOreImg;
                                renderUndergroundCanvases(undergroundData);
                            }
                        };
                    }
                });
                if (loadedCount === allImages.length) {
                    undergroundData._rockBgImg = rockBgImg;
                    undergroundData._fuelOreImg = fuelOreImg;
                    undergroundData._hardStoneOreImg = hardStoneOreImg;
                    renderUndergroundCanvases(undergroundData);
                }
            }

            if (player) {
                player.style.visibility = 'visible';
                player.style.display = 'block';
                player.style.opacity = '1';
                undergroundData.container.appendChild(player);
            }
        }

        gameState.playerX = (gameState.currentHole.underground.cols - 0.5) * gameState.currentHole.underground.tile;
        gameState.playerY = gameState.currentHole.underground.tile / 2;
    }
    
    updatePlayerPosition();
    
    setTimeout(() => {
        gameState.collisionEnabled = true;
    }, 100);
}

function generateRandomSurfaceElements() {
    for (let i = 0; i < 3; i++) createTree();
    for (let i = 0; i < 5; i++) createElement('stone');
    for (let i = 0; i < 3; i++) createElement('bush');
    for (let i = 0; i < 2; i++) createAnimal();
}

function createTree() {
    const attempts = 100;
    const maxCol = Math.floor(window.innerWidth / GRID_SIZE) - 1;
    const maxRow = Math.floor(window.innerHeight / GRID_SIZE) - 3;
    
    for (let i = 0; i < attempts; i++) {
        const col = Math.floor(Math.random() * (maxCol + 1));
        const row = Math.floor(Math.random() * (maxRow + 1));
        
        if (!isGridCellOccupied(col, row, GRID_SIZE, GRID_SIZE * 3)) {
            occupyGridCells(col, row, GRID_SIZE, GRID_SIZE * 3);
            
            const x = col * GRID_SIZE;
            const y = row * GRID_SIZE;
            
            createElement('tree-leaf', x - 75, y - 75, 200, 200);
            createElement('tree-trunk', x + 15, y + GRID_SIZE, 20, GRID_SIZE * 2);
            return;
        }
    }
}

function createAnimal() {
    const attempts = 100;
    const maxCol = Math.floor(window.innerWidth / GRID_SIZE) - 1;
    const maxRow = Math.floor(window.innerHeight / GRID_SIZE) - 1;
    
    for (let i = 0; i < attempts; i++) {
        const col = Math.floor(Math.random() * (maxCol + 1));
        const row = Math.floor(Math.random() * (maxRow + 1));
        
        if (!isGridCellOccupied(col, row, GRID_SIZE, GRID_SIZE)) {
            occupyGridCells(col, row, GRID_SIZE, GRID_SIZE);
            
            const x = col * GRID_SIZE;
            const y = row * GRID_SIZE;
            
            const el = document.createElement('div');
            el.className = 'animal game-element';
            el.style.left = x + 'px';
            el.style.top = y + 'px';
            el.textContent = '4';
            
            const container = document.getElementById('game-container');
            if (container) container.appendChild(el);

            const animalObj = { el, x, y, hp: 4 };
            gameState.animals.push(animalObj);

            el.addEventListener('click', () => {
                const playerX = gameState.playerX || window.innerWidth / 2;
                const playerY = gameState.playerY || window.innerHeight / 2;
                
                const rect = el.getBoundingClientRect();
                const centerX = rect.left + rect.width / 2;
                const centerY = rect.top + rect.height / 2;
                const dist = Math.hypot(centerX - playerX, centerY - playerY);
                
                if (dist > 80) return;
                
                animalObj.hp -= gameState.attack;

                hitFlash(el);
                spawnParticles(centerX, centerY, '#ff4444', 8, 3, [3, 6]);
                floatingText(centerX, centerY - 20, `-${gameState.attack}`, '#ff4444', 22);
                screenShake(3, 150);
                
                if (animalObj.hp <= 0) {
                    const col = Math.floor(animalObj.x / GRID_SIZE);
                    const row = Math.floor(animalObj.y / GRID_SIZE);
                    freeGridCells(col, row, GRID_SIZE, GRID_SIZE);
                    
                    spawnParticles(centerX, centerY, '#ff8c00', 20, 5, [5, 10]);
                    spawnParticles(centerX, centerY, '#ffcc00', 10, 4, [3, 6]);
                    floatingText(centerX, centerY - 10, '+1 生肉', '#FFD700', 18);
                    screenShake(6, 250);
                    
                    el.remove();
                    gameState.animals = gameState.animals.filter(a => a !== animalObj);
                    updateResource('rawMeat', 1);
                    updateInventoryPanel();
                } else {
                    el.textContent = animalObj.hp;
                }
                
                if (gameState.resources.hardStoneSword > 0) {
                    updateDurability('hardStoneSwordDurability', 150);
                    updateInventoryPanel();
                } else if (gameState.resources.woodenSword > 0) {
                    updateDurability('woodenSwordDurability', 30);
                    updateInventoryPanel();
                }
            });
            return;
        }
    }
}

function startAnimalMovement() {
    const COLLISION_SIZE = 20;
    const BOUNCE_DIST = 30;
    
    setInterval(() => {
        if (gameState.gamePaused || gameState.uiPanelOpen) return;
        gameState.animals.forEach(animal => {
            let angle = Math.random() * 2 * Math.PI;
            let dist = 20 + Math.random() * 30;
            let newX = animal.x + Math.cos(angle) * dist;
            let newY = animal.y + Math.sin(angle) * dist;
            
            newX = Math.max(0, Math.min(window.innerWidth - 40, newX));
            newY = Math.max(0, Math.min(window.innerHeight - 40, newY));
            
            const playerX = gameState.playerX || window.innerWidth / 2;
            const playerY = gameState.playerY || window.innerHeight / 2;
            const distToPlayer = Math.hypot(newX - playerX, newY - playerY);
            if (distToPlayer < 50) {
                return;
            }
            
            if (isBlockedAt(newX + 10, newY + 10, COLLISION_SIZE, COLLISION_SIZE, animal.el)) {
                const bounceAngle = findBounceAngle(animal.x, animal.y, newX, newY);
                newX = animal.x + Math.cos(bounceAngle) * BOUNCE_DIST;
                newY = animal.y + Math.sin(bounceAngle) * BOUNCE_DIST;
                newX = Math.max(0, Math.min(window.innerWidth - 40, newX));
                newY = Math.max(0, Math.min(window.innerHeight - 40, newY));
                
                if (isBlockedAt(newX + 10, newY + 10, COLLISION_SIZE, COLLISION_SIZE, animal.el)) {
                    return;
                }
            }
            
            const duration = 400;
            const startX = animal.x;
            const startY = animal.y;
            const deltaX = newX - startX;
            const deltaY = newY - startY;
            let startTime = null;
            
            function animateAnimalMove(ts) {
                if (!startTime) startTime = ts;
                const progress = Math.min(1, (ts - startTime) / duration);
                const eased = 1 - Math.pow(1 - progress, 3);
                animal.x = startX + deltaX * eased;
                animal.y = startY + deltaY * eased;
                animal.el.style.left = animal.x + 'px';
                animal.el.style.top = animal.y + 'px';
                if (progress < 1) {
                    requestAnimationFrame(animateAnimalMove);
                } else {
                    animal.x = newX;
                    animal.y = newY;
                    animal.el.style.left = animal.x + 'px';
                    animal.el.style.top = animal.y + 'px';
                }
            }
            
            requestAnimationFrame(animateAnimalMove);
        });
    }, 1500);
}

function findBounceAngle(fromX, fromY, toX, toY) {
    const dx = toX - fromX;
    const dy = toY - fromY;
    const originalAngle = Math.atan2(dy, dx);
    
    const candidates = [
        originalAngle + Math.PI / 4,
        originalAngle - Math.PI / 4,
        originalAngle + Math.PI / 2,
        originalAngle - Math.PI / 2,
        originalAngle + 3 * Math.PI / 4,
        originalAngle - 3 * Math.PI / 4,
        originalAngle + Math.PI
    ];
    
    let bestAngle = originalAngle;
    let bestDistance = -1;
    
    const COLLISION_SIZE = 20;
    
    for (const angle of candidates) {
        const testX = fromX + Math.cos(angle) * 30;
        const testY = fromY + Math.sin(angle) * 30;
        
        if (testX >= 0 && testX <= window.innerWidth - 40 &&
            testY >= 0 && testY <= window.innerHeight - 40) {
            
            if (!isBlockedAt(testX + 10, testY + 10, COLLISION_SIZE, COLLISION_SIZE)) {
                const dist = Math.abs(Math.cos(angle));
                if (dist > bestDistance) {
                    bestDistance = dist;
                    bestAngle = angle;
                }
            }
        }
    }
    
    return bestAngle;
}

function showButtonControls() {
    if (gameState.controlMode !== 'button') return;
    
    const crafting = document.getElementById('crafting-ui');
    const inventoryPanel = document.getElementById('inventory-panel');
    const mapUI = document.getElementById('map-ui');
    const fuelPopup = document.getElementById('fuel-popup');
    const commandContainer = document.getElementById('command-container');
    const messagePopup = document.getElementById('message-popup');
    
    const isAnyOpen = 
        (crafting && crafting.style.display === 'block') ||
        (inventoryPanel && inventoryPanel.style.display === 'flex') ||
        (mapUI && mapUI.style.display === 'block') ||
        (fuelPopup && fuelPopup.style.display === 'block') ||
        (commandContainer && commandContainer.style.display === 'block') ||
        (messagePopup && messagePopup.style.display === 'block');
    
    if (isAnyOpen) {
        const actionButtons = ['dig-hole', 'place-ladder', 'open-chest-btn', 'reclaim-table-btn', 'reclaim-furnace-btn'];
        actionButtons.forEach(id => {
            const el = document.getElementById(id);
            if (el) el.style.display = 'none';
        });
        return;
    }
    
    document.getElementById('touch-controls').style.display = 'flex';
    document.getElementById('touch-joystick-area').style.display = 'block';
    document.getElementById('inventory-btn').style.display = 'flex';
    document.getElementById('touch-crafting').style.display = 'flex';
    document.getElementById('refresh-button').style.display = 'flex';
    document.getElementById('map-btn').style.display = 'flex';
    
    const commandBtn = document.getElementById('command-btn');
    if (commandBtn && gameState.cheatModeEnabled) commandBtn.style.display = 'flex';
    
    updateHoleButtons();
    updateReclaimTableBtn();
    updateReclaimFurnaceBtn();
    
    checkRefreshButtonPosition();
}

function isAnyPanelOpen() {
    const panels = ['crafting-ui', 'inventory-panel', 'map-ui', 'fuel-popup', 'command-container', 'message-popup'];
    for (const id of panels) {
        const el = document.getElementById(id);
        if (el && window.getComputedStyle(el).display !== 'none') {
            return true;
        }
    }
    return false;
}

function updateReclaimTableBtn() {
    const reclaimBtn = document.getElementById('reclaim-table-btn');
    if (isAnyPanelOpen()) {
        reclaimBtn.style.display = 'none';
        return;
    }
    reclaimBtn.style.display = checkNear('.crafting-table') ? 'block' : 'none';
    updateActionButtonHighlight();
}

function updateReclaimFurnaceBtn() {
    const furnaceBtn = document.getElementById('reclaim-furnace-btn');
    if (isAnyPanelOpen()) {
        furnaceBtn.style.display = 'none';
        return;
    }
    furnaceBtn.style.display = checkNear('.furnace') ? 'block' : 'none';
    updateActionButtonHighlight();
}

function bindReclaimTableBtn() {
    const reclaimBtn = document.getElementById('reclaim-table-btn');
    reclaimBtn.onclick = () => {
        let found = false;
        document.querySelectorAll('.crafting-table').forEach(table => {
            const playerX = gameState.playerX || window.innerWidth / 2;
            const playerY = gameState.playerY || window.innerHeight / 2;
            
            const rect = table.getBoundingClientRect();
            const centerX = rect.left + rect.width / 2;
            const centerY = rect.top + rect.height / 2;
            const d = Math.hypot(centerX - playerX, centerY - playerY);
            
            if (d < 100 && !found) {
                const rect = table.getBoundingClientRect();
                table.remove();
                freeGridCells(Math.floor(rect.left / GRID_SIZE), Math.floor(rect.top / GRID_SIZE), 60, 60);
                updateResource('craftingTable', 1);
                updateInventoryPanel();
                found = true;
            }
        });
    };
}

function bindReclaimFurnaceBtn() {
    const furnaceBtn = document.getElementById('reclaim-furnace-btn');
    furnaceBtn.onclick = () => {
        let found = false;
        document.querySelectorAll('.furnace').forEach(furnace => {
            const playerX = gameState.playerX || window.innerWidth / 2;
            const playerY = gameState.playerY || window.innerHeight / 2;
            
            const rect = furnace.getBoundingClientRect();
            const centerX = rect.left + rect.width / 2;
            const centerY = rect.top + rect.height / 2;
            const d = Math.hypot(centerX - playerX, centerY - playerY);
            
            if (d < 100 && !found) {
                const rect = furnace.getBoundingClientRect();
                furnace.remove();
                freeGridCells(Math.floor(rect.left / GRID_SIZE), Math.floor(rect.top / GRID_SIZE), 60, 60);
                updateResource('furnace', 1);
                updateInventoryPanel();
                found = true;
            }
        });
    };
}

function setupFurnacePlaceAndReclaim() {
    let furnaceBtn = document.getElementById('reclaim-furnace-btn');
    
    if (!furnaceBtn) {
        furnaceBtn = document.createElement('button');
        furnaceBtn.id = 'reclaim-furnace-btn';
        furnaceBtn.className = 'btn';
        furnaceBtn.style.position = 'fixed';
        furnaceBtn.style.bottom = '160px';
        furnaceBtn.style.right = '20px';
        furnaceBtn.style.zIndex = '101';
        furnaceBtn.style.display = 'none';
        furnaceBtn.textContent = '收回熔炉';
        document.body.appendChild(furnaceBtn);
    }
    
    furnaceBtn.onclick = () => {
        let found = false;
        document.querySelectorAll('.furnace').forEach(furnace => {
            const playerX = gameState.playerX || window.innerWidth / 2;
            const playerY = gameState.playerY || window.innerHeight / 2;
            
            const rect = furnace.getBoundingClientRect();
            const centerX = rect.left + rect.width / 2;
            const centerY = rect.top + rect.height / 2;
            const d = Math.hypot(centerX - playerX, centerY - playerY);
            
            if (d < 100 && !found) {
                furnace.remove();
                updateResource('furnace', 1);
                updateInventoryPanel();
                found = true;
            }
        });
        
        if (!found) showMessage("请靠近熔炉再点击收回！");
    };
}

function initGame() {
    generateRandomSurfaceElements();
    setupEventListeners();
    setupJoystick();
    updateInventoryPanel();
    updateHealthBar();
    
    const reclaimBtn = document.getElementById('reclaim-table-btn');
    if (reclaimBtn) {
        reclaimBtn.className = 'btn';
        reclaimBtn.style.display = 'none';
    }
    
    bindReclaimTableBtn();
    bindReclaimFurnaceBtn();
    setupFurnacePlaceAndReclaim();
    
    const craftFurnaceBtn = document.getElementById('craft-furnace');
    if (craftFurnaceBtn) {
        craftFurnaceBtn.addEventListener('click', () => {
            if (gameState.resources.stone >= 10 && checkNearCraftingTable()) {
                const pos = findNearbyFreePosition(60, 60);
                if (!pos) {
                    showMessage('周围没有空位，无法放置！');
                    return;
                }
                updateResource('stone', -10);
                const f = createElement('furnace', pos.x, pos.y, 60, 60);
                f.textContent = '熔炉';
                updateInventoryPanel();
                updateCraftingButtons();
                resolveCollision();
                
                const crafting = document.getElementById('crafting-ui');
                if (crafting && crafting.style.display === 'block') {
                    closePanel('crafting-ui');
                }
                updateReclaimFurnaceBtn();
                showMessage("制作了一个熔炉！");
            } else if (gameState.resources.stone < 10) {
                showMessage("材料不足！需要10个石子");
            } else {
                showMessage("需要靠近合成台才能制作熔炉！");
            }
        });
    }
    
    const closeFuelBtn = document.getElementById('close-fuel-popup');
    if (closeFuelBtn) {
        closeFuelBtn.onclick = () => {
            closePanel('fuel-popup');
            updateCraftingButtons();
        };
    }
}

function setupEventListeners() {
    bindBtn('craft-wooden-sword', craftWoodenSword);
    bindBtn('craft-axe', craftAxe);
    bindBtn('craft-table', craftTable);
    bindBtn('craft-pickaxe', craftPickaxe);
    bindBtn('craft-vine', craftVine);
    bindBtn('craft-branch', craftBranch);
    bindBtn('craft-ladder', craftLadder);
    bindBtn('craft-stone-pickaxe', craftStonePickaxe);
    bindBtn('dig-hole', digHole);
    bindBtn('place-ladder', placeLadder);

    bindBtn('prev-page', () => { craftingPagination.prevPage(); renderCraftingUI(); });
    bindBtn('next-page', () => { craftingPagination.nextPage(); renderCraftingUI(); });
    bindBtn('refresh-button', () => { if (gameState.controlMode === 'button') refreshMap(); });
    bindBtn('inventory-btn', toggleInventory);
    bindBtn('touch-crafting', () => {
        if (gameState.controlMode === 'button') {
            gameState.craftingPage = 1;
            renderCraftingUI();
            const crafting = document.getElementById('crafting-ui');
            if (crafting) togglePopup(crafting);
        }
    });
    bindBtn('close-message', () => {
        const messagePopup = document.getElementById('message-popup');
        messagePopup.style.display = 'none';
        gameState.messageVisible = false;
        if (messageAutoCloseTimer) {
            clearTimeout(messageAutoCloseTimer);
            messageAutoCloseTimer = null;
        }

        gameState.uiPanelOpen = isAnyPanelOpen();

        if (!isAnyPanelOpen()) {
            gameState.gamePaused = false;
            if (gameState.controlMode === 'button') {
                restoreGameButtons();
            }
            updateReclaimTableBtn();
            updateReclaimFurnaceBtn();
            updateHoleButtons();
        } else {
            gameState.gamePaused = true;
            const crafting = document.getElementById('crafting-ui');
            if (crafting && crafting.style.display === 'block') {
                renderCraftingUI();
                if (gameState.controlMode === 'button') {
                    hideGameButtons();
                    const touchBtn = document.getElementById('touch-crafting');
                    if (touchBtn) {
                        touchBtn.style.display = 'flex';
                        touchBtn.style.zIndex = '100';
                    }
                }
            }
        }
    });
    bindBtn('map-btn', openMapUI);
    bindBtn('close-map-btn', closeMapUI);
    
    document.querySelectorAll('.map-item').forEach(item => {
        item.addEventListener('click', () => {
            if (!item.classList.contains('disabled')) {
                switchMap(item.dataset.map);
            }
        });
    });
    
    const healthBar = document.getElementById('player-health-bar');
    if (healthBar) {
        healthBar.addEventListener('click', toggleAllButtons);
        healthBar.addEventListener('touchstart', (e) => { e.preventDefault(); toggleAllButtons(); }, { passive: false });
    }
    
    const startGame = (mode) => {
        document.getElementById('start-screen').style.display = 'none';
        document.getElementById('player-health-bar').style.display = 'block';
        gameState.controlMode = mode;
        gameState.buttonsHidden = false;
        
        const cheatModeCheckbox = document.getElementById('cheat-mode');
        gameState.cheatModeEnabled = cheatModeCheckbox ? cheatModeCheckbox.checked : false;
        
        if (mode === 'button') {
            document.getElementById('touch-controls').style.display = 'flex';
            document.getElementById('inventory-btn').style.display = 'flex';
            document.getElementById('touch-crafting').style.display = 'flex';
            document.getElementById('refresh-button').style.display = 'flex';
        } else {
            document.getElementById('touch-controls').style.display = 'none';
            document.getElementById('touch-joystick-area').style.display = 'none';
            document.getElementById('inventory-btn').style.display = 'none';
            document.getElementById('touch-crafting').style.display = 'none';
            document.getElementById('refresh-button').style.display = 'none';
        }
        
        document.getElementById('command-btn').style.display = (mode === 'button' && gameState.cheatModeEnabled) ? 'flex' : 'none';
        document.getElementById('map-btn').style.display = (mode === 'button') ? 'flex' : 'none';
        
        gameState.isRunning = true;
        
        if (mode === 'button') {
            setupJoystick();
            restoreGameButtons();
        }
        
        const startX = window.innerWidth / 2;
        const startY = window.innerHeight / 2;
        gameState.playerX = startX;
        gameState.playerY = startY;
        
        if (phaserPlayer) {
            phaserPlayer.setPosition(startX, startY);
        }
        
        const playerDiv = document.getElementById('phaser-player');
        if (playerDiv) {
            playerDiv.style.left = (startX - 73) + 'px';
            playerDiv.style.top = (startY - 73) + 'px';
        }
        
        startAnimalMovement();
        gameLoop();
    };
    
    bindBtn('keyboard-control', () => startGame('keyboard'));
    bindBtn('button-control', () => startGame('button'));
    bindBtn('download-guide', downloadGameGuide);
    bindBtn('command-btn', () => {
        ensureCommandInput();
        const cmdContainer = document.getElementById('command-container');
        const cmdInput = document.getElementById('command-input');
        cmdContainer.style.display = 'block';
        cmdInput.focus();
        cmdInput.value = '/';
        openPanel('command-container');
    });
    
    document.addEventListener('keydown', (e) => {
        if (gameState.controlMode !== 'keyboard') return;
        
        const commandOpen = document.getElementById('command-container')?.style.display === 'block';
        const craftingOpen = document.getElementById('crafting-ui').style.display === 'block';
        const inventoryOpen = document.getElementById('inventory-panel').style.display === 'flex';
        const messageOpen = document.getElementById('message-popup').style.display === 'block';
        const mapOpen = document.getElementById('map-ui').style.display === 'block';
        
        if (messageOpen) {
            if (e.key === 'Enter') {
                const closeBtn = document.getElementById('close-message');
                if (closeBtn) closeBtn.click();
            }
            e.preventDefault();
            return;
        }
        
        if (commandOpen) {
            return;
        }
        
        if (craftingOpen) {
            if (e.key.toLowerCase() === 'c') {
                closePanel('crafting-ui');
            }
            e.preventDefault();
            return;
        }
        
        if (inventoryOpen) {
            if (e.key.toLowerCase() === 'e') {
                closePanel('inventory-panel');
            }
            e.preventDefault();
            return;
        }
        
        if (mapOpen) {
            if (e.key === 'Escape' || e.key.toLowerCase() === 'm') {
                closeMapUI();
            }
            e.preventDefault();
            return;
        }
        
        if (gameState.gamePaused) {
            e.preventDefault();
            return;
        }
        
        if (e.key.toLowerCase() === 'f') {
            if (gameState.currentMap === 'underground') {
                const playerX = gameState.playerX || window.innerWidth / 2;
                const playerY = gameState.playerY || window.innerHeight / 2;
                
                const chests = document.querySelectorAll('.ug-tile[data-type="chest"][data-opened="false"]');
                let nearestChest = null;
                let minDist = 120;
                
                chests.forEach(chest => {
                    const rect = chest.getBoundingClientRect();
                    const centerX = rect.left + rect.width / 2;
                    const centerY = rect.top + rect.height / 2;
                    const dist = Math.hypot(centerX - playerX, centerY - playerY);
                    
                    if (dist < minDist) {
                        minDist = dist;
                        nearestChest = chest;
                    }
                });
                
                if (nearestChest) {
                    startMiningUnderground(nearestChest);
                    return;
                }
            }
            
            const actionButtons = ['dig-hole', 'place-ladder', 'open-chest-btn', 'reclaim-table-btn', 'reclaim-furnace-btn'];
            const visibleButtons = actionButtons.filter(id => {
                const btn = document.getElementById(id);
                return btn && btn.style.display !== 'none';
            });
            
            if (visibleButtons.length > 0) {
                const highlightedId = gameState.highlightedActionBtn || visibleButtons[0];
                const btn = document.getElementById(highlightedId);
                if (btn) {
                    btn.click();
                }
            }
            return;
        }
        
        const key = e.key.toLowerCase();
        
        if (key === 't') {
            if (gameState.cheatModeEnabled) {
                ensureCommandInput();
                const cmdContainer = document.getElementById('command-container');
                const cmdInput = document.getElementById('command-input');
                if (cmdContainer && cmdInput && cmdContainer.style.display !== 'block') {
                    e.preventDefault();
                    cmdContainer.style.display = 'block';
                    cmdInput.focus();
                    cmdInput.value = '/';
                    openPanel('command-container');
                }
            }
            return;
        }
        
        if (key === 'c') {
            gameState.craftingPage = 1;
            renderCraftingUI();
            const crafting = document.getElementById('crafting-ui');
            if (crafting) togglePopup(crafting);
            e.preventDefault();
            return;
        }
        
        if (key === 'e') {
            toggleInventory();
            e.preventDefault();
            return;
        }
        
        if (key === 'o') {
            digHole();
            e.preventDefault();
            return;
        }
        
        if (key === 'm') {
            openMapUI();
            e.preventDefault();
            return;
        }
        
        if (key === 'r') {
            const playerX = gameState.playerX || window.innerWidth / 2;
            const playerY = gameState.playerY || window.innerHeight / 2;
            if (playerX < 100 && (window.innerHeight - playerY) < 100) {
                refreshMap();
            }
            return;
        }
        
        if (['w', 'a', 's', 'd'].includes(key)) {
            gameState.keysPressed.add(key);
            
            if (gameState.keyboardInterval) clearInterval(gameState.keyboardInterval);
            
            const stepFn = () => {
                let dx = 0, dy = 0;
                if (gameState.keysPressed.has('w')) dy -= 1;
                if (gameState.keysPressed.has('s')) dy += 1;
                if (gameState.keysPressed.has('a')) dx -= 1;
                if (gameState.keysPressed.has('d')) dx += 1;
                if (dx === 0 && dy === 0) return;
                movePlayerByVector(dx, dy);
            };
            
            stepFn();
            gameState.keyboardInterval = setInterval(stepFn, 50);
        }
    });
    
    document.addEventListener('keyup', (e) => {
        const key = e.key.toLowerCase();
        if (gameState.controlMode === 'keyboard' && ['w', 'a', 's', 'd'].includes(key)) {
            gameState.keysPressed.delete(key);
            
            if (gameState.keyboardInterval) clearInterval(gameState.keyboardInterval);
            
            if (gameState.keysPressed.size > 0) {
                const stepFn = () => {
                    let dx = 0, dy = 0;
                    if (gameState.keysPressed.has('w')) dy -= 1;
                    if (gameState.keysPressed.has('s')) dy += 1;
                    if (gameState.keysPressed.has('a')) dx -= 1;
                    if (gameState.keysPressed.has('d')) dx += 1;
                    if (dx === 0 && dy === 0) return;
                    movePlayerByVector(dx, dy);
                };
                stepFn();
                gameState.keyboardInterval = setInterval(stepFn, 50);
            } else {
                gameState.keyboardInterval = null;
            }
        }
    });
    
    document.addEventListener('wheel', (e) => {
        if (gameState.controlMode !== 'keyboard') return;
        if (isAnyPanelOpen()) return;
        
        const actionButtons = ['dig-hole', 'place-ladder', 'open-chest-btn', 'reclaim-table-btn', 'reclaim-furnace-btn'];
        const visibleButtons = actionButtons.filter(id => {
            const btn = document.getElementById(id);
            return btn && btn.style.display !== 'none';
        });
        
        if (visibleButtons.length > 0) {
            e.preventDefault();
            
            const currentHighlighted = gameState.highlightedActionBtn || visibleButtons[0];
            const currentIndex = visibleButtons.indexOf(currentHighlighted);
            
            let newIndex;
            if (e.deltaY > 0) {
                newIndex = (currentIndex + 1) % visibleButtons.length;
            } else {
                newIndex = (currentIndex - 1 + visibleButtons.length) % visibleButtons.length;
            }
            
            const prevBtn = document.getElementById(currentHighlighted);
            if (prevBtn) {
                prevBtn.style.outline = '';
                prevBtn.style.transform = '';
            }
            
            const newBtn = document.getElementById(visibleButtons[newIndex]);
            if (newBtn) {
                newBtn.style.outline = '3px solid #FFD700';
                newBtn.style.outlineOffset = '3px';
                newBtn.style.transform = 'scale(1.1)';
                newBtn.style.transition = 'transform 0.1s, outline 0.1s';
            }
            
            gameState.highlightedActionBtn = visibleButtons[newIndex];
        }
    });
    
    window.addEventListener('resize', () => {
        const maxX = window.innerWidth - 50;
        const maxY = window.innerHeight - 50;
        gameState.playerX = Math.min(maxX, gameState.playerX || maxX / 2);
        gameState.playerY = Math.min(maxY, gameState.playerY || maxY / 2);
        
        const player = document.getElementById('phaser-player');
        if (player) {
            player.style.left = gameState.playerX - 73 + 'px';
            player.style.top = gameState.playerY - 73 + 'px';
        }
        
        if (gameState.currentMap === 'underground' && gameState.currentHole && gameState.currentHole.underground) {
            resizeUnderground();
        }
    });
    
    document.addEventListener('click', (e) => {
        if (gameState.controlMode !== 'button') return;
        
        const crafting = document.getElementById('crafting-ui');
        const message = document.getElementById('message-popup');
        const fuel = document.getElementById('fuel-popup');
        
        const craftingOpen = crafting && crafting.style.display === 'block';
        const messageOpen = message && message.style.display === 'block';
        const fuelOpen = fuel && fuel.style.display === 'block';
        
        if (!craftingOpen && !messageOpen && !fuelOpen) return;
        
        const clickedInPopup = e.target.closest('.popup');
        const clickedTouchCraft = e.target.closest('#touch-crafting');
        
        if (!clickedInPopup && !clickedTouchCraft) {
            closeAllPopups();
            restoreGameButtons();
        }
    });
}

function movePlayerByVector(dx, dy) {
    const size = 50;
    const step = 15;
    
    let stepX = dx * step;
    let stepY = dy * step;
    
    if (dx !== 0 && dy !== 0) {
        const inv = 1 / Math.SQRT2;
        stepX *= inv;
        stepY *= inv;
    }
    
    let newX = (gameState.playerX || window.innerWidth / 2) + Math.round(stepX);
    let newY = (gameState.playerY || window.innerHeight / 2) + Math.round(stepY);
    
    newX = Math.max(25, Math.min(window.innerWidth - 25, newX));
    newY = Math.max(25, Math.min(window.innerHeight - 25, newY));
    
    if (isBlockedAt(newX - 25, newY - 25, size, size)) return;
    
    gameState.playerX = newX;
    gameState.playerY = newY;
    
    if (phaserPlayer) {
        phaserPlayer.setPosition(newX, newY);
    }
    
    const playerDiv = document.getElementById('phaser-player');
    if (playerDiv) {
        playerDiv.style.left = (newX - 73) + 'px';
        playerDiv.style.top = (newY - 73) + 'px';
    }
    
    checkNearCraftingTable();
    checkBreakingDistance();
    updateReclaimTableBtn();
    updateReclaimFurnaceBtn();
    updateHoleButtons();
}

function checkBreakingDistance() {
    breakingElements.forEach((info, key) => {
        const playerX = gameState.playerX || window.innerWidth / 2;
        const playerY = gameState.playerY || window.innerHeight / 2;

        if (typeof key === 'string' && key.startsWith('ug:')) {
            const parts = key.substring(3).split(',');
            const row = parseInt(parts[0]);
            const col = parseInt(parts[1]);
            const ug = gameState.currentHole && gameState.currentHole.underground;
            if (!ug) return;
            const cellCx = col * ug.tile + ug.tile / 2;
            const cellCy = row * ug.tile + ug.tile / 2;
            const dist = Math.hypot(cellCx - playerX, cellCy - playerY);
            if (dist > 120) {
                resetBreakingProgressByKey(key);
            }
        } else if (key instanceof HTMLElement) {
            const el = key;
            const rect = el.getBoundingClientRect();
            const centerX = rect.left + rect.width / 2;
            const centerY = rect.top + rect.height / 2;
            const dist = Math.hypot(centerX - playerX, centerY - playerY);
            const isUndergroundTile = el.classList.contains('ug-tile');
            const maxDist = isUndergroundTile ? 120 : 80;
            if (dist > maxDist) {
                resetBreakingProgress(el);
            }
        }
    });
}

function setupJoystick() {
    const area = document.getElementById('touch-joystick-area');
    const thumb = document.getElementById('touch-joystick-thumb');
    
    area.ontouchstart = area.ontouchmove = area.ontouchend = null;
    
    area.addEventListener('touchstart', (e) => {
        if (gameState.controlMode !== 'button') return;
        e.preventDefault();
        
        const t = e.touches[0];
        const rect = area.getBoundingClientRect();
        const cx = rect.left + rect.width / 2;
        const cy = rect.top + rect.height / 2;
        
        gameState.joystick = { active: true, startX: cx, startY: cy, currentX: t.clientX, currentY: t.clientY };
        updateJoystickPosition();
    }, { passive: false });
    
    area.addEventListener('touchmove', (e) => {
        if (!gameState.joystick?.active) return;
        e.preventDefault();
        
        const t = e.touches[0];
        gameState.joystick.currentX = t.clientX;
        gameState.joystick.currentY = t.clientY;
        
        updateJoystickPosition();
        updatePlayerMovement();
    }, { passive: false });
    
    area.addEventListener('touchend', (e) => {
        if (!gameState.joystick?.active) return;
        e.preventDefault();
        
        gameState.joystick.active = false;
        if (thumb) thumb.style.transform = 'translate(0, 0)';
        stopContinuousMove();
    }, { passive: false });
    
    area.addEventListener('mousedown', (e) => {
        if (gameState.controlMode !== 'button') return;
        
        const rect = area.getBoundingClientRect();
        const cx = rect.left + rect.width / 2;
        const cy = rect.top + rect.height / 2;
        
        gameState.joystick = { active: true, startX: cx, startY: cy, currentX: e.clientX, currentY: e.clientY };
        updateJoystickPosition();
    });
    
    document.addEventListener('mousemove', (e) => {
        if (!gameState.joystick?.active) return;
        
        gameState.joystick.currentX = e.clientX;
        gameState.joystick.currentY = e.clientY;
        
        updateJoystickPosition();
        updatePlayerMovement();
    });
    
    document.addEventListener('mouseup', () => {
        if (!gameState.joystick?.active) return;
        
        gameState.joystick.active = false;
        if (thumb) thumb.style.transform = 'translate(0, 0)';
        stopContinuousMove();
    });
}

function updateJoystickPosition() {
    const thumb = document.getElementById('touch-joystick-thumb');
    const joystick = document.getElementById('touch-joystick');
    
    if (!thumb || !joystick || !gameState.joystick) return;
    
    const rect = joystick.getBoundingClientRect();
    const cx = rect.left + rect.width / 2;
    const cy = rect.top + rect.height / 2;
    
    const dx = gameState.joystick.currentX - gameState.joystick.startX;
    const dy = gameState.joystick.currentY - gameState.joystick.startY;
    const dist = Math.sqrt(dx * dx + dy * dy);
    const maxDist = 35;
    
    if (dist > maxDist) {
        const angle = Math.atan2(dy, dx);
        thumb.style.transform = `translate(${Math.cos(angle) * maxDist}px, ${Math.sin(angle) * maxDist}px)`;
    } else {
        thumb.style.transform = `translate(${dx}px, ${dy}px)`;
    }
}

function updatePlayerMovement() {
    if (!gameState.joystick?.active || gameState.gamePaused) return;
    
    const dx = gameState.joystick.currentX - gameState.joystick.startX;
    const dy = gameState.joystick.currentY - gameState.joystick.startY;
    const dist = Math.sqrt(dx * dx + dy * dy);
    
    if (dist < 10) {
        stopContinuousMove();
        return;
    }
    
    const angle = Math.atan2(dy, dx);
    let dir = '';
    
    if (angle > -Math.PI/4 && angle < Math.PI/4) dir = 'right';
    else if (angle >= Math.PI/4 && angle < 3*Math.PI/4) dir = 'down';
    else if (angle >= -3*Math.PI/4 && angle <= -Math.PI/4) dir = 'up';
    else dir = 'left';
    
    startContinuousMove(dir);
}

function stopContinuousMove() {
    if (gameState.touchInterval) clearInterval(gameState.touchInterval);
    gameState.touchInterval = null;
    gameState.currentDirection = null;
}

function startContinuousMove(direction) {
    if (gameState.currentDirection === direction) return;
    
    stopContinuousMove();
    gameState.currentDirection = direction;
    
    movePlayer(direction);
    gameState.touchInterval = setInterval(() => movePlayer(direction), 50);
}

function movePlayer(direction) {
    const step = 15;
    const size = 50;
    
    let newX = gameState.playerX || window.innerWidth / 2;
    let newY = gameState.playerY || window.innerHeight / 2;
    
    const currentX = newX;
    const currentY = newY;
    
    if (direction === 'up') newY = Math.max(25, newY - step);
    if (direction === 'down') newY = Math.min(window.innerHeight - 25, newY + step);
    if (direction === 'left') newX = Math.max(25, newX - step);
    if (direction === 'right') newX = Math.min(window.innerWidth - 25, newX + step);
    
    if (isBlockedAt(newX - 25, newY - 25, size, size)) {
        if ((direction === 'left' || direction === 'right') && !isBlockedAt(newX - 25, currentY - 25, size, size)) {
            newY = currentY;
        } else if ((direction === 'up' || direction === 'down') && !isBlockedAt(currentX - 25, newY - 25, size, size)) {
            newX = currentX;
        } else {
            resolveCollision();
            return;
        }
    }
    
    gameState.playerX = newX;
    gameState.playerY = newY;
    
    if (phaserPlayer) {
        phaserPlayer.setPosition(newX, newY);
    }
    
    const playerDiv = document.getElementById('phaser-player');
    if (playerDiv) {
        playerDiv.style.left = (newX - 73) + 'px';
        playerDiv.style.top = (newY - 73) + 'px';
    }
    
    checkNearCraftingTable();
    checkBreakingDistance();
    updateReclaimTableBtn();
    updateReclaimFurnaceBtn();
    updateHoleButtons();
}

function gameLoop() {
    if (!gameState.isRunning) return;
    
    checkRefreshButtonPosition();
    
    if (!gameState.uiPanelOpen && !gameState.gamePaused) {
        updateReclaimTableBtn();
        updateReclaimFurnaceBtn();
        updateHoleButtons();
    }
    
    requestAnimationFrame(gameLoop);
}

function downloadGameGuide() {
    const guideText = `绿色森林 - 游戏操作指南
========================

【游戏简介】
绿色森林是一款休闲生存类游戏，玩家需要在森林中采集资源、制作工具、探索地下世界。

【操作方式】
玩家可以选择两种控制方式：
1. 键盘控制：使用方向键或WASD移动，使用按键进行交互
2. 按钮控制：使用屏幕上的虚拟按钮移动和交互

【基本操作】

一、移动
- 键盘：方向键 ↑↓←→ 或 WASD
- 按钮：屏幕底部的方向按钮

二、采集资源
- 靠近资源后长按进行采集
- 可用资源包括：树叶、石头、树干
- 部分资源需要特定工具才能采集
- 挖掘时切换目标会打断当前挖掘（进度清零）

三、制作系统
- 按 C 键打开制作界面（键盘控制）
- 或点击屏幕上的制作按钮（按钮控制）
- 制作需要消耗相应材料
- 部分物品需要靠近合成台才能制作（如木镐、石镐、熔炉等）
- 制作合成台或熔炉后，需从背包中点击放置到地图上
- 靠近已放置的合成台或熔炉，按 F 键可收回（收回后放回背包）

四、战斗系统
- 靠近动物后点击动物进行攻击（攻击范围约80px）
- 动物有生命值（4点），需要多次攻击才能击杀
- 攻击力取决于装备的武器（基础1，木剑+1，硬石剑+3）
- 击杀动物可获得生肉

五、地下探索
1. 挖洞：按 O 键挖洞（键盘控制）或点击挖洞按钮（按钮控制），消耗镐耐久
2. 放置梯子：在洞旁边放置梯子
3. 进入地下：靠近放置了梯子的洞后，按 F 键或点击进入矿洞按钮（需要主世界刷新5次）
4. 返回地面：移动到地下世界右上角的出口区域，按 F 键或点击返回地面按钮
5. 地下刷新：在地下世界也可以刷新地图，刷新后传送至右上角出口
6. 宝箱：每个地下地图有一个宝箱，靠近后按 F 键或点击打开宝箱按钮打开，获得1金币

【资源说明】

基础资源：
- 树枝(twig)：采集树叶获得，用于制作工具
- 藤蔓(fullVine)：采集树叶获得，用于制作梯子和工具
- 破碎藤蔓(vine)：由藤蔓制作获得，用于制作工具
- 木棍(branch)：由树枝制作获得，用于制作工具和梯子
- 木头(wood)：砍树获得，用于制作工具和建筑
- 石头(stone)：采集石头获得，用于制作石制工具
- 石块(stoneBlock)：在地下世界挖掘石块获得（需镐），用于制作工具
- 硬石块(hardStoneBlock)：在熔炉中烧制硬石矿获得，用于制作高级工具

高级资源：
- 生肉(rawMeat)：击杀动物获得
- 熟肉(cookedMeat)：在熔炉中烧制生肉获得
- 燃矿(fuelOre)：地下世界挖掘获得，用作熔炉燃料（橙色矿石，绿色进度条），每个燃矿可添加1000燃料
- 硬石矿(hardStoneOre)：地下世界挖掘获得，用于制作高级工具（灰色矿石）
- 金币(gold)：打开地下世界宝箱获得，用于解锁地图

【工具说明】

镐类（用于挖洞和挖掘石块）：
- 木镐：耐久10，挖洞消耗2耐久
- 石镐：耐久30，挖洞消耗1耐久，挖掘速度2.5倍
- 硬石镐：耐久100，挖洞消耗1耐久，挖掘速度最快

斧类（用于砍树）：
- 碎石斧：耐久10，用于砍树
- 硬石斧：耐久50，砍树速度更快

武器（用于攻击动物，基础攻击力1）：
- 木剑：耐久30，攻击力+1（总计2）
- 硬石剑：耐久150，攻击力+3（总计4）

【熔炉系统】
- 需要先制作熔炉并放置到地图上
- 靠近熔炉后打开制作界面（C键或制作按钮）
- 在制作界面的最后一页找到"添加燃料"按钮
- 点击"添加燃料"按钮打开燃料选择界面
- 可添加的燃料及燃料值：
  - 燃矿：1000燃料
  - 木材：200燃料
  - 树枝：60燃料
  - 木棍：20燃料
- 熔炼配方：
  - 生肉 → 熟肉：消耗100燃料
  - 硬石矿 → 硬石块：消耗200燃料

【作弊模式】
在开始界面勾选"启用作弊模式"复选框即可开启作弊功能。

开启后可以使用以下指令：
/give [物品名] [数量] - 给予指定数量的物品
/health [数量] - 恢复指定数量的生命值（最大20）
/fuel [数量] - 增加熔炉燃料
/clear - 清空背包所有物品
/tp x,y - 瞬移到地图指定位置（支持 x,y 或 x y 格式）
/unlockmap [地图名] - 解锁地图(surface/underground)
/map [地图名] - 直接切换地图(surface/underground)
/refreshtimes [地图名] - 查询地图刷新次数
/help - 显示所有可用指令

打开指令面板方式：
- 键盘控制：按 T 键
- 按钮控制：点击屏幕上的 💬 按钮

可用物品名称（用于 /give 指令）：
基础材料：wood（木头）、stone（石头）、twig（树枝）、branch（木棍）、vine（破碎藤蔓）、fullVine（藤蔓）、stoneBlock（石块）、hardStoneBlock（硬石块）、gold（金币）
工具：pickaxe（木镐）、stonePickaxe（石镐）、hardStonePickaxe（硬石镐）、axe（碎石斧）、hardStoneAxe（硬石斧）、woodenSword（木剑）、hardStoneSword（硬石剑）、ladder（梯子）
建筑：craftingTable（合成台）、furnace（熔炉）
食物：rawMeat（生肉）、cookedMeat（熟肉）
矿石：fuelOre（燃矿）、hardStoneOre（硬石矿）

示例：
/give wood 10 - 获得10个木头
/give pickaxe 1 - 获得1个木镐
/health 20 - 恢复满生命值
/tp 500,300 - 瞬移到坐标(500, 300)
/map underground - 切换到地下世界

【游戏技巧】
1. 优先制作工具，工具能提高采集效率
2. 合理管理工具耐久，及时补充
3. 探索地下世界获取稀有资源（燃矿、硬石矿、宝箱金币）
4. 注意保持生命值，及时食用食物
5. 利用刷新地图获取更多资源
6. 传送（切换地图、刷新）后会出现在右上角安全区域

【快捷键汇总】
W/↑ - 向上移动
S/↓ - 向下移动
A/← - 向左移动
D/→ - 向右移动
C - 打开制作界面
E - 打开背包
T - 打开指令（作弊模式）
O - 挖洞（键盘控制）
F - 交互键（打开宝箱、收回工作台/熔炉、进入/退出矿洞等）
M - 打开地图
R - 刷新地图（仅在左下角区域）

【控制模式差异】
键盘模式：
- 所有交互通过按键完成
- 无屏幕按钮显示（除菜单按钮）
- 挖洞使用 O 键
- 交互使用 F 键
- 地图使用 M 键打开

按钮模式：
- 所有交互通过屏幕按钮完成
- 显示方向按钮和各种操作按钮
- 挖洞、放置梯子、进入矿洞等都有对应按钮
- 橙色圆形地图按钮位于屏幕顶部
- 无任何键盘快捷键（命令输入框内输入指令除外）

========================
祝游戏愉快！
`;
    
    const blob = new Blob([guideText], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = '绿色森林游戏指南.txt';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
    
    showMessage('游戏指南已下载！');
}

function ensureCommandInput() {
    let cmdContainer = document.getElementById('command-container');
    let cmdInput = document.getElementById('command-input');
    
    if (!cmdContainer) {
        cmdContainer = document.createElement('div');
        cmdContainer.id = 'command-container';
        cmdContainer.style.position = 'fixed';
        cmdContainer.style.top = '50%';
        cmdContainer.style.left = '50%';
        cmdContainer.style.transform = 'translate(-50%, -50%)';
        cmdContainer.style.zIndex = 1000;
        cmdContainer.style.display = 'none';
        cmdContainer.style.background = 'rgba(0, 0, 0, 0.8)';
        cmdContainer.style.padding = '20px';
        cmdContainer.style.borderRadius = '8px';
        document.body.appendChild(cmdContainer);
        
        cmdInput = document.createElement('input');
        cmdInput.id = 'command-input';
        cmdInput.type = 'text';
        cmdInput.style.width = '300px';
        cmdInput.style.padding = '10px';
        cmdInput.style.fontSize = '16px';
        cmdInput.style.background = '#333';
        cmdInput.style.color = '#fff';
        cmdInput.style.border = '1px solid #555';
        cmdInput.style.borderRadius = '4px';
        cmdContainer.appendChild(cmdInput);
        
        cmdInput.addEventListener('keydown', (e) => {
            if (e.key === 'Enter') {
                executeCommand(cmdInput.value);
                closePanel('command-container');
                cmdInput.value = '';
            } else if (e.key === 'Escape') {
                closePanel('command-container');
                cmdInput.value = '';
            }
        });
    }
}

function executeCommand(command) {
    if (!command.startsWith('/')) return;
    
    const parts = command.trim().split(' ');
    const cmd = parts[0].toLowerCase();
    
    if (cmd === '/give' && parts.length >= 2) {
        const itemName = parts[1];
        const amount = parts.length >= 3 ? parseInt(parts[2]) : 1;
        
        const resource = RESOURCES.find(r => 
            r.name === itemName || r.key === itemName.toLowerCase()
        );
        
        if (resource) {
            updateResource(resource.key, amount);
            
            if (resource.durability && resource.max) {
                const currentDurability = gameState[resource.durability] || 0;
                const neededDurability = amount * resource.max;
                if (currentDurability < neededDurability) {
                    gameState[resource.durability] = neededDurability;
                }
            }
            
            updateInventoryPanel();
            showMessage(`获得了 ${amount} 个 ${resource.name}！`);
        } else {
            showMessage(`未知物品: ${itemName}`);
        }
    } else if (cmd === '/health') {
        const amount = parts.length >= 2 ? parseInt(parts[1]) : 20;
        gameState.health = Math.min(20, gameState.health + amount);
        updateHealthBar();
        showMessage(`生命值恢复了 ${amount} 点！`);
    } else if (cmd === '/fuel') {
        const amount = parts.length >= 2 ? parseInt(parts[2]) : 10;
        gameState.furnaceFuel += amount;
        updateInventoryPanel();
        showMessage(`熔炉燃料增加了 ${amount}！`);
    } else if (cmd === '/clear') {
        Object.keys(gameState.resources).forEach(key => {
            gameState.resources[key] = 0;
        });
        updateInventoryPanel();
        showMessage('物品已清空！');
    } else if (cmd === '/tp') {
        if (parts.length < 2) {
            showMessage('用法: /tp x,y 或 /tp x y');
            return;
        }
        
        const posStr = parts[1];
        let x, y;
        
        if (posStr.includes(',')) {
            const coords = posStr.split(',');
            x = parseInt(coords[0].trim());
            y = parseInt(coords[1].trim());
        } else if (parts.length >= 3) {
            x = parseInt(posStr);
            y = parseInt(parts[2]);
        }
        
        if (isNaN(x) || isNaN(y)) {
            showMessage('无效坐标！用法: /tp x,y 或 /tp x y');
            return;
        }
        
        const maxX = window.innerWidth - 50;
        const maxY = window.innerHeight - 50;
        
        x = Math.max(0, Math.min(maxX, x));
        y = Math.max(0, Math.min(maxY, y));
        
        gameState.playerX = x;
        gameState.playerY = y;
        
        const playerDiv = document.getElementById('phaser-player');
        if (playerDiv) {
            playerDiv.style.left = (x - 73) + 'px';
            playerDiv.style.top = (y - 73) + 'px';
        }
        
        showMessage(`已传送到 (${x}, ${y})！`);
    } else if (cmd === '/unlockmap') {
        if (parts.length < 2) {
            showMessage('用法: /unlockmap [地图名]');
            showMessage('可用地图: surface, underground');
            return;
        }
        
        const mapName = parts[1].toLowerCase();
        if (mapName === 'surface' || mapName === 'underground') {
            if (!gameState.unlockedMaps.includes(mapName)) {
                gameState.unlockedMaps.push(mapName);
                showMessage(`${mapName === 'surface' ? '地面世界' : '地下矿洞'}已解锁！`);
            } else {
                showMessage(`${mapName === 'surface' ? '地面世界' : '地下矿洞'}已经解锁！`);
            }
        } else {
            showMessage(`未知地图: ${mapName}`);
            showMessage('可用地图: surface, underground');
        }
    } else if (cmd === '/refreshtimes') {
        if (parts.length < 2) {
            showMessage('用法: /refreshtimes [地图名]');
            showMessage('可用地图: surface, underground');
            return;
        }
        
        const mapName = parts[1].toLowerCase();
        if (mapName === 'surface' || mapName === 'underground') {
            const count = gameState.refreshCounts[mapName] || 0;
            showMessage(`${mapName === 'surface' ? '地面世界' : '地下矿洞'} 刷新次数: ${count}`);
        } else {
            showMessage(`未知地图: ${mapName}`);
            showMessage('可用地图: surface, underground');
        }
    } else if (cmd === '/map') {
        if (parts.length < 2) {
            showMessage('用法: /map [地图名]');
            showMessage('可用地图: surface, underground');
            return;
        }
        
        const mapName = parts[1].toLowerCase();
        if (mapName === 'surface' || mapName === 'underground') {
            if (gameState.currentMap === mapName) {
                showMessage(`已经在${mapName === 'surface' ? '地面世界' : '地下矿洞'}！`);
                return;
            }
            
            saveCurrentMapState();
            
            if (!gameState.unlockedMaps.includes(mapName)) {
                gameState.unlockedMaps.push(mapName);
            }
            
            if (mapName === 'surface') {
                loadSurfaceMap();
                showMessage('已切换到地面世界！');
            } else if (mapName === 'underground') {
                const success = loadUndergroundMap();
                if (success) {
                    showMessage('已切换到地下矿洞！');
                }
            }
        } else {
            showMessage(`未知地图: ${mapName}`);
            showMessage('可用地图: surface, underground');
        }
    } else if (cmd === '/help') {
        const helpText = `
可用指令:
/give [物品名] [数量] - 给予物品
/health [数量] - 恢复生命值
/fuel [数量] - 增加熔炉燃料
/clear - 清空物品
/tp x,y - 瞬移到指定位置
/unlockmap [地图名] - 解锁地图(surface/underground)
/map [地图名] - 直接切换地图(surface/underground)
/refreshtimes [地图名] - 查询地图刷新次数
/show 或 /display - 显示/隐藏所有碰撞箱
/help - 显示帮助
        `.trim();
        showMessage(helpText);
    } else if (cmd === '/show' || cmd === '/display') {
        toggleHitboxes();
    } else {
        showMessage(`未知指令: ${cmd}`);
    }
}

document.addEventListener('DOMContentLoaded', () => {
    initGame();
});

let hitboxVisible = false;

function toggleHitboxes() {
    hitboxVisible = !hitboxVisible;
    if (hitboxVisible) {
        document.body.classList.add('show-hitboxes');
        showMessage('碰撞箱已显示（再次输入 /show 隐藏）');
    } else {
        document.body.classList.remove('show-hitboxes');
        showMessage('碰撞箱已隐藏');
    }
}