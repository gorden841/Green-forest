start net.bat
start ngrok.bat