let phaserGame = null;
let phaserPlayer = null;

const GRID_SIZE = 50;

function initPhaserGame() {
    const config = {
        type: Phaser.AUTO,
        width: window.innerWidth,
        height: window.innerHeight,
        parent: 'game-container',
        canvas: document.getElementById('game-canvas'),
        physics: {
            default: 'arcade',
            arcade: {
                gravity: { y: 0 },
                debug: false
            }
        },
        scene: {
            preload: preload,
            create: create,
            update: update
        }
    };

    phaserGame = new Phaser.Game(config);
}

function preload() {
    this.load.image('player', 'data:image/svg+xml,<svg xmlns="http://www.w3.org/2000/svg" width="50" height="50"><circle cx="25" cy="25" r="25" fill="#FF8C00"/></svg>');
    this.load.image('treeLeaf', 'data:image/svg+xml,<svg xmlns="http://www.w3.org/2000/svg" width="50" height="50"><circle cx="25" cy="25" r="25" fill="#008000"/></svg>');
    this.load.image('treeTrunk', 'data:image/svg+xml,<svg xmlns="http://www.w3.org/2000/svg" width="20" height="70"><rect width="20" height="70" fill="#A0522D"/></svg>');
    this.load.image('stone', 'data:image/svg+xml,<svg xmlns="http://www.w3.org/2000/svg" width="50" height="50"><circle cx="25" cy="25" r="25" fill="#808080"/></svg>');
    this.load.image('animal', 'data:image/svg+xml,<svg xmlns="http://www.w3.org/2000/svg" width="40" height="40"><circle cx="20" cy="20" r="20" fill="#FFC0CB"/></svg>');
    this.load.image('craftingTable', 'data:image/svg+xml,<svg xmlns="http://www.w3.org/2000/svg" width="60" height="60"><rect width="60" height="60" fill="#654321" rx="5"/></svg>');
    this.load.image('furnace', 'data:image/svg+xml,<svg xmlns="http://www.w3.org/2000/svg" width="50" height="50"><rect width="50" height="50" fill="#555555" rx="5"/></svg>');
    this.load.image('hole', 'data:image/svg+xml,<svg xmlns="http://www.w3.org/2000/svg" width="50" height="50"><rect width="50" height="50" fill="#222222" rx="6" stroke="rgba(0,0,0,0.3)" stroke-width="2"/></svg>');
    this.load.image('ladder', 'data:image/svg+xml,<svg xmlns="http://www.w3.org/2000/svg" width="50" height="50"><rect width="50" height="50" fill="#D2B48C"/><line x1="10" y1="0" x2="10" y2="50" stroke="#8B4513" stroke-width="3"/><line x1="30" y1="0" x2="30" y2="50" stroke="#8B4513" stroke-width="3"/><line x1="40" y1="0" x2="40" y2="50" stroke="#8B4513" stroke-width="3"/></svg>');
}

function create() {
    this.physics.world.setBounds(0, 0, window.innerWidth, window.innerHeight);
    
    phaserPlayer = this.physics.add.sprite(window.innerWidth / 2, window.innerHeight / 2, 'player');
    phaserPlayer.setDisplaySize(50, 50);
    phaserPlayer.setCollideWorldBounds(true);
    
    gameState.playerX = phaserPlayer.x;
    gameState.playerY = phaserPlayer.y;
}

function updatePlayerPosition() {
    if (phaserPlayer && gameState.playerX !== undefined) {
        phaserPlayer.setPosition(gameState.playerX, gameState.playerY);
    }
    
    const playerDiv = document.getElementById('phaser-player');
    if (playerDiv && gameState.playerX !== undefined) {
        playerDiv.style.left = gameState.playerX - 25 + 'px';
        playerDiv.style.top = gameState.playerY - 25 + 'px';
    }
}

function update() {
    if (!gameState.isRunning) return;
    
    updatePlayerPosition();
}

function getPlayerBounds() {
    const size = 28;
    const halfSize = size / 2;
    return {
        left: gameState.playerX - halfSize,
        top: gameState.playerY - halfSize,
        right: gameState.playerX + halfSize,
        bottom: gameState.playerY + halfSize,
        width: size,
        height: size
    };
}

function getElementBounds(el) {
    const rect = el.getBoundingClientRect();
    
    let left = rect.left;
    let top = rect.top;
    let width = rect.width;
    let height = rect.height;
    
    if (el.classList.contains('tree-leaf')) {
        const shrink = 8.75;
        left = rect.left + shrink;
        top = rect.top + shrink;
        width = rect.width - shrink * 2;
        height = rect.height - shrink * 2;
    } else if (el.classList.contains('stone')) {
        const shrink = 8.75;
        left = rect.left + shrink;
        top = rect.top + shrink;
        width = rect.width - shrink * 2;
        height = rect.height - shrink * 2;
    } else if (el.classList.contains('tree-trunk')) {
        width = rect.width * 0.7;
        height = rect.height * 0.7;
        left = rect.left + rect.width * 0.15;
        top = rect.top + rect.height * 0.15;
    } else if (el.classList.contains('crafting-table') || el.classList.contains('furnace')) {
        const shrink = 7.5;
        left = rect.left + shrink;
        top = rect.top + shrink;
        width = rect.width - shrink * 2;
        height = rect.height - shrink * 2;
    }
    
    return { left, top, right: left + width, bottom: top + height };
}

function checkPlayerCollision() {
    if (!gameState.collisionEnabled) return null;
    
    const playerBounds = getPlayerBounds();
    
    let container;
    if (gameState.currentMap === 'surface') {
        container = document.getElementById('game-container');
    } else if (gameState.currentMap === 'underground' && gameState.currentHole && gameState.currentHole.underground) {
        container = gameState.currentHole.underground.container;
    }
    
    if (!container) return null;
    
    const blocks = container.querySelectorAll('.tree-trunk, .tree-leaf, .stone, .crafting-table, .furnace, .hole, .ug-tile');
    
    for (const el of blocks) {
        const blockBounds = getElementBounds(el);
        
        if (isOverlapping(playerBounds, blockBounds)) {
            return { el, blockBounds };
        }
    }
    
    return null;
}

function isOverlapping(a, b) {
    return a.left < b.right && a.right > b.left && a.top < b.bottom && a.bottom > b.top;
}

function resolveCollision() {
    const collision = checkPlayerCollision();
    if (!collision) return;
    
    const { blockBounds } = collision;
    const playerBounds = getPlayerBounds();
    
    const overlapLeft = playerBounds.right - blockBounds.left;
    const overlapRight = blockBounds.right - playerBounds.left;
    const overlapTop = playerBounds.bottom - blockBounds.top;
    const overlapBottom = blockBounds.bottom - playerBounds.top;
    
    const minOverlapX = Math.min(overlapLeft, overlapRight);
    const minOverlapY = Math.min(overlapTop, overlapBottom);
    
    let newX = gameState.playerX;
    let newY = gameState.playerY;
    
    if (minOverlapX < minOverlapY) {
        if (overlapLeft < overlapRight) {
            newX = blockBounds.left - playerBounds.width / 2;
        } else {
            newX = blockBounds.right + playerBounds.width / 2;
        }
    } else {
        if (overlapTop < overlapBottom) {
            newY = blockBounds.top - playerBounds.height / 2;
        } else {
            newY = blockBounds.bottom + playerBounds.height / 2;
        }
    }
    
    const size = playerBounds.width;
    newX = Math.max(size / 2, Math.min(window.innerWidth - size / 2, newX));
    newY = Math.max(size / 2, Math.min(window.innerHeight - size / 2, newY));
    
    gameState.playerX = newX;
    gameState.playerY = newY;
    
    if (phaserPlayer) {
        phaserPlayer.setPosition(newX, newY);
    }
    
    const playerDiv = document.getElementById('phaser-player');
    if (playerDiv) {
        playerDiv.style.left = newX - 25 + 'px';
        playerDiv.style.top = newY - 25 + 'px';
    }
    
    if (checkPlayerCollision()) {
        setTimeout(resolveCollision, 0);
    }
}

function movePhaserPlayer(dx, dy) {
    if (!phaserPlayer || !gameState.isRunning) return;
    
    const baseStep = 15;
    
    if (dx !== 0 && dy !== 0) {
        const inv = 1 / Math.SQRT2;
        dx *= inv;
        dy *= inv;
    }
    
    let newX = phaserPlayer.x + Math.round(dx * baseStep);
    let newY = phaserPlayer.y + Math.round(dy * baseStep);
    
    const size = 50;
    newX = Math.max(25, Math.min(window.innerWidth - 25, newX));
    newY = Math.max(25, Math.min(window.innerHeight - 25, newY));
    
    if (isBlockedAt(newX - 25, newY - 25, size, size)) return;
    
    phaserPlayer.setPosition(newX, newY);
    
    gameState.playerX = newX;
    gameState.playerY = newY;
    
    const playerDiv = document.getElementById('phaser-player');
    if (playerDiv) {
        playerDiv.style.left = newX - 25 + 'px';
        playerDiv.style.top = newY - 25 + 'px';
    }
    
    resolveCollision();
}

function movePhaserPlayerByDirection(direction) {
    let dx = 0, dy = 0;
    if (direction === 'up') dy = -1;
    if (direction === 'down') dy = 1;
    if (direction === 'left') dx = -1;
    if (direction === 'right') dx = 1;
    movePhaserPlayer(dx, dy);
}

const RESOURCES = [
    { name: '破碎藤蔓', key: 'vine', color: '#8FBC8F' },
    { name: '木棍', key: 'branch', color: '#A0522D' },
    { name: '完整藤蔓', key: 'fullVine', color: '#2E8B57' },
    { name: '石子', key: 'stone', color: '#808080' },
    { name: '木材', key: 'wood', color: '#A0522D' },
    { name: '碎石斧', key: 'axe', color: '#D2691E', durability: 'axeDurability', max: 10 },
    { name: '木镐', key: 'pickaxe', color: '#654321', durability: 'pickaxeDurability', max: 10 },
    { name: '树枝', key: 'twig', color: '#8B5A2B' },
    { name: '木剑', key: 'woodenSword', color: '#FF8C00', durability: 'woodenSwordDurability', max: 30 },
    { name: '合成台', key: 'craftingTable', color: '#654321' },
    { name: '生肉', key: 'rawMeat', color: '#e06666' },
    { name: '熔炉', key: 'furnace', color: '#555555' },
    { name: '熟肉', key: 'cookedMeat', color: '#b8860b' },
    { name: '石块', key: 'stoneBlock', color: '#9E9E9E' },
    { name: '硬石矿', key: 'hardStoneOre', color: '#666666' },
    { name: '燃矿', key: 'fuelOre', color: '#ff8800' },
    { name: '硬石块', key: 'hardStoneBlock', color: '#555555' },
    { name: '梯子', key: 'ladder', color: '#D2B48C' },
    { name: '石镐', key: 'stonePickaxe', color: '#999999', durability: 'stonePickaxeDurability', max: 30 },
    { name: '硬石镐', key: 'hardStonePickaxe', color: '#7f7f7f', durability: 'hardStonePickaxeDurability', max: 100 },
    { name: '硬石剑', key: 'hardStoneSword', color: '#b0b0b0', durability: 'hardStoneSwordDurability', max: 150 },
    { name: '硬石斧', key: 'hardStoneAxe', color: '#b0662e', durability: 'hardStoneAxeDurability', max: 50 },
    { name: '金币', key: 'gold', color: '#FFD700' },
];

const RECIPES = [
    { id: 'axe', title: '碎石斧', category: 'global', ingredients: [{k:'stone',q:1},{k:'branch',q:1},{k:'vine',q:1}], func: 'craftAxe', desc: '无需工作台' },
    { id: 'branch', title: '木棍', category: 'global', ingredients: [{k:'twig',q:1}], func: 'craftBranch', desc: '无需工作台' },
    { id: 'vine', title: '破碎藤蔓', category: 'global', ingredients: [{k:'fullVine',q:1}], func: 'craftVine', desc: '无需工作台' },
    { id: 'table', title: '合成台', category: 'global', ingredients: [{k:'wood',q:1}], func: 'craftTable', desc: '放置合成台' },
    { id: 'woodenSword', title: '木剑', category: 'workbench', ingredients: [{k:'fullVine',q:1},{k:'twig',q:1},{k:'wood',q:1}], func: 'craftWoodenSword', desc: '需要工作台' },
    { id: 'pickaxe', title: '木镐', category: 'workbench', ingredients: [{k:'fullVine',q:1},{k:'twig',q:1},{k:'wood',q:1}], func: 'craftPickaxe', desc: '木镐耐久10' },
    { id: 'stonePickaxe', title: '石镐', category: 'workbench', ingredients: [{k:'fullVine',q:1},{k:'twig',q:1},{k:'stoneBlock',q:1}], func: 'craftStonePickaxe', desc: '耐久30，挖掘速度2.5倍' },
    { id: 'ladder', title: '梯子', category: 'workbench', ingredients: [{k:'branch',q:7}], func: 'craftLadder', desc: '需要合成台' },
    { id: 'furnace', title: '熔炉', category: 'workbench', ingredients: [{k:'stone',q:10}], func: 'craftFurnace', desc: '需要合成台' },
    { id: 'stonePickaxe_hard', title: '硬石镐', category: 'workbench', ingredients: [{k:'hardStoneBlock',q:3},{k:'twig',q:1},{k:'fullVine',q:1}], func: 'craftHardStonePickaxe', desc: '耐久100，需合成台' },
    { id: 'hardStoneSword', title: '硬石剑', category: 'workbench', ingredients: [{k:'hardStoneBlock',q:2},{k:'twig',q:1},{k:'fullVine',q:1}], func: 'craftHardStoneSword', desc: '强力武器' },
    { id: 'hardStoneAxe', title: '硬石斧', category: 'workbench', ingredients: [{k:'hardStoneBlock',q:2},{k:'branch',q:1}], func: 'craftHardStoneAxe', desc: '耐久强，砍树更快' },
    { id: 'smeltMeat', title: '熟肉', category: 'furnace', ingredients: [{k:'rawMeat',q:1}], func: 'smeltCookedMeat', desc: '需要靠近熔炉并消耗燃料' },
    { id: 'smeltHard', title: '烧制硬石块', category: 'furnace', ingredients: [{k:'hardStoneOre',q:1}], func: 'smeltHardStone', desc: '需要靠近熔炉并消耗燃料' }
];

const gameState = {
    resources: {},
    axeDurability: 0,
    pickaxeDurability: 0,
    woodenSwordDurability: 0,
    stonePickaxeDurability: 0,
    hardStonePickaxeDurability: 0,
    hardStoneSwordDurability: 0,
    hardStoneAxeDurability: 0,
    controlMode: 'keyboard',
    isRunning: false,
    health: 20,
    craftingPage: 1,
    refreshCooldown: false,
    attack: 1,
    furnaceFuel: 0,
    holes: [],
    undergroundOpen: false,
    currentHole: null,
    nearCraftingTable: false,
    keysPressed: new Set(),
    cheatModeEnabled: false,
    animals: [],
    gridOccupied: new Set(),
    currentMap: 'surface',
    unlockedMaps: ['surface'],
    surfaceSnapshot: null,
    refreshCounts: {
        surface: 0,
        underground: 0
    },
    collisionEnabled: true,
};

RESOURCES.forEach(r => {
    gameState.resources[r.key] = 0;
});

function bindBtn(id, fn) {
    const el = document.getElementById(id);
    if (el) {
        el.addEventListener('touchstart', e => { e.preventDefault(); fn(); }, { passive: false });
        el.addEventListener('click', fn);
    }
}

function updateResource(key, delta) {
    gameState.resources[key] = Math.max(0, (gameState.resources[key] || 0) + delta);
}

function updateDurability(durKey, max) {
    gameState[durKey]--;
    if (gameState[durKey] <= 0) {
        const toolKey = durKey.replace('Durability', '');
        updateResource(toolKey, -1);
        if (gameState.resources[toolKey] > 0) gameState[durKey] = max;
    }
}

function checkNear(selector, threshold = 100) {
    const elements = Array.from(document.querySelectorAll(selector));
    const playerPos = { x: gameState.playerX || window.innerWidth / 2, y: gameState.playerY || window.innerHeight / 2 };
    return elements.some(el => {
        const rect = el.getBoundingClientRect();
        const centerX = rect.left + rect.width / 2;
        const centerY = rect.top + rect.height / 2;
        const dist = Math.hypot(centerX - playerPos.x, centerY - playerPos.y);
        return dist < threshold;
    });
}

const craftingPagination = {
    totalPages: 4,
    nextPage() { 
        if (gameState.craftingPage < this.totalPages) { 
            gameState.craftingPage++; 
            this.updatePageDisplay(); 
        } 
    },
    prevPage() { 
        if (gameState.craftingPage > 1) { 
            gameState.craftingPage--; 
            this.updatePageDisplay(); 
        } 
    },
    updatePageDisplay() {
        const el = document.getElementById('crafting-page');
        if (el) el.textContent = `${gameState.craftingPage}/${this.totalPages}`;
        document.querySelectorAll('.recipe-page').forEach((page, idx) => {
            page.style.display = (idx === gameState.craftingPage - 1) ? 'block' : 'none';
        });
    }
};

function updateInventoryPanel() {
    const fuelEl = document.getElementById('inventory-fuel-value');
    if (fuelEl) fuelEl.textContent = gameState.furnaceFuel;
    
    const grid = document.getElementById('inventory-grid');
    if (!grid) return;
    
    grid.innerHTML = '';
    RESOURCES.filter(item => gameState.resources[item.key] > 0).forEach(item => {
        const div = document.createElement('div');
        div.className = 'inventory-item';
        div.style.cursor = ['craftingTable', 'furnace', 'rawMeat', 'cookedMeat'].includes(item.key) ? 'pointer' : 'default';
        div.innerHTML = `
            <div class="inventory-icon" style="background-color: ${item.color}">${item.name}</div>
            <span>数量: ${gameState.resources[item.key]}</span>
            ${item.durability && gameState[item.durability] > 0 ? `<span>耐久: ${gameState[item.durability]}/${item.max}</span>` : ''}
        `;
        div.onclick = () => handleInventoryItemClick(item);
        grid.appendChild(div);
    });
}

function handleInventoryItemClick(item) {
    if (item.key === 'craftingTable') {
        document.getElementById('inventory-panel').style.display = 'none';
        const pos = findNearbyFreePosition(60, 60);
        createCraftingTable(pos.x, pos.y);
        updateResource('craftingTable', -1);
        updateInventoryPanel();
    } else if (item.key === 'furnace') {
        document.getElementById('inventory-panel').style.display = 'none';
        const pos = findNearbyFreePosition(60, 60);
        const f = createElement('furnace', pos.x, pos.y, 60, 60);
        f.textContent = '熔炉';
        updateResource('furnace', -1);
        updateInventoryPanel();
    } else if (item.key === 'rawMeat') {
        if (gameState.health >= 20) return;
        if (gameState.resources.rawMeat > 0) {
            updateResource('rawMeat', -1);
            const add = Math.min(2, 20 - gameState.health);
            gameState.health += add;
            updateInventoryPanel();
            updateHealthBar();
        }
    } else if (item.key === 'cookedMeat') {
        if (gameState.health >= 20) return;
        if (gameState.resources.cookedMeat > 0) {
            updateResource('cookedMeat', -1);
            const add = Math.min(5, 20 - gameState.health);
            gameState.health += add;
            updateInventoryPanel();
            updateHealthBar();
        }
    }
}

function updateHealthBar() {
    const bar = document.getElementById('player-health-fill');
    const text = document.getElementById('player-health-text');
    const percent = Math.max(0, Math.min(20, gameState.health));
    if (bar) bar.style.width = (percent / 20 * 100) + '%';
    if (text) text.textContent = `${percent} / 20`;
}

function showMessage(text) {
    const content = document.getElementById('message-content');
    const popup = document.getElementById('message-popup');
    
    if (content) {
        content.textContent = text;
    }
    
    if (popup) {
        setTimeout(() => {
            popup.style.setProperty('display', 'block', 'important');
            popup.style.setProperty('z-index', '2000', 'important');
            popup.style.visibility = 'visible';
            popup.style.opacity = '1';
            popup.style.position = 'fixed';
            popup.style.top = '50%';
            popup.style.left = '50%';
            popup.style.transform = 'translate(-50%, -50%)';
            popup.style.background = 'rgba(0, 0, 0, 0.9)';
            popup.style.padding = '20px';
            popup.style.borderRadius = '15px';
            popup.style.color = '#fff';
            popup.style.maxWidth = '90%';
            popup.style.boxShadow = '0 0 20px rgba(0,0,0,0.7)';
            popup.style.pointerEvents = 'auto';
        }, 0);
    }
    
    if (gameState.controlMode === 'button') {
        document.getElementById('touch-crafting').style.display = 'none';
        document.getElementById('refresh-button').style.display = 'none';
        document.getElementById('touch-joystick-area').style.display = 'none';
        document.getElementById('inventory-btn').style.display = 'none';
        document.getElementById('touch-controls').style.display = 'none';
    }
}

function closeAllPopups() {
    const inventoryPanel = document.getElementById('inventory-panel');
    const crafting = document.getElementById('crafting-ui');
    const message = document.getElementById('message-popup');
    const fuel = document.getElementById('fuel-popup');
    const commandContainer = document.getElementById('command-container');
    const mapUI = document.getElementById('map-ui');
    
    if (inventoryPanel) {
        inventoryPanel.style.display = 'none';
    }
    if (crafting) crafting.style.display = 'none';
    if (message) message.style.display = 'none';
    if (fuel) fuel.style.display = 'none';
    if (commandContainer) commandContainer.style.display = 'none';
    if (mapUI) mapUI.style.display = 'none';
    
    if (gameState.controlMode === 'button') {
        document.getElementById('inventory-btn').style.display = 'block';
        document.getElementById('touch-controls').style.display = 'flex';
        document.getElementById('touch-joystick-area').style.display = 'block';
        document.getElementById('refresh-button').style.display = 'flex';
    }
}

function toggleInventory() {
    const panel = document.getElementById('inventory-panel');
    const isOpen = panel && panel.style.display === 'flex';
    
    closeAllPopups();
    
    if (!isOpen && panel) {
        panel.style.display = 'flex';
        updateInventoryPanel();
        if (gameState.controlMode === 'button') {
            document.getElementById('touch-crafting').style.display = 'none';
            document.getElementById('refresh-button').style.display = 'none';
            document.getElementById('touch-joystick-area').style.display = 'none';
            document.getElementById('touch-controls').style.display = 'none';
        }
    }
}

function togglePopup(popup) {
    const willOpen = popup.style.display !== 'block';
    closeAllPopups();
    popup.style.display = willOpen ? 'block' : 'none';
    
    if (popup.id === 'crafting-ui') updateCraftingButtons();
    
    if (gameState.controlMode === 'button') {
        const isOpen = popup.style.display === 'block';
        document.getElementById('inventory-btn').style.display = isOpen ? 'none' : 'block';
        document.getElementById('refresh-button').style.display = isOpen ? 'none' : 'flex';
        document.getElementById('touch-joystick-area').style.display = isOpen ? 'none' : 'block';
        document.getElementById('touch-controls').style.display = isOpen ? 'none' : 'flex';
        const touchBtn = document.getElementById('touch-crafting');
        if (touchBtn) {
            touchBtn.style.display = 'flex';
            touchBtn.style.zIndex = isOpen ? '100' : '';
        }
    }
}

function updateCraftingButtons() {
    const nearTable = checkNear('.crafting-table');
    const nearFurnace = checkNear('.furnace');
    
    const safeToggle = (id, cond) => { 
        const el = document.getElementById(id); 
        if (el) el.classList.toggle('disabled', !cond); 
    };
    
    safeToggle('craft-axe', gameState.resources.stone >= 1 && gameState.resources.branch >= 1 && gameState.resources.vine >= 1);
    safeToggle('craft-table', gameState.resources.wood >= 1);
    safeToggle('craft-pickaxe', gameState.resources.fullVine >= 1 && gameState.resources.twig >= 1 && gameState.resources.wood >= 1 && nearTable);
    safeToggle('craft-vine', gameState.resources.fullVine >= 1);
    safeToggle('craft-branch', gameState.resources.twig >= 1);
    safeToggle('craft-wooden-sword', gameState.resources.fullVine >= 1 && gameState.resources.twig >= 1 && gameState.resources.wood >= 1 && nearTable);
    safeToggle('craft-furnace', gameState.resources.stone >= 10 && nearTable);
    safeToggle('craft-ladder', gameState.resources.branch >= 7 && nearTable);
    safeToggle('craft-stone-pickaxe', gameState.resources.fullVine >= 1 && gameState.resources.twig >= 1 && gameState.resources.stoneBlock >= 1 && nearTable);
    safeToggle('smelt-cooked-meat', gameState.resources.rawMeat >= 1 && nearFurnace && gameState.furnaceFuel >= 100);
    safeToggle('smelt-hardstone', (gameState.resources.hardStoneOre || 0) >= 1 && nearFurnace && gameState.furnaceFuel >= 200);
    
    updateFurnaceFuelUI();
    
    const crafting = document.getElementById('crafting-ui');
    if (crafting && crafting.style.display === 'block') renderCraftingUI();
}

function renderCraftingUI() {
    const container = document.getElementById('recipe-pages');
    if (!container) return;
    
    const nearTable = checkNear('.crafting-table');
    const nearFurnace = checkNear('.furnace');
    
    const visible = RECIPES.filter(r => {
        if (r.category === 'global') return true;
        if (r.category === 'workbench') return nearTable;
        if (r.category === 'furnace') return nearFurnace;
        return false;
    });
    
    const perPage = 3;
    const pages = Math.max(1, Math.ceil(visible.length / perPage));
    craftingPagination.totalPages = pages;
    if (!gameState.craftingPage || gameState.craftingPage < 1) gameState.craftingPage = 1;
    if (gameState.craftingPage > pages) gameState.craftingPage = pages;
    
    container.innerHTML = '';
    
    for (let p = 0; p < pages; p++) {
        const pageDiv = document.createElement('div');
        pageDiv.className = 'recipe-page';
        pageDiv.style.display = (p === gameState.craftingPage - 1) ? 'block' : 'none';
        
        const slice = visible.slice(p * perPage, p * perPage + perPage);
        
        slice.forEach(rec => {
            const row = document.createElement('div');
            row.className = 'recipe';
            
            const itemsDiv = document.createElement('div');
            itemsDiv.className = 'recipe-items';
            
            rec.ingredients.forEach(it => {
                const itemDiv = document.createElement('div');
                itemDiv.className = 'recipe-item';
                
                const icon = document.createElement('div');
                icon.className = 'recipe-icon';
                const res = RESOURCES.find(r => r.key === it.k);
                icon.style.backgroundColor = res ? res.color : '#888';
                icon.textContent = res ? res.name : it.k;
                
                itemDiv.appendChild(icon);
                itemDiv.appendChild(document.createElement('span')).textContent = `×${it.q}`;
                itemsDiv.appendChild(itemDiv);
            });
            
            row.appendChild(itemsDiv);
            
            const actionDiv = document.createElement('div');
            actionDiv.className = 'recipe-item';
            
            const iconOut = document.createElement('div');
            iconOut.className = 'recipe-icon';
            iconOut.style.background = '#FF8C00';
            iconOut.textContent = rec.title;
            
            actionDiv.appendChild(iconOut);
            
            const btn = document.createElement('button');
            btn.className = 'btn';
            btn.id = `dyn-craft-${rec.id}`;
            btn.textContent = '制作';
            
            const canCraft = rec.ingredients.every(it => (gameState.resources[it.k] || 0) >= it.q) && 
                           (rec.category !== 'workbench' || nearTable) && 
                           (rec.category !== 'furnace' || nearFurnace);
            
            if (!canCraft) btn.classList.add('disabled');
            
            btn.onclick = () => {
                if (btn.classList.contains('disabled')) {
                    showMessage('无法制作：条件不满足或距离不足');
                    return;
                }
                if (typeof window[rec.func] === 'function') {
                    const ok = window[rec.func]();
                    if (ok === false) return;
                } else {
                    showMessage('制作函数未实现');
                    return;
                }
                updateInventoryPanel();
                renderCraftingUI();
            };
            
            btn.addEventListener('touchstart', (e) => { 
                e.preventDefault(); 
                e.stopPropagation(); 
                btn.click(); 
            }, { passive: false });
            
            actionDiv.appendChild(btn);
            
            const desc = document.createElement('div');
            desc.className = 'recipe-requirement';
            desc.innerHTML = rec.desc || '';
            actionDiv.appendChild(desc);
            
            row.appendChild(actionDiv);
            pageDiv.appendChild(row);
        });
        
        container.appendChild(pageDiv);
    }
    
    craftingPagination.updatePageDisplay();
    updateFurnaceFuelUI();
}

function craftAxe() {
    if (gameState.resources.stone >= 1 && gameState.resources.branch >= 1 && gameState.resources.vine >= 1) {
        updateResource('stone', -1);
        updateResource('branch', -1);
        updateResource('vine', -1);
        updateResource('axe', 1);
        gameState.axeDurability = 10;
        updateInventoryPanel();
        showMessage("制作了一把粗制碎石斧！");
        updateCraftingButtons();
        const crafting = document.getElementById('crafting-ui');
        if (crafting) {
            crafting.style.display = 'block';
            renderCraftingUI();
        }
        return true;
    } else {
        showMessage("材料不足！需要1个石子、1个木棍和1个破碎藤蔓");
        return false;
    }
}

function craftTable() {
    if (gameState.resources.wood >= 1) {
        updateResource('wood', -1);
        const pos = findNearbyFreePosition(60, 60);
        createCraftingTable(pos.x, pos.y);
        updateInventoryPanel();
        showMessage("制作了一个合成台！");
        checkNearCraftingTable();
        updateCraftingButtons();
        checkRefreshButtonPosition();
        const crafting = document.getElementById('crafting-ui');
        if (crafting) {
            crafting.style.display = 'block';
            renderCraftingUI();
        }
        return true;
    } else {
        showMessage("材料不足！需要1个木材");
        return false;
    }
}

function craftPickaxe() {
    if (gameState.resources.fullVine >= 1 && gameState.resources.twig >= 1 && gameState.resources.wood >= 1) {
        if (gameState.nearCraftingTable) {
            updateResource('fullVine', -1);
            updateResource('twig', -1);
            updateResource('wood', -1);
            updateResource('pickaxe', 1);
            gameState.pickaxeDurability = 10;
            updateInventoryPanel();
            showMessage("制作了一把木镐（耐久10）！");
            updateCraftingButtons();
            const crafting = document.getElementById('crafting-ui');
            if (crafting) {
                crafting.style.display = 'block';
                renderCraftingUI();
            }
            return true;
        } else {
            showMessage("需要靠近合成台才能制作木镐！");
            return false;
        }
    } else {
        showMessage("材料不足！需要1个完整藤蔓、1个树枝和1个木材");
        return false;
    }
}

function craftStonePickaxe() {
    if (gameState.resources.fullVine >= 1 && gameState.resources.twig >= 1 && gameState.resources.stoneBlock >= 1) {
        if (gameState.nearCraftingTable) {
            updateResource('fullVine', -1);
            updateResource('twig', -1);
            updateResource('stoneBlock', -1);
            gameState.resources.stonePickaxe = (gameState.resources.stonePickaxe || 0) + 1;
            gameState.stonePickaxeDurability = 30;
            updateInventoryPanel();
            showMessage("制作了一把石镐（耐久30）！");
            updateCraftingButtons();
            const crafting = document.getElementById('crafting-ui');
            if (crafting) {
                crafting.style.display = 'block';
                renderCraftingUI();
            }
            return true;
        } else {
            showMessage("需要靠近合成台才能制作石镐！");
            return false;
        }
    } else {
        showMessage("材料不足！需要1个完整藤蔓、1个树枝和1个石块");
        return false;
    }
}

function craftHardStonePickaxe() {
    if ((gameState.resources.hardStoneBlock||0) >= 3 && (gameState.resources.twig||0) >= 1 && (gameState.resources.fullVine||0) >= 1) {
        if (gameState.nearCraftingTable) {
            updateResource('hardStoneBlock', -3);
            updateResource('twig', -1);
            updateResource('fullVine', -1);
            gameState.resources.hardStonePickaxe = (gameState.resources.hardStonePickaxe||0) + 1;
            gameState.hardStonePickaxeDurability = 100;
            updateInventoryPanel();
            showMessage('制作了一把硬石镐（耐久100）！');
            updateCraftingButtons();
            const crafting = document.getElementById('crafting-ui');
            if (crafting) {
                crafting.style.display = 'block';
                renderCraftingUI();
            }
            return true;
        } else {
            showMessage('需要靠近合成台才能制作硬石镐！');
            return false;
        }
    } else {
        showMessage('材料不足！需要3个硬石块、1个树枝和1个完整藤蔓');
        return false;
    }
}

function craftHardStoneSword() {
    if ((gameState.resources.hardStoneBlock||0) >= 2 && (gameState.resources.twig||0) >= 1 && (gameState.resources.fullVine||0) >= 1) {
        if (gameState.nearCraftingTable) {
            updateResource('hardStoneBlock', -2);
            updateResource('twig', -1);
            updateResource('fullVine', -1);
            gameState.resources.hardStoneSword = (gameState.resources.hardStoneSword||0) + 1;
            gameState.hardStoneSwordDurability = 150;
            updateInventoryPanel();
            showMessage('制作了一把硬石剑！');
            updateCraftingButtons();
            updateAttack();
            const crafting = document.getElementById('crafting-ui');
            if (crafting) {
                crafting.style.display = 'block';
                renderCraftingUI();
            }
            return true;
        } else {
            showMessage('需要靠近合成台才能制作硬石剑！');
            return false;
        }
    } else {
        showMessage('材料不足！需要2个硬石块、1个树枝和1个完整藤蔓');
        return false;
    }
}

function craftHardStoneAxe() {
    if ((gameState.resources.hardStoneBlock||0) >= 2 && (gameState.resources.branch||0) >= 1) {
        if (gameState.nearCraftingTable) {
            updateResource('hardStoneBlock', -2);
            updateResource('branch', -1);
            gameState.resources.hardStoneAxe = (gameState.resources.hardStoneAxe||0) + 1;
            gameState.hardStoneAxeDurability = 50;
            updateInventoryPanel();
            showMessage('制作了一把硬石斧！');
            updateCraftingButtons();
            const crafting = document.getElementById('crafting-ui');
            if (crafting) {
                crafting.style.display = 'block';
                renderCraftingUI();
            }
            return true;
        } else {
            showMessage('需要靠近合成台才能制作硬石斧！');
            return false;
        }
    } else {
        showMessage('材料不足！需要2个硬石块和1个木棍');
        return false;
    }
}

function craftFurnace() {
    if (gameState.resources.stone >= 10 && checkNearCraftingTable()) {
        updateResource('stone', -10);
        gameState.resources.furnace = (gameState.resources.furnace || 0) + 1;
        updateInventoryPanel();
        showMessage('制作了一个熔炉！');
        updateCraftingButtons();
        const crafting = document.getElementById('crafting-ui');
        if (crafting) {
            crafting.style.display = 'block';
            renderCraftingUI();
        }
        return true;
    } else if (gameState.resources.stone < 10) {
        showMessage('材料不足！需要10个石子');
        return false;
    } else {
        showMessage('需要靠近合成台才能制作熔炉！');
        return false;
    }
}

function craftLadder() {
    if (gameState.resources.branch >= 7) {
        if (gameState.nearCraftingTable) {
            updateResource('branch', -7);
            gameState.resources.ladder = (gameState.resources.ladder || 0) + 1;
            updateInventoryPanel();
            showMessage("制作了一个梯子！");
            updateCraftingButtons();
            const crafting = document.getElementById('crafting-ui');
            if (crafting) {
                crafting.style.display = 'block';
                renderCraftingUI();
            }
            return true;
        } else {
            showMessage("需要靠近合成台才能制作梯子！");
            return false;
        }
    } else {
        showMessage("材料不足！需要7个木棍");
        return false;
    }
}

function craftWoodenSword() {
    if (gameState.resources.fullVine >= 1 && gameState.resources.twig >= 1 && gameState.resources.wood >= 1) {
        if (gameState.nearCraftingTable) {
            updateResource('fullVine', -1);
            updateResource('twig', -1);
            updateResource('wood', -1);
            gameState.resources.woodenSword++;
            gameState.woodenSwordDurability = 30;
            updateInventoryPanel();
            showMessage("制作了一把木剑！");
            updateCraftingButtons();
            updateAttack();
            const crafting = document.getElementById('crafting-ui');
            if (crafting) {
                crafting.style.display = 'block';
                renderCraftingUI();
            }
            return true;
        } else {
            showMessage("需要靠近合成台才能制作木剑！");
            return false;
        }
    } else {
        showMessage("材料不足！需要1个完整藤蔓、1个树枝和1个木材");
        return false;
    }
}

function craftBranch() {
    if (gameState.resources.twig < 1) {
        showMessage("没有树枝可分解！");
        return false;
    }
    updateResource('twig', -1);
    updateResource('branch', 3);
    updateInventoryPanel();
    showMessage("将1个树枝分解为3个木棍！");
    updateCraftingButtons();
    const crafting = document.getElementById('crafting-ui');
    if (crafting) {
        crafting.style.display = 'block';
        renderCraftingUI();
    }
    return true;
}

function craftVine() {
    if (gameState.resources.fullVine < 1) {
        showMessage("没有完整藤蔓可分解！");
        return false;
    }
    updateResource('fullVine', -1);
    updateResource('vine', 3);
    updateInventoryPanel();
    showMessage("将1个完整藤蔓分解为3个破碎藤蔓！");
    updateCraftingButtons();
    const crafting = document.getElementById('crafting-ui');
    if (crafting) {
        crafting.style.display = 'block';
        renderCraftingUI();
    }
    return true;
}

function updateAttack() {
    gameState.attack = 1 + (gameState.resources.hardStoneSword > 0 ? 3 : (gameState.resources.woodenSword > 0 ? 1 : 0));
}

function gridKey(col, row) {
    return `${col},${row}`;
}

function isGridCellOccupied(col, row, width, height) {
    const cols = Math.ceil(width / GRID_SIZE);
    const rows = Math.ceil(height / GRID_SIZE);
    
    for (let c = col; c < col + cols; c++) {
        for (let r = row; r < row + rows; r++) {
            if (gameState.gridOccupied.has(gridKey(c, r))) {
                return true;
            }
        }
    }
    return false;
}

function occupyGridCells(col, row, width, height) {
    const cols = Math.ceil(width / GRID_SIZE);
    const rows = Math.ceil(height / GRID_SIZE);
    
    for (let c = col; c < col + cols; c++) {
        for (let r = row; r < row + rows; r++) {
            gameState.gridOccupied.add(gridKey(c, r));
        }
    }
}

function freeGridCells(col, row, width, height) {
    const cols = Math.ceil(width / GRID_SIZE);
    const rows = Math.ceil(height / GRID_SIZE);
    
    for (let c = col; c < col + cols; c++) {
        for (let r = row; r < row + rows; r++) {
            gameState.gridOccupied.delete(gridKey(c, r));
        }
    }
}

function findFreePosition(width, height, attempts = 100) {
    const cols = Math.ceil(width / GRID_SIZE);
    const rows = Math.ceil(height / GRID_SIZE);
    const maxCol = Math.floor(window.innerWidth / GRID_SIZE) - cols;
    const maxRow = Math.floor(window.innerHeight / GRID_SIZE) - rows;
    
    if (maxCol < 0 || maxRow < 0) {
        return { x: 0, y: 0 };
    }
    
    const tried = new Set();
    
    for (let i = 0; i < attempts; i++) {
        const col = Math.floor(Math.random() * (maxCol + 1));
        const row = Math.floor(Math.random() * (maxRow + 1));
        
        if (tried.has(gridKey(col, row))) continue;
        tried.add(gridKey(col, row));
        
        if (!isGridCellOccupied(col, row, width, height)) {
            occupyGridCells(col, row, width, height);
            return { x: col * GRID_SIZE, y: row * GRID_SIZE };
        }
    }
    
    for (let col = 0; col <= maxCol; col++) {
        for (let row = 0; row <= maxRow; row++) {
            if (!isGridCellOccupied(col, row, width, height)) {
                occupyGridCells(col, row, width, height);
                return { x: col * GRID_SIZE, y: row * GRID_SIZE };
            }
        }
    }
    
    return { x: 0, y: 0 };
}

function findNearbyFreePosition(width, height) {
    const playerX = gameState.playerX || window.innerWidth / 2;
    const playerY = gameState.playerY || window.innerHeight / 2;
    const playerCol = Math.floor(playerX / GRID_SIZE);
    const playerRow = Math.floor(playerY / GRID_SIZE);
    
    const cols = Math.ceil(width / GRID_SIZE);
    const rows = Math.ceil(height / GRID_SIZE);
    const maxCol = Math.floor(window.innerWidth / GRID_SIZE) - cols;
    const maxRow = Math.floor(window.innerHeight / GRID_SIZE) - rows;
    
    const offsets = [
        {dc:-1,dr:0},{dc:1,dr:0},{dc:0,dr:-1},{dc:0,dr:1},
        {dc:-1,dr:-1},{dc:1,dr:1},{dc:-2,dr:0},{dc:2,dr:0},{dc:0,dr:-2},{dc:0,dr:2}
    ];
    
    for (const off of offsets) {
        const col = playerCol + off.dc;
        const row = playerRow + off.dr;
        
        if (col < 0 || row < 0 || col > maxCol || row > maxRow) continue;
        if (!isGridCellOccupied(col, row, width, height)) {
            occupyGridCells(col, row, width, height);
            return { x: col * GRID_SIZE, y: row * GRID_SIZE };
        }
    }
    
    return findFreePosition(width, height);
}

function isBlockedAt(x, y, w = 50, h = 50, excludeEl = null) {
    if (!gameState.collisionEnabled) return false;
    
    let surfaceContainer, undergroundContainer;
    if (gameState.currentMap === 'surface') {
        surfaceContainer = document.getElementById('game-container');
        
        const col = Math.floor(x / GRID_SIZE);
        const row = Math.floor(y / GRID_SIZE);
        if (isGridCellOccupied(col, row, w, h)) {
            return true;
        }
    } else if (gameState.currentMap === 'underground' && gameState.currentHole && gameState.currentHole.underground) {
        undergroundContainer = gameState.currentHole.underground.container;
    }
    
    if (surfaceContainer) {
        const blocks = surfaceContainer.querySelectorAll('.tree-trunk, .tree-leaf, .stone, .crafting-table, .furnace, .animal');
        for (const el of blocks) {
            if (el === excludeEl) continue;
            
            const rect = el.getBoundingClientRect();
            
            if (x < rect.right && x + w > rect.left && y < rect.bottom && y + h > rect.top) {
                return true;
            }
        }
    }
    
    if (undergroundContainer) {
        const ugTiles = undergroundContainer.querySelectorAll('.ug-tile');
        for (const tile of ugTiles) {
            if (tile.dataset.type === 'empty') continue;
            
            const rect = tile.getBoundingClientRect();
            if (x < rect.right && x + w > rect.left && y < rect.bottom && y + h > rect.top) {
                return true;
            }
        }
    }
    
    return false;
}

function createElement(className, x, y, width, height) {
    const el = document.createElement('div');
    el.className = `${className} game-element`;
    
    const w = width || (className === 'tree-trunk' ? 20 : (className === 'crafting-table' ? 60 : (className === 'stone' ? 50 : 50)));
    const h = height || (className === 'tree-trunk' ? 70 : (className === 'crafting-table' ? 60 : (className === 'stone' ? 50 : 50)));
    
    el.style.width = w + 'px';
    el.style.height = h + 'px';
    
    if (x == null || y == null) {
        const pos = findFreePosition(w, h);
        el.style.left = pos.x + 'px';
        el.style.top = pos.y + 'px';
    } else {
        el.style.left = x + 'px';
        el.style.top = y + 'px';
    }
    
    if (className === 'tree-trunk') {
        const bar = document.createElement('div');
        bar.className = 'progress-bar';
        bar.innerHTML = '<div class="progress-fill"></div>';
        el.appendChild(bar);
    }
    
    const container = document.getElementById('game-container');
    if (container) container.appendChild(el);
    
    if (['tree-leaf', 'stone', 'tree-trunk'].includes(className)) {
        attachLongPress(el, () => {
            if (!isWithinInteractRange(el, 2)) {
                showMessage('太远了！靠近后长按以采集。');
                return;
            }
            if (className === 'tree-leaf') collectLeaf(el);
            else if (className === 'stone') collectStone(el);
            else if (className === 'tree-trunk') {
                const leaf = el.previousElementSibling;
                chopTree(el, leaf?.classList.contains('tree-leaf') ? leaf : null);
            }
        });
    }
    
    return el;
}

function createCraftingTable(x, y) {
    const table = createElement('crafting-table', x, y, 60, 60);
    table.textContent = '合成台';
    return table;
}

function attachLongPress(el, callback, holdMs = 400) {
    let timer = null;
    const start = (e) => { 
        e.preventDefault && e.preventDefault(); 
        timer = setTimeout(() => { 
            timer = null; 
            callback(); 
        }, holdMs); 
    };
    const cancel = () => { 
        if (timer) { 
            clearTimeout(timer); 
            timer = null; 
        } 
    };
    
    el.addEventListener('mousedown', start);
    el.addEventListener('touchstart', start, { passive: false });
    el.addEventListener('mouseup', cancel);
    el.addEventListener('mouseleave', cancel);
    el.addEventListener('touchend', cancel);
    el.addEventListener('touchcancel', cancel);
}

function isWithinInteractRange(el, multiplier = 2) {
    const playerX = gameState.playerX || window.innerWidth / 2;
    const playerY = gameState.playerY || window.innerHeight / 2;
    
    const rect = el.getBoundingClientRect();
    const centerX = rect.left + rect.width / 2;
    const centerY = rect.top + rect.height / 2;
    
    const dist = Math.hypot(centerX - playerX, centerY - playerY);
    const elRadius = Math.max(el.offsetWidth, el.offsetHeight) / 2;
    const playerRadius = 25;
    
    return dist <= elRadius * multiplier + playerRadius;
}

function collectLeaf(leaf) {
    if (!isWithinInteractRange(leaf, 2)) return;
    if (gameState.resources.axe > 0 && gameState.axeDurability > 0) {
        startBreaking(leaf, 'twig');
        setTimeout(() => { 
            updateResource('fullVine', 1); 
            updateInventoryPanel(); 
        }, 600);
    } else {
        startBreaking(leaf, Math.random() < 0.5 ? 'vine' : 'branch');
    }
}

function collectStone(stone) {
    if (!isWithinInteractRange(stone, 2)) return;
    startBreaking(stone, 'stone');
}

function chopTree(trunk, leaf) {
    if (!isWithinInteractRange(trunk, 2)) {
        showMessage('太远了！靠近后长按以砍树。');
        return;
    }
    if (gameState.resources.axe > 0 && gameState.axeDurability > 0) {
        if (leaf && !breakingElements.has(leaf)) {
            startBreaking(leaf, 'twig');
            setTimeout(() => {
                updateResource('fullVine', 1);
                updateInventoryPanel();
            }, 600);
        }
        if (!breakingElements.has(trunk)) startBreaking(trunk, 'wood', true);
    } else {
        showMessage('需要斧头才能砍树！');
    }
}

const breakingElements = new Map();

function startBreaking(element, resourceType, isTree = false) {
    if (breakingElements.has(element)) return;
    
    for (const [el] of breakingElements) {
        resetBreakingProgress(el);
    }
    
    let breakTime = isTree ? 5000 : 500;
    let toolUsed = null;
    
    if (isTree) {
        if (gameState.resources.hardStoneAxe > 0 && gameState.hardStoneAxeDurability > 0) {
            toolUsed = 'hardStoneAxe';
        } else if (gameState.resources.axe > 0 && gameState.axeDurability > 0) {
            toolUsed = 'axe';
        }
        const speedFactor = (toolUsed === 'hardStoneAxe') ? 3 : (toolUsed === 'axe' ? 1 : 1);
        breakTime = Math.max(200, breakTime / speedFactor);
    }
    
    let progress = 0;
    const progressBar = element.querySelector('.progress-fill');
    
    breakingElements.set(element, {
        progress: 0,
        interval: setInterval(() => {
            progress += 100;
            const percent = Math.min(100, (progress / breakTime) * 100);
            breakingElements.get(element).progress = percent;
            if (progressBar) progressBar.style.width = `${percent}%`;
            if (progress >= breakTime) finishBreaking(element, resourceType, isTree, toolUsed);
        }, 100),
        isTree,
        toolUsed
    });
    
    element.classList.add('breaking');
}

function finishBreaking(element, resourceType, isTree, toolUsed) {
    const info = breakingElements.get(element) || {};
    resetBreakingProgress(element);
    element.classList.add('broken');
    
    const rect = element.getBoundingClientRect();
    const col = Math.floor(rect.left / GRID_SIZE);
    const row = Math.floor(rect.top / GRID_SIZE);
    
    setTimeout(() => {
        element.remove();
        freeGridCells(col, row, rect.width, rect.height);
        
        if (isTree) {
            updateResource('wood', 1);
            if (info.toolUsed === 'hardStoneAxe' && gameState.hardStoneAxeDurability > 0) {
                updateDurability('hardStoneAxeDurability', 50);
            } else if (info.toolUsed === 'axe' && gameState.axeDurability > 0) {
                updateDurability('axeDurability', 10);
            }
        } else if (resourceType === 'fullVine') {
            updateResource('fullVine', 1);
        } else {
            updateResource(resourceType, 1);
        }
        updateInventoryPanel();
    }, 500);
}

function resetBreakingProgress(element) {
    if (breakingElements.has(element)) {
        const d = breakingElements.get(element);
        clearInterval(d.interval);
        element.classList.remove('breaking');
        const bar = element.querySelector('.progress-fill');
        if (bar) bar.style.width = '0%';
        breakingElements.delete(element);
    }
}

function digHole() {
    let pickaxeType = null;
    let durabilityKey = null;
    let durabilityCost = 0;
    
    if (gameState.resources.hardStonePickaxe > 0 && gameState.hardStonePickaxeDurability >= 1) {
        pickaxeType = 'hardStonePickaxe';
        durabilityKey = 'hardStonePickaxeDurability';
        durabilityCost = 1;
    } else if (gameState.resources.stonePickaxe > 0 && gameState.stonePickaxeDurability >= 1) {
        pickaxeType = 'stonePickaxe';
        durabilityKey = 'stonePickaxeDurability';
        durabilityCost = 1;
    } else if (gameState.resources.pickaxe > 0 && gameState.pickaxeDurability >= 2) {
        pickaxeType = 'pickaxe';
        durabilityKey = 'pickaxeDurability';
        durabilityCost = 2;
    }
    
    if (!pickaxeType) {
        showMessage('需要镐来挖洞！');
        return;
    }
    
    const playerX = gameState.playerX || window.innerWidth / 2;
    const playerY = gameState.playerY || window.innerHeight / 2;
    const hx = playerX - 20;
    const hy = playerY - 20;
    
    for (const h of gameState.holes) {
        const dist = Math.hypot(h.x - hx, h.y - hy);
        if (dist < 30) {
            showMessage('这里已经有洞了');
            return;
        }
    }
    
    gameState[durabilityKey] -= durabilityCost;
    if (gameState[durabilityKey] <= 0) {
        updateResource(pickaxeType, -1);
        if (gameState.resources[pickaxeType] > 0) {
            if (pickaxeType === 'hardStonePickaxe') {
                gameState[durabilityKey] = 200;
            } else if (pickaxeType === 'stonePickaxe') {
                gameState[durabilityKey] = 100;
            } else {
                gameState[durabilityKey] = 10;
            }
        }
    }
    
    const hole = { x: hx, y: hy, hasLadder: false, underground: null, id: Date.now() };
    gameState.holes.push(hole);
    
    const holeEl = document.createElement('div');
    holeEl.className = 'hole game-element';
    holeEl.style.left = hx + 'px';
    holeEl.style.top = hy + 'px';
    holeEl.style.width = '40px';
    holeEl.style.height = '40px';
    holeEl.style.background = '#000';
    holeEl.style.borderRadius = '6px';
    holeEl.dataset.holeId = hole.id;
    
    const container = document.getElementById('game-container');
    if (container) container.appendChild(holeEl);
    
    updateInventoryPanel();
    showMessage('挖好了一个洞！');
}

function placeLadder() {
    let nearHole = null;
    const playerX = gameState.playerX || window.innerWidth / 2;
    const playerY = gameState.playerY || window.innerHeight / 2;
    
    for (const h of gameState.holes) {
        const d = Math.hypot(h.x - playerX, h.y - playerY);
        if (d < 80) {
            nearHole = h;
            break;
        }
    }
    
    if (!nearHole) {
        showMessage('附近没有可放置梯子的洞！');
        return;
    }
    if (!gameState.resources.ladder) {
        showMessage('没有梯子可放置！');
        return;
    }
    if (nearHole.hasLadder) {
        showMessage('该洞已有梯子！');
        return;
    }
    
    nearHole.hasLadder = true;
    updateResource('ladder', -1);
    updateInventoryPanel();
    unlockUndergroundMap();
    
    const ladderEl = document.createElement('div');
    ladderEl.className = 'ladder game-element';
    ladderEl.style.left = (nearHole.x + 10) + 'px';
    ladderEl.style.top = nearHole.y + 'px';
    ladderEl.style.width = '20px';
    ladderEl.style.height = '40px';
    ladderEl.style.background = '#D2B48C';
    ladderEl.dataset.holeId = nearHole.id;
    
    const container = document.getElementById('game-container');
    if (container) container.appendChild(ladderEl);
    
    showMessage('放置了梯子，现在可以进入矿洞');
}

function openMapUI() {
    const mapUI = document.getElementById('map-ui');
    const mapItems = document.querySelectorAll('.map-item');
    
    mapItems.forEach(item => {
        const mapId = item.dataset.map;
        const statusEl = item.querySelector('.map-status');
        
        item.classList.remove('disabled');
        
        if (gameState.currentMap === mapId) {
            statusEl.textContent = '当前';
            statusEl.className = 'map-status current';
            item.classList.add('disabled');
        } else if (gameState.unlockedMaps.includes(mapId)) {
            statusEl.textContent = '已解锁';
            statusEl.className = 'map-status available';
        } else {
            statusEl.textContent = '未解锁';
            statusEl.className = 'map-status locked';
            item.classList.add('disabled');
        }
    });
    
    mapUI.style.display = 'block';
}

function closeMapUI() {
    const mapUI = document.getElementById('map-ui');
    mapUI.style.display = 'none';
}

function unlockUndergroundMap() {
    if (!gameState.unlockedMaps.includes('underground')) {
        gameState.unlockedMaps.push('underground');
        showMessage('地下矿洞已解锁！');
    }
}

function switchMap(mapId) {
    if (gameState.currentMap === mapId) return;
    if (!gameState.unlockedMaps.includes(mapId)) return;
    
    const canSwitch = checkCanSwitchMap();
    if (!canSwitch) {
        showMessage('请回到地图刷新区域再切换地图！');
        return;
    }
    
    saveCurrentMapState();
    
    if (mapId === 'surface') {
        loadSurfaceMap();
    } else if (mapId === 'underground') {
        loadUndergroundMap();
    }
    
    closeMapUI();
}

function checkCanSwitchMap() {
    const playerX = gameState.playerX || window.innerWidth / 2;
    const playerY = gameState.playerY || window.innerHeight / 2;
    
    const refreshRadius = 150;
    const centerX = window.innerWidth - 120;
    const centerY = 100;
    
    const distance = Math.hypot(playerX - centerX, playerY - centerY);
    return distance < refreshRadius;
}

function saveCurrentMapState() {
    if (gameState.currentMap === 'surface') {
        const container = document.getElementById('game-container');
        gameState.surfaceSnapshot = {
            innerHTML: container.innerHTML,
            playerX: gameState.playerX,
            playerY: gameState.playerY
        };
    } else if (gameState.currentMap === 'underground' && gameState.currentHole) {
        const hole = gameState.currentHole;
        hole.playerX = gameState.playerX;
        hole.playerY = gameState.playerY;
    }
}

function loadSurfaceMap() {
    gameState.collisionEnabled = false;
    
    const container = document.getElementById('game-container');
    const player = document.getElementById('phaser-player');
    
    if (gameState.currentHole && gameState.currentHole.underground) {
        gameState.currentHole.underground.container.style.display = 'none';
        if (player) container.appendChild(player);
    }
    
    if (gameState.surfaceSnapshot) {
        container.innerHTML = gameState.surfaceSnapshot.innerHTML;
    }
    
    gameState.playerX = window.innerWidth - 70;
    gameState.playerY = 50;
    
    container.style.display = 'block';
    gameState.currentMap = 'surface';
    gameState.undergroundOpen = false;
    
    const hasLadderHole = gameState.holes.some(h => h.hasLadder);
    if (hasLadderHole) {
        unlockUndergroundMap();
    }
    
    updateHoleButtons();
    updateCraftingButtons();
    updatePlayerPosition();
    
    setTimeout(() => {
        gameState.collisionEnabled = true;
    }, 100);
}

function loadUndergroundMap() {
    gameState.collisionEnabled = false;
    
    let hole = gameState.currentHole;
    
    if (!hole) {
        for (const h of gameState.holes) {
            if (h.hasLadder) {
                hole = h;
                break;
            }
        }
    }
    
    if (!hole) {
        if (gameState.cheatModeEnabled) {
            hole = { 
                x: window.innerWidth / 2, 
                y: window.innerHeight / 2, 
                hasLadder: true, 
                underground: null, 
                id: Date.now(),
                playerX: undefined,
                playerY: undefined
            };
            gameState.holes.push(hole);
        } else {
            showMessage('没有可进入的矿洞');
            gameState.collisionEnabled = true;
            return false;
        }
    }
    
    if (!hole.surfaceSnapshot) saveSurfaceSnapshot(hole);
    if (!hole.underground) hole.underground = generateUndergroundForHole(hole);
    
    const container = document.getElementById('game-container');
    const undergroundData = hole.underground;
    const ug = undergroundData.container;
    
    container.style.display = 'none';
    ug.style.display = 'block';
    ug.style.zIndex = 90;
    
    const player = document.getElementById('phaser-player');
    if (player) ug.appendChild(player);
    
    gameState.playerX = (undergroundData.cols - 0.5) * undergroundData.tile;
    gameState.playerY = undergroundData.tile / 2;
    
    gameState.currentMap = 'underground';
    gameState.currentHole = hole;
    gameState.undergroundOpen = true;
    
    updateHoleButtons();
    updateCraftingButtons();
    updatePlayerPosition();
    
    setTimeout(() => {
        gameState.collisionEnabled = true;
    }, 100);
    
    return true;
}

function enterUnderground(hole) {
    const surfaceRefreshCount = gameState.refreshCounts.surface || 0;
    if (surfaceRefreshCount < 5) {
        showMessage(`需要主世界刷新 5 次才能进入地下！当前刷新次数: ${surfaceRefreshCount}/5`);
        return;
    }
    
    unlockUndergroundMap();
    openMapUI();
}

function exitUnderground() {
    openMapUI();
}

function saveSurfaceSnapshot(hole) {
    const snapshot = [];
    const container = document.getElementById('game-container');
    if (!container) return;
    
    container.querySelectorAll('.game-element').forEach(el => {
        if (el.id === 'phaser-player') return;
        
        const ds = {};
        for (const k in el.dataset) ds[k] = el.dataset[k];
        
        snapshot.push({
            className: el.className.replace(' game-element', ''),
            left: el.style.left,
            top: el.style.top,
            width: el.style.width,
            height: el.style.height,
            innerHTML: el.innerHTML,
            text: el.textContent,
            dataset: ds
        });
        
        el.remove();
    });
    
    hole.surfaceSnapshot = snapshot;
}

function generateUndergroundForHole(hole) {
    const tile = 80;
    const cols = Math.ceil(window.innerWidth / tile);
    const rows = Math.ceil(window.innerHeight / tile);
    
    const container = document.createElement('div');
    container.className = 'underground-container';
    container.style.position = 'fixed';
    container.style.left = '0';
    container.style.top = '0';
    container.style.width = (cols * tile) + 'px';
    container.style.height = (rows * tile) + 'px';
    container.style.background = '#222';
    container.style.display = 'none';
    container.style.zIndex = 90;
    document.body.appendChild(container);
    
    hole.underground = { tiles: [], container, cols, rows, tile };
    
    const chestRow = Math.floor(Math.random() * (rows - 2)) + 1;
    const chestCol = Math.floor(Math.random() * (cols - 2)) + 1;
    
    for (let r = 0; r < rows; r++) {
        for (let c = 0; c < cols; c++) {
            const cx = c * tile;
            const cy = r * tile;
            
            const tileEl = document.createElement('div');
            tileEl.className = 'ug-tile';
            tileEl.style.position = 'absolute';
            tileEl.style.left = cx + 'px';
            tileEl.style.top = cy + 'px';
            tileEl.style.width = tile + 'px';
            tileEl.style.height = tile + 'px';
            tileEl.style.boxSizing = 'border-box';
            
            const exitCol = cols - 1;
            const exitRow = 0;
            
            if (r === exitRow && c === exitCol) {
                tileEl.style.background = 'transparent';
                tileEl.dataset.type = 'empty';
                tileEl.dataset.exit = 'true';
            } else if (r === exitRow && c === exitCol - 1) {
                tileEl.style.background = 'transparent';
                tileEl.dataset.type = 'empty';
            } else if (r === exitRow + 1 && c === exitCol) {
                tileEl.style.background = 'transparent';
                tileEl.dataset.type = 'empty';
            } else if (r === chestRow && c === chestCol) {
                tileEl.dataset.type = 'chest';
                tileEl.style.background = 'linear-gradient(135deg, #8B4513 0%, #654321 50%, #4a2c0a 100%)';
                tileEl.style.border = '3px solid #FFD700';
                tileEl.style.borderRadius = '8px';
                tileEl.style.display = 'flex';
                tileEl.style.alignItems = 'center';
                tileEl.style.justifyContent = 'center';
                tileEl.style.fontSize = '2rem';
                tileEl.style.zIndex = 10;
                tileEl.textContent = '📦';
                tileEl.dataset.opened = 'false';
            } else {
                const rand = Math.random();
                if (rand < 0.05) {
                    tileEl.dataset.type = 'fuelOre';
                    tileEl.style.background = '#ff8f2b';
                } else if (rand < 0.15) {
                    tileEl.dataset.type = 'hardStoneOre';
                    tileEl.style.background = '#6b6b6b';
                } else {
                    tileEl.dataset.type = 'stoneBlock';
                    tileEl.style.background = '#9E9E9E';
                }
                tileEl.style.border = '1px solid rgba(0,0,0,0.15)';
            }
            
            if (tileEl.dataset.type !== 'chest' && tileEl.dataset.type !== 'empty') {
                attachLongPress(tileEl, () => {
                    startMiningUnderground(tileEl);
                });
            }
            
            container.appendChild(tileEl);
            hole.underground.tiles.push(tileEl);
        }
    }
    
    return hole.underground;
}

function startMiningUnderground(tileEl) {
    const type = tileEl.dataset.type;
    if (!type) return;
    
    if (type === 'chest') {
        const playerX = gameState.playerX || window.innerWidth / 2;
        const playerY = gameState.playerY || window.innerHeight / 2;
        
        const rect = tileEl.getBoundingClientRect();
        const centerX = rect.left + rect.width / 2;
        const centerY = rect.top + rect.height / 2;
        const dist = Math.hypot(centerX - playerX, centerY - playerY);
        
        if (dist > 120) {
            showMessage('太远了，靠近后按 F 打开宝箱。');
            return;
        }
        
        if (tileEl.dataset.opened === 'true') {
            showMessage('宝箱已经被打开了！');
            return;
        }
        
        tileEl.dataset.opened = 'true';
        tileEl.remove();
        
        gameState.resources.gold = (gameState.resources.gold || 0) + 1;
        updateInventoryPanel();
        showMessage('获得了 1 金币！');
        updateHoleButtons();
        return;
    }
    
    const playerX = gameState.playerX || window.innerWidth / 2;
    const playerY = gameState.playerY || window.innerHeight / 2;
    
    const rect = tileEl.getBoundingClientRect();
    const centerX = rect.left + rect.width / 2;
    const centerY = rect.top + rect.height / 2;
    const dist = Math.hypot(centerX - playerX, centerY - playerY);
    
    if (dist > 120) {
        showMessage('太远了，靠近后长按以挖掘。');
        return;
    }
    
    let tool = null, durField = null;
    
    if (type === 'stoneBlock') {
        if (gameState.resources.hardStonePickaxe > 0 && gameState.hardStonePickaxeDurability > 0) {
            tool = 'hardStonePickaxe';
            durField = 'hardStonePickaxeDurability';
        } else if (gameState.resources.stonePickaxe > 0 && gameState.stonePickaxeDurability > 0) {
            tool = 'stonePickaxe';
            durField = 'stonePickaxeDurability';
        } else if (gameState.resources.pickaxe > 0 && gameState.pickaxeDurability > 0) {
            tool = 'pickaxe';
            durField = 'pickaxeDurability';
        } else {
            showMessage('需要镐来挖掘石块！');
            return;
        }
    } else {
        if (gameState.resources.hardStonePickaxe > 0 && gameState.hardStonePickaxeDurability > 0) {
            tool = 'hardStonePickaxe';
            durField = 'hardStonePickaxeDurability';
        } else if (gameState.resources.stonePickaxe > 0 && gameState.stonePickaxeDurability > 0) {
            tool = 'stonePickaxe';
            durField = 'stonePickaxeDurability';
        } else {
            showMessage('需要石镐来挖掘地底矿石！');
            return;
        }
    }
    
    const base = (type === 'stoneBlock') ? 5000 : 10000;
    const speedFactor = (tool === 'hardStonePickaxe') ? 10 : ((tool === 'stonePickaxe') ? 2.5 : 1);
    const time = Math.max(200, base / speedFactor);
    
    if (breakingElements.has(tileEl)) return;
    
    for (const [el] of breakingElements) {
        if (el !== tileEl) {
            resetBreakingProgress(el);
        }
    }
    
    let progress = 0;
    const progressDiv = document.createElement('div');
    progressDiv.className = 'progress-fill';
    progressDiv.style.position = 'absolute';
    progressDiv.style.left = '0';
    progressDiv.style.bottom = '0';
    progressDiv.style.height = '6px';
    progressDiv.style.background = (type === 'fuelOre') ? '#00FF00' : '#FF8C00';
    progressDiv.style.width = '0%';
    progressDiv.style.borderRadius = '3px';
    tileEl.appendChild(progressDiv);
    
    breakingElements.set(tileEl, {
        interval: setInterval(() => {
            progress += 100;
            progressDiv.style.width = Math.min(100, (progress / time) * 100) + '%';
            
            if (progress >= time) {
                clearInterval(breakingElements.get(tileEl).interval);
                breakingElements.delete(tileEl);
                tileEl.remove();
                
                if (type === 'stoneBlock') updateResource('stoneBlock', 1);
                else if (type === 'hardStoneOre') updateResource('hardStoneOre', 1);
                else if (type === 'fuelOre') updateResource('fuelOre', 1);
                
                if (durField) {
                    updateDurability(durField, (tool === 'hardStonePickaxe') ? 100 : 30);
                }
                
                updateInventoryPanel();
            }
        }, 100)
    });
}

function smeltHardStone() {
    if (!checkNear('.furnace')) {
        showMessage('需要靠近熔炉才能烧制硬石块！');
        return;
    }
    if ((gameState.resources.hardStoneOre || 0) < 1) {
        showMessage('没有硬石矿可烧制！');
        return;
    }
    if (gameState.furnaceFuel < 200) {
        showMessage('燃料不足，至少需要200燃料！');
        return;
    }
    
    gameState.resources.hardStoneOre--;
    gameState.resources.hardStoneBlock = (gameState.resources.hardStoneBlock || 0) + 1;
    gameState.furnaceFuel -= 200;
    
    updateFurnaceFuelUI();
    updateInventoryPanel();
    showMessage('烧制成功，获得1个硬石块！');
}

function smeltCookedMeat() {
    if (!checkNear('.furnace')) {
        showMessage('需要靠近熔炉才能熔炼！');
        return;
    }
    if (gameState.resources.rawMeat < 1) {
        showMessage("没有生肉可熔炼！");
        return;
    }
    if (gameState.furnaceFuel < 100) {
        showMessage("燃料不足！需要至少100燃料");
        return;
    }
    
    updateResource('rawMeat', -1);
    gameState.furnaceFuel -= 100;
    updateResource('cookedMeat', 1);
    
    updateInventoryPanel();
    updateFurnaceFuelUI();
    showMessage("熔炼成功，获得1个熟肉！");
    updateCraftingButtons();
}

function updateFurnaceFuelUI() {
    const el = document.getElementById('furnace-fuel-value');
    if (el) el.textContent = String(gameState.furnaceFuel || 0);
}

function showFuelPopup() {
    closeAllPopups();
    
    const popup = document.getElementById('fuel-popup');
    const options = document.getElementById('fuel-options');
    
    if (!popup || !options) {
        console.warn('showFuelPopup: required DOM elements missing');
        return;
    }
    
    options.innerHTML = '';
    
    const fuels = [
        { key: 'fuelOre', name: '燃矿', value: 1000, color: '#ff8800' },
        { key: 'branch', name: '木棍', value: 20, color: '#A0522D' },
        { key: 'twig', name: '树枝', value: 60, color: '#8B5A2B' },
        { key: 'wood', name: '木材', value: 200, color: '#A0522D' }
    ];
    
    let hasFuel = false;
    
    fuels.forEach(fuel => {
        if ((gameState.resources[fuel.key] || 0) > 0) {
            hasFuel = true;
            const btn = document.createElement('button');
            btn.className = 'btn';
            btn.style.margin = '5px';
            btn.innerHTML = `<span style="background:${fuel.color};color:#fff;padding:4px 10px;border-radius:8px;">${fuel.name}</span> ×1 → <span style="color:#FF8C00;">+${fuel.value}燃料</span>`;
            
            btn.onclick = () => {
                updateResource(fuel.key, -1);
                gameState.furnaceFuel += fuel.value;
                updateFurnaceFuelUI();
                updateInventoryPanel();
                showMessage(`${fuel.name} 已添加，获得 +${fuel.value} 燃料`);
                showFuelPopup();
                updateCraftingButtons();
            };
            
            options.appendChild(btn);
        }
    });
    
    if ((gameState.resources.fuelOre || 0) > 0) {
        const bulk = document.createElement('button');
        bulk.className = 'btn';
        bulk.style.margin = '5px';
        bulk.textContent = '全部转换燃矿';
        
        bulk.onclick = () => {
            const cnt = gameState.resources.fuelOre;
            if (cnt <= 0) return;
            updateResource('fuelOre', -cnt);
            gameState.furnaceFuel += cnt * 1000;
            updateFurnaceFuelUI();
            updateInventoryPanel();
            showMessage(`已转换 ${cnt} 个燃矿，获得 +${cnt * 1000} 燃料`);
            showFuelPopup();
            updateCraftingButtons();
        };
        
        options.appendChild(bulk);
    }
    
    if (!hasFuel) {
        options.innerHTML = '<div style="color:#fff;text-align:center;">没有可用燃料物品</div>';
    }
    
    popup.style.display = 'block';
}

function checkNearCraftingTable() {
    gameState.nearCraftingTable = checkNear('.crafting-table');
    return gameState.nearCraftingTable;
}

function checkRefreshButtonPosition() {
    if (gameState.controlMode !== 'button') {
        document.getElementById('refresh-button').style.display = 'none';
        return;
    }
    
    const playerX = gameState.playerX || window.innerWidth / 2;
    const playerY = gameState.playerY || window.innerHeight / 2;
    
    const nearLeft = playerX < 100;
    const nearBottom = (window.innerHeight - playerY) < 100;
    
    document.getElementById('refresh-button').style.display = (nearLeft && nearBottom) ? 'flex' : 'none';
}

function updateActionButtonHighlight() {
    const actionButtons = ['dig-hole', 'place-ladder', 'enter-underground', 'exit-underground', 'open-chest-btn', 'reclaim-table-btn', 'reclaim-furnace-btn'];
    const visibleButtons = actionButtons.filter(id => {
        const btn = document.getElementById(id);
        return btn && btn.style.display !== 'none';
    });
    
    actionButtons.forEach(id => {
        const btn = document.getElementById(id);
        if (btn) {
            btn.style.outline = '';
            btn.style.transform = '';
        }
    });
    
    if (visibleButtons.length > 0) {
        let highlightedId = gameState.highlightedActionBtn;
        
        if (!highlightedId || !visibleButtons.includes(highlightedId)) {
            highlightedId = visibleButtons[0];
            gameState.highlightedActionBtn = highlightedId;
        }
        
        const btn = document.getElementById(highlightedId);
        if (btn) {
            btn.style.outline = '3px solid #FFD700';
            btn.style.outlineOffset = '3px';
            btn.style.transform = 'scale(1.1)';
            btn.style.transition = 'transform 0.1s, outline 0.1s';
        }
    }
}

function updateHoleButtons() {
    const digBtn = document.getElementById('dig-hole');
    const placeBtn = document.getElementById('place-ladder');
    const enterBtn = document.getElementById('enter-underground');
    const exitBtn = document.getElementById('exit-underground');
    
    const hasPickaxe = gameState.resources.hardStonePickaxe > 0 && gameState.hardStonePickaxeDurability >= 1 ||
                       gameState.resources.stonePickaxe > 0 && gameState.stonePickaxeDurability >= 1 ||
                       gameState.resources.pickaxe > 0 && gameState.pickaxeDurability >= 2;
    
    if (gameState.controlMode === 'button' && hasPickaxe && !gameState.undergroundOpen) {
        digBtn.style.display = 'block';
    } else {
        digBtn.style.display = 'none';
    }
    
    let nearHole = null;
    const playerX = gameState.playerX || window.innerWidth / 2;
    const playerY = gameState.playerY || window.innerHeight / 2;
    
    for (const h of gameState.holes) {
        const d = Math.hypot(h.x - playerX, h.y - playerY);
        if (d < 80) {
            nearHole = h;
            break;
        }
    }
    
    if (nearHole && !nearHole.hasLadder && gameState.resources.ladder > 0 && !gameState.undergroundOpen) {
        placeBtn.style.display = 'block';
    } else {
        placeBtn.style.display = 'none';
    }
    
    let nearLadder = null;
    for (const h of gameState.holes) {
        if (h.hasLadder) {
            const d = Math.hypot(h.x - playerX, h.y - playerY);
            if (d < 80) {
                nearLadder = h;
                break;
            }
        }
    }
    
    if (nearLadder && !gameState.undergroundOpen && gameState.controlMode === 'button') {
        enterBtn.style.display = 'block';
    } else {
        enterBtn.style.display = 'none';
    }
    
    if (gameState.undergroundOpen && gameState.controlMode === 'button') {
        const exitAreaX = window.innerWidth - 120;
        const exitAreaY = 100;
        const distToExit = Math.hypot(playerX - exitAreaX, playerY - exitAreaY);
        if (distToExit < 100) {
            exitBtn.style.display = 'block';
        } else {
            exitBtn.style.display = 'none';
        }
    } else {
        exitBtn.style.display = 'none';
    }
    
    const chestBtn = document.getElementById('open-chest-btn');
    if (gameState.undergroundOpen && gameState.currentHole && gameState.currentHole.underground) {
        const chests = gameState.currentHole.underground.container.querySelectorAll('.ug-tile[data-type="chest"][data-opened="false"]');
        let nearChest = null;
        let minDist = 120;
        chests.forEach(chest => {
            const rect = chest.getBoundingClientRect();
            const centerX = rect.left + rect.width / 2;
            const centerY = rect.top + rect.height / 2;
            const dist = Math.hypot(centerX - playerX, centerY - playerY);
            if (dist < minDist) {
                minDist = dist;
                nearChest = chest;
            }
        });
        if (nearChest) {
            chestBtn.style.display = 'block';
            chestBtn.onclick = () => startMiningUnderground(nearChest);
        } else {
            chestBtn.style.display = 'none';
        }
    } else {
        if (chestBtn) chestBtn.style.display = 'none';
    }
    
    updateActionButtonHighlight();
}

function refreshMap() {
    if (gameState.refreshCooldown) return;
    gameState.refreshCooldown = true;
    setTimeout(() => { gameState.refreshCooldown = false; }, 1000);
    
    gameState.collisionEnabled = false;
    
    if (gameState.currentMap === 'surface') {
        gameState.refreshCounts.surface++;
        
        const container = document.getElementById('game-container');
        if (container) {
            container.querySelectorAll('.game-element').forEach(el => {
                if (el.id !== 'phaser-player') el.remove();
            });
        }
        
        generateRandomSurfaceElements();
        
        gameState.playerX = window.innerWidth - 70;
        gameState.playerY = 50;
    } else if (gameState.currentMap === 'underground' && gameState.currentHole) {
        gameState.refreshCounts.underground = (gameState.refreshCounts.underground || 0) + 1;
        
        const undergroundData = gameState.currentHole.underground;
        const player = document.getElementById('phaser-player');
        if (undergroundData) {
            if (player) player.remove();
            
            undergroundData.container.innerHTML = '';
            undergroundData.tiles = [];
            
            const tile = undergroundData.tile;
            const cols = undergroundData.cols;
            const rows = undergroundData.rows;
            
            const chestRow = Math.floor(Math.random() * (rows - 2)) + 1;
            const chestCol = Math.floor(Math.random() * (cols - 2)) + 1;
            
            for (let r = 0; r < rows; r++) {
                for (let c = 0; c < cols; c++) {
                    const cx = c * tile;
                    const cy = r * tile;
                    
                    const tileEl = document.createElement('div');
                    tileEl.className = 'ug-tile';
                    tileEl.style.position = 'absolute';
                    tileEl.style.left = cx + 'px';
                    tileEl.style.top = cy + 'px';
                    tileEl.style.width = tile + 'px';
                    tileEl.style.height = tile + 'px';
                    tileEl.style.boxSizing = 'border-box';
                    
                    const exitCol = cols - 1;
                    const exitRow = 0;
                    
                    if (r === exitRow && c === exitCol) {
                        tileEl.style.background = 'transparent';
                        tileEl.dataset.type = 'empty';
                        tileEl.dataset.exit = 'true';
                    } else if (r === exitRow && c === exitCol - 1) {
                        tileEl.style.background = 'transparent';
                        tileEl.dataset.type = 'empty';
                    } else if (r === exitRow + 1 && c === exitCol) {
                        tileEl.style.background = 'transparent';
                        tileEl.dataset.type = 'empty';
                    } else if (r === chestRow && c === chestCol) {
                        tileEl.dataset.type = 'chest';
                        tileEl.style.background = 'linear-gradient(135deg, #8B4513 0%, #654321 50%, #4a2c0a 100%)';
                        tileEl.style.border = '3px solid #FFD700';
                        tileEl.style.borderRadius = '8px';
                        tileEl.style.display = 'flex';
                        tileEl.style.alignItems = 'center';
                        tileEl.style.justifyContent = 'center';
                        tileEl.style.fontSize = '2rem';
                        tileEl.style.zIndex = 10;
                        tileEl.textContent = '📦';
                        tileEl.dataset.opened = 'false';
                    } else {
                        const rand = Math.random();
                        if (rand < 0.05) {
                            tileEl.dataset.type = 'fuelOre';
                            tileEl.style.background = '#ff8f2b';
                        } else if (rand < 0.15) {
                            tileEl.dataset.type = 'hardStoneOre';
                            tileEl.style.background = '#6b6b6b';
                        } else {
                            tileEl.dataset.type = 'stoneBlock';
                            tileEl.style.background = '#9E9E9E';
                        }
                        tileEl.style.border = '1px solid rgba(0,0,0,0.15)';
                    }
                    
                    if (tileEl.dataset.type !== 'chest' && tileEl.dataset.type !== 'empty') {
                        attachLongPress(tileEl, () => {
                            startMiningUnderground(tileEl);
                        });
                    }
                    
                    undergroundData.container.appendChild(tileEl);
                    undergroundData.tiles.push(tileEl);
                }
            }
        }
        
        gameState.playerX = (gameState.currentHole.underground.cols - 0.5) * gameState.currentHole.underground.tile;
        gameState.playerY = gameState.currentHole.underground.tile / 2;
        
        if (player) {
            player.style.visibility = 'visible';
            player.style.display = 'block';
            player.style.opacity = '1';
            undergroundData.container.appendChild(player);
        }
    }
    
    updatePlayerPosition();
    
    setTimeout(() => {
        gameState.collisionEnabled = true;
    }, 100);
}

function generateRandomSurfaceElements() {
    for (let i = 0; i < 3; i++) createTree();
    for (let i = 0; i < 5; i++) createElement('stone');
    for (let i = 0; i < 3; i++) createElement('tree-leaf');
    for (let i = 0; i < 2; i++) createAnimal();
}

function createTree() {
    const attempts = 100;
    const maxCol = Math.floor(window.innerWidth / GRID_SIZE) - 1;
    const maxRow = Math.floor(window.innerHeight / GRID_SIZE) - 3;
    
    for (let i = 0; i < attempts; i++) {
        const col = Math.floor(Math.random() * (maxCol + 1));
        const row = Math.floor(Math.random() * (maxRow + 1));
        
        if (!isGridCellOccupied(col, row, GRID_SIZE, GRID_SIZE * 3)) {
            occupyGridCells(col, row, GRID_SIZE, GRID_SIZE * 3);
            
            const x = col * GRID_SIZE;
            const y = row * GRID_SIZE;
            
            createElement('tree-leaf', x, y, GRID_SIZE, GRID_SIZE);
            createElement('tree-trunk', x + 15, y + GRID_SIZE, 20, GRID_SIZE * 2);
            return;
        }
    }
}

function createAnimal() {
    const attempts = 100;
    const maxCol = Math.floor(window.innerWidth / GRID_SIZE) - 1;
    const maxRow = Math.floor(window.innerHeight / GRID_SIZE) - 1;
    
    for (let i = 0; i < attempts; i++) {
        const col = Math.floor(Math.random() * (maxCol + 1));
        const row = Math.floor(Math.random() * (maxRow + 1));
        
        if (!isGridCellOccupied(col, row, GRID_SIZE, GRID_SIZE)) {
            occupyGridCells(col, row, GRID_SIZE, GRID_SIZE);
            
            const x = col * GRID_SIZE;
            const y = row * GRID_SIZE;
            
            const el = document.createElement('div');
            el.className = 'animal game-element';
            el.style.left = x + 'px';
            el.style.top = y + 'px';
            el.textContent = '4';
            
            const container = document.getElementById('game-container');
            if (container) container.appendChild(el);

            const animalObj = { el, x, y, hp: 4 };
            gameState.animals.push(animalObj);

            el.addEventListener('click', () => {
                const playerX = gameState.playerX || window.innerWidth / 2;
                const playerY = gameState.playerY || window.innerHeight / 2;
                
                const rect = el.getBoundingClientRect();
                const centerX = rect.left + rect.width / 2;
                const centerY = rect.top + rect.height / 2;
                const dist = Math.hypot(centerX - playerX, centerY - playerY);
                
                if (dist > 80) return;
                
                animalObj.hp -= gameState.attack;
                
                if (animalObj.hp <= 0) {
                    const col = Math.floor(animalObj.x / GRID_SIZE);
                    const row = Math.floor(animalObj.y / GRID_SIZE);
                    freeGridCells(col, row, GRID_SIZE, GRID_SIZE);
                    
                    el.remove();
                    gameState.animals = gameState.animals.filter(a => a !== animalObj);
                    updateResource('rawMeat', 1);
                    updateInventoryPanel();
                } else {
                    el.textContent = animalObj.hp;
                }
                
                if (gameState.resources.hardStoneSword > 0) {
                    updateDurability('hardStoneSwordDurability', 150);
                    updateInventoryPanel();
                } else if (gameState.resources.woodenSword > 0) {
                    updateDurability('woodenSwordDurability', 30);
                    updateInventoryPanel();
                }
            });
            return;
        }
    }
}

function startAnimalMovement() {
    const COLLISION_SIZE = 20;
    const BOUNCE_DIST = 30;
    
    setInterval(() => {
        gameState.animals.forEach(animal => {
            let angle = Math.random() * 2 * Math.PI;
            let dist = 20 + Math.random() * 30;
            let newX = animal.x + Math.cos(angle) * dist;
            let newY = animal.y + Math.sin(angle) * dist;
            
            newX = Math.max(0, Math.min(window.innerWidth - 40, newX));
            newY = Math.max(0, Math.min(window.innerHeight - 40, newY));
            
            const playerX = gameState.playerX || window.innerWidth / 2;
            const playerY = gameState.playerY || window.innerHeight / 2;
            const distToPlayer = Math.hypot(newX - playerX, newY - playerY);
            if (distToPlayer < 50) {
                return;
            }
            
            if (isBlockedAt(newX + 10, newY + 10, COLLISION_SIZE, COLLISION_SIZE, animal.el)) {
                const bounceAngle = findBounceAngle(animal.x, animal.y, newX, newY);
                newX = animal.x + Math.cos(bounceAngle) * BOUNCE_DIST;
                newY = animal.y + Math.sin(bounceAngle) * BOUNCE_DIST;
                newX = Math.max(0, Math.min(window.innerWidth - 40, newX));
                newY = Math.max(0, Math.min(window.innerHeight - 40, newY));
                
                if (isBlockedAt(newX + 10, newY + 10, COLLISION_SIZE, COLLISION_SIZE, animal.el)) {
                    return;
                }
            }
            
            const duration = 400;
            const startX = animal.x;
            const startY = animal.y;
            const deltaX = newX - startX;
            const deltaY = newY - startY;
            let startTime = null;
            
            function animateAnimalMove(ts) {
                if (!startTime) startTime = ts;
                const progress = Math.min(1, (ts - startTime) / duration);
                const eased = 1 - Math.pow(1 - progress, 3);
                animal.x = startX + deltaX * eased;
                animal.y = startY + deltaY * eased;
                animal.el.style.left = animal.x + 'px';
                animal.el.style.top = animal.y + 'px';
                if (progress < 1) {
                    requestAnimationFrame(animateAnimalMove);
                } else {
                    animal.x = newX;
                    animal.y = newY;
                    animal.el.style.left = animal.x + 'px';
                    animal.el.style.top = animal.y + 'px';
                }
            }
            
            requestAnimationFrame(animateAnimalMove);
        });
    }, 1500);
}

function findBounceAngle(fromX, fromY, toX, toY) {
    const dx = toX - fromX;
    const dy = toY - fromY;
    const originalAngle = Math.atan2(dy, dx);
    
    const candidates = [
        originalAngle + Math.PI / 4,
        originalAngle - Math.PI / 4,
        originalAngle + Math.PI / 2,
        originalAngle - Math.PI / 2,
        originalAngle + 3 * Math.PI / 4,
        originalAngle - 3 * Math.PI / 4,
        originalAngle + Math.PI
    ];
    
    let bestAngle = originalAngle;
    let bestDistance = -1;
    
    const COLLISION_SIZE = 20;
    
    for (const angle of candidates) {
        const testX = fromX + Math.cos(angle) * 30;
        const testY = fromY + Math.sin(angle) * 30;
        
        if (testX >= 0 && testX <= window.innerWidth - 40 &&
            testY >= 0 && testY <= window.innerHeight - 40) {
            
            if (!isBlockedAt(testX + 10, testY + 10, COLLISION_SIZE, COLLISION_SIZE)) {
                const dist = Math.abs(Math.cos(angle));
                if (dist > bestDistance) {
                    bestDistance = dist;
                    bestAngle = angle;
                }
            }
        }
    }
    
    return bestAngle;
}

function showButtonControls() {
    if (gameState.controlMode === 'button') {
        const crafting = document.getElementById('crafting-ui');
        const isCraftingOpen = crafting && crafting.style.display === 'block';
        
        document.getElementById('touch-controls').style.display = isCraftingOpen ? 'none' : 'flex';
        document.getElementById('touch-joystick-area').style.display = isCraftingOpen ? 'none' : 'block';
        document.getElementById('inventory-btn').style.display = isCraftingOpen ? 'none' : 'flex';
        document.getElementById('touch-crafting').style.display = 'flex';
        
        checkRefreshButtonPosition();
    }
}

function updateReclaimTableBtn() {
    const reclaimBtn = document.getElementById('reclaim-table-btn');
    reclaimBtn.style.display = checkNear('.crafting-table') ? 'block' : 'none';
    updateActionButtonHighlight();
}

function updateReclaimFurnaceBtn() {
    const furnaceBtn = document.getElementById('reclaim-furnace-btn');
    furnaceBtn.style.display = checkNear('.furnace') ? 'block' : 'none';
    updateActionButtonHighlight();
}

function bindReclaimTableBtn() {
    const reclaimBtn = document.getElementById('reclaim-table-btn');
    reclaimBtn.onclick = () => {
        let found = false;
        document.querySelectorAll('.crafting-table').forEach(table => {
            const playerX = gameState.playerX || window.innerWidth / 2;
            const playerY = gameState.playerY || window.innerHeight / 2;
            
            const rect = table.getBoundingClientRect();
            const centerX = rect.left + rect.width / 2;
            const centerY = rect.top + rect.height / 2;
            const d = Math.hypot(centerX - playerX, centerY - playerY);
            
            if (d < 100 && !found) {
                table.remove();
                updateResource('craftingTable', 1);
                updateInventoryPanel();
                found = true;
            }
        });
    };
}

function bindReclaimFurnaceBtn() {
    const furnaceBtn = document.getElementById('reclaim-furnace-btn');
    furnaceBtn.onclick = () => {
        let found = false;
        document.querySelectorAll('.furnace').forEach(furnace => {
            const playerX = gameState.playerX || window.innerWidth / 2;
            const playerY = gameState.playerY || window.innerHeight / 2;
            
            const rect = furnace.getBoundingClientRect();
            const centerX = rect.left + rect.width / 2;
            const centerY = rect.top + rect.height / 2;
            const d = Math.hypot(centerX - playerX, centerY - playerY);
            
            if (d < 100 && !found) {
                furnace.remove();
                updateResource('furnace', 1);
                updateInventoryPanel();
                found = true;
            }
        });
    };
}

function setupFurnacePlaceAndReclaim() {
    let furnaceBtn = document.getElementById('reclaim-furnace-btn');
    
    if (!furnaceBtn) {
        furnaceBtn = document.createElement('button');
        furnaceBtn.id = 'reclaim-furnace-btn';
        furnaceBtn.className = 'btn';
        furnaceBtn.style.position = 'fixed';
        furnaceBtn.style.bottom = '160px';
        furnaceBtn.style.right = '20px';
        furnaceBtn.style.zIndex = '101';
        furnaceBtn.style.display = 'none';
        furnaceBtn.textContent = '收回熔炉';
        document.body.appendChild(furnaceBtn);
    }
    
    furnaceBtn.onclick = () => {
        let found = false;
        document.querySelectorAll('.furnace').forEach(furnace => {
            const playerX = gameState.playerX || window.innerWidth / 2;
            const playerY = gameState.playerY || window.innerHeight / 2;
            
            const rect = furnace.getBoundingClientRect();
            const centerX = rect.left + rect.width / 2;
            const centerY = rect.top + rect.height / 2;
            const d = Math.hypot(centerX - playerX, centerY - playerY);
            
            if (d < 100 && !found) {
                furnace.remove();
                updateResource('furnace', 1);
                updateInventoryPanel();
                found = true;
            }
        });
        
        if (!found) showMessage("请靠近熔炉再点击收回！");
    };
}

function initGame() {
    generateRandomSurfaceElements();
    setupEventListeners();
    setupJoystick();
    updateInventoryPanel();
    updateHealthBar();
    
    const reclaimBtn = document.getElementById('reclaim-table-btn');
    if (reclaimBtn) {
        reclaimBtn.className = 'btn';
        reclaimBtn.style.display = 'none';
    }
    
    bindReclaimTableBtn();
    bindReclaimFurnaceBtn();
    setupFurnacePlaceAndReclaim();
    
    const craftFurnaceBtn = document.getElementById('craft-furnace');
    if (craftFurnaceBtn) {
        craftFurnaceBtn.addEventListener('click', () => {
            if (gameState.resources.stone >= 10 && checkNearCraftingTable()) {
                updateResource('stone', -10);
                updateResource('furnace', 1);
                updateInventoryPanel();
                showMessage("制作了一个熔炉！");
                updateCraftingButtons();
            } else if (gameState.resources.stone < 10) {
                showMessage("材料不足！需要10个石子");
            } else {
                showMessage("需要靠近合成台才能制作熔炉！");
            }
        });
    }
    
    const addFuelBtn = document.getElementById('add-fuel-btn');
    if (addFuelBtn) {
        addFuelBtn.onclick = () => {
            if (!checkNear('.furnace')) {
                showMessage("需要靠近熔炉才能添加燃料！");
                return;
            }
            showFuelPopup();
        };
    }
    
    const closeFuelBtn = document.getElementById('close-fuel-popup');
    if (closeFuelBtn) {
        closeFuelBtn.onclick = () => {
            const fp = document.getElementById('fuel-popup');
            if (fp) fp.style.display = 'none';
            
            const crafting = document.getElementById('crafting-ui');
            if (crafting && crafting.style.display === 'block') {
                renderCraftingUI();
            }
            updateCraftingButtons();
        };
    }
}

function setupEventListeners() {
    bindBtn('craft-wooden-sword', craftWoodenSword);
    bindBtn('craft-axe', craftAxe);
    bindBtn('craft-table', craftTable);
    bindBtn('craft-pickaxe', craftPickaxe);
    bindBtn('craft-vine', craftVine);
    bindBtn('craft-branch', craftBranch);
    bindBtn('craft-ladder', craftLadder);
    bindBtn('craft-stone-pickaxe', craftStonePickaxe);
    bindBtn('smelt-hardstone', smeltHardStone);
    bindBtn('dig-hole', digHole);
    bindBtn('place-ladder', placeLadder);
    bindBtn('enter-underground', enterUnderground);
    bindBtn('exit-underground', exitUnderground);
    bindBtn('prev-page', () => { craftingPagination.prevPage(); renderCraftingUI(); });
    bindBtn('next-page', () => { craftingPagination.nextPage(); renderCraftingUI(); });
    bindBtn('refresh-button', () => { if (gameState.controlMode === 'button') refreshMap(); });
    bindBtn('inventory-btn', toggleInventory);
    bindBtn('touch-crafting', () => {
        if (gameState.controlMode === 'button') {
            gameState.craftingPage = 1;
            renderCraftingUI();
            const crafting = document.getElementById('crafting-ui');
            if (crafting) togglePopup(crafting);
        }
    });
    bindBtn('close-message', () => {
        document.getElementById('message-popup').style.display = 'none';
        const crafting = document.getElementById('crafting-ui');
        if (crafting && crafting.style.display === 'block') renderCraftingUI();
        if (gameState.controlMode === 'button') showButtonControls();
    });
    bindBtn('smelt-cooked-meat', smeltCookedMeat);
    bindBtn('map-btn', openMapUI);
    bindBtn('close-map-btn', closeMapUI);
    
    document.querySelectorAll('.map-item').forEach(item => {
        item.addEventListener('click', () => {
            if (!item.classList.contains('disabled')) {
                switchMap(item.dataset.map);
            }
        });
    });
    
    const startGame = (mode) => {
        document.getElementById('start-screen').style.display = 'none';
        document.getElementById('player-health-bar').style.display = 'block';
        gameState.controlMode = mode;
        
        const cheatModeCheckbox = document.getElementById('cheat-mode');
        gameState.cheatModeEnabled = cheatModeCheckbox ? cheatModeCheckbox.checked : false;
        
        if (mode === 'button') {
            document.getElementById('touch-controls').style.display = 'flex';
            document.getElementById('inventory-btn').style.display = 'block';
            document.getElementById('touch-crafting').style.display = 'flex';
            document.getElementById('refresh-button').style.display = 'flex';
        } else {
            document.getElementById('touch-controls').style.display = 'none';
            document.getElementById('touch-joystick-area').style.display = 'none';
            document.getElementById('inventory-btn').style.display = 'none';
            document.getElementById('touch-crafting').style.display = 'none';
            document.getElementById('refresh-button').style.display = 'none';
        }
        
        document.getElementById('command-btn').style.display = (mode === 'button' && gameState.cheatModeEnabled) ? 'flex' : 'none';
        document.getElementById('map-btn').style.display = (mode === 'button') ? 'flex' : 'none';
        
        gameState.isRunning = true;
        
        if (mode === 'button') setupJoystick();
        
        const startX = window.innerWidth / 2;
        const startY = window.innerHeight / 2;
        gameState.playerX = startX;
        gameState.playerY = startY;
        
        if (phaserPlayer) {
            phaserPlayer.setPosition(startX, startY);
        }
        
        const playerDiv = document.getElementById('phaser-player');
        if (playerDiv) {
            playerDiv.style.left = (startX - 25) + 'px';
            playerDiv.style.top = (startY - 25) + 'px';
        }
        
        startAnimalMovement();
        gameLoop();
    };
    
    bindBtn('keyboard-control', () => startGame('keyboard'));
    bindBtn('button-control', () => startGame('button'));
    bindBtn('download-guide', downloadGameGuide);
    bindBtn('command-btn', () => {
        ensureCommandInput();
        const cmdContainer = document.getElementById('command-container');
        const cmdInput = document.getElementById('command-input');
        cmdContainer.style.display = 'block';
        cmdInput.focus();
        cmdInput.value = '/';
    });
    
    document.addEventListener('keydown', (e) => {
        if (gameState.controlMode !== 'keyboard') return;
        
        const commandOpen = document.getElementById('command-container')?.style.display === 'block';
        const craftingOpen = document.getElementById('crafting-ui').style.display === 'block';
        const inventoryOpen = document.getElementById('inventory-panel').style.display === 'flex';
        const messageOpen = document.getElementById('message-popup').style.display === 'block';
        const mapOpen = document.getElementById('map-ui').style.display === 'block';
        
        if (messageOpen) {
            if (e.key === 'Enter') {
                const closeBtn = document.getElementById('close-message');
                if (closeBtn) closeBtn.click();
            }
            e.preventDefault();
            return;
        }
        
        if (commandOpen) {
            return;
        }
        
        if (craftingOpen) {
            if (e.key.toLowerCase() === 'c') {
                document.getElementById('crafting-ui').style.display = 'none';
            }
            e.preventDefault();
            return;
        }
        
        if (inventoryOpen) {
            if (e.key.toLowerCase() === 'e') {
                document.getElementById('inventory-panel').style.display = 'none';
            }
            e.preventDefault();
            return;
        }
        
        if (mapOpen) {
            if (e.key === 'Escape' || e.key.toLowerCase() === 'm') {
                closeMapUI();
            }
            e.preventDefault();
            return;
        }
        
        if (e.key.toLowerCase() === 'f') {
            if (gameState.currentMap === 'underground') {
                const playerX = gameState.playerX || window.innerWidth / 2;
                const playerY = gameState.playerY || window.innerHeight / 2;
                
                const chests = document.querySelectorAll('.ug-tile[data-type="chest"][data-opened="false"]');
                let nearestChest = null;
                let minDist = 120;
                
                chests.forEach(chest => {
                    const rect = chest.getBoundingClientRect();
                    const centerX = rect.left + rect.width / 2;
                    const centerY = rect.top + rect.height / 2;
                    const dist = Math.hypot(centerX - playerX, centerY - playerY);
                    
                    if (dist < minDist) {
                        minDist = dist;
                        nearestChest = chest;
                    }
                });
                
                if (nearestChest) {
                    startMiningUnderground(nearestChest);
                    return;
                }
            }
            
            const actionButtons = ['dig-hole', 'place-ladder', 'enter-underground', 'exit-underground', 'open-chest-btn', 'reclaim-table-btn', 'reclaim-furnace-btn'];
            const visibleButtons = actionButtons.filter(id => {
                const btn = document.getElementById(id);
                return btn && btn.style.display !== 'none';
            });
            
            if (visibleButtons.length > 0) {
                const highlightedId = gameState.highlightedActionBtn || visibleButtons[0];
                const btn = document.getElementById(highlightedId);
                if (btn) {
                    btn.click();
                }
            }
            return;
        }
        
        const key = e.key.toLowerCase();
        
        if (key === 't') {
            if (gameState.cheatModeEnabled) {
                ensureCommandInput();
                const cmdContainer = document.getElementById('command-container');
                const cmdInput = document.getElementById('command-input');
                if (cmdContainer && cmdInput && cmdContainer.style.display !== 'block') {
                    e.preventDefault();
                    cmdContainer.style.display = 'block';
                    cmdInput.focus();
                    cmdInput.value = '/';
                }
            }
            return;
        }
        
        if (key === 'c') {
            gameState.craftingPage = 1;
            renderCraftingUI();
            const crafting = document.getElementById('crafting-ui');
            if (crafting) togglePopup(crafting);
            e.preventDefault();
            return;
        }
        
        if (key === 'e') {
            toggleInventory();
            e.preventDefault();
            return;
        }
        
        if (key === 'o') {
            digHole();
            e.preventDefault();
            return;
        }
        
        if (key === 'm') {
            openMapUI();
            e.preventDefault();
            return;
        }
        
        if (key === 'r') {
            const playerX = gameState.playerX || window.innerWidth / 2;
            const playerY = gameState.playerY || window.innerHeight / 2;
            if (playerX < 100 && (window.innerHeight - playerY) < 100) {
                refreshMap();
            }
            return;
        }
        
        if (['w', 'a', 's', 'd'].includes(key)) {
            gameState.keysPressed.add(key);
            
            if (gameState.keyboardInterval) clearInterval(gameState.keyboardInterval);
            
            const stepFn = () => {
                let dx = 0, dy = 0;
                if (gameState.keysPressed.has('w')) dy -= 1;
                if (gameState.keysPressed.has('s')) dy += 1;
                if (gameState.keysPressed.has('a')) dx -= 1;
                if (gameState.keysPressed.has('d')) dx += 1;
                if (dx === 0 && dy === 0) return;
                movePlayerByVector(dx, dy);
            };
            
            stepFn();
            gameState.keyboardInterval = setInterval(stepFn, 50);
        }
    });
    
    document.addEventListener('keyup', (e) => {
        const key = e.key.toLowerCase();
        if (gameState.controlMode === 'keyboard' && ['w', 'a', 's', 'd'].includes(key)) {
            gameState.keysPressed.delete(key);
            
            if (gameState.keyboardInterval) clearInterval(gameState.keyboardInterval);
            
            if (gameState.keysPressed.size > 0) {
                const stepFn = () => {
                    let dx = 0, dy = 0;
                    if (gameState.keysPressed.has('w')) dy -= 1;
                    if (gameState.keysPressed.has('s')) dy += 1;
                    if (gameState.keysPressed.has('a')) dx -= 1;
                    if (gameState.keysPressed.has('d')) dx += 1;
                    if (dx === 0 && dy === 0) return;
                    movePlayerByVector(dx, dy);
                };
                stepFn();
                gameState.keyboardInterval = setInterval(stepFn, 50);
            } else {
                gameState.keyboardInterval = null;
            }
        }
    });
    
    document.addEventListener('wheel', (e) => {
        if (gameState.controlMode !== 'keyboard') return;
        
        const commandOpen = document.getElementById('command-container')?.style.display === 'block';
        const craftingOpen = document.getElementById('crafting-ui').style.display === 'block';
        const inventoryOpen = document.getElementById('inventory-panel').style.display === 'flex';
        
        if (commandOpen || craftingOpen || inventoryOpen) return;
        
        const actionButtons = ['dig-hole', 'place-ladder', 'enter-underground', 'exit-underground', 'open-chest-btn', 'reclaim-table-btn', 'reclaim-furnace-btn'];
        const visibleButtons = actionButtons.filter(id => {
            const btn = document.getElementById(id);
            return btn && btn.style.display !== 'none';
        });
        
        if (visibleButtons.length > 0) {
            e.preventDefault();
            
            const currentHighlighted = gameState.highlightedActionBtn || visibleButtons[0];
            const currentIndex = visibleButtons.indexOf(currentHighlighted);
            
            let newIndex;
            if (e.deltaY > 0) {
                newIndex = (currentIndex + 1) % visibleButtons.length;
            } else {
                newIndex = (currentIndex - 1 + visibleButtons.length) % visibleButtons.length;
            }
            
            const prevBtn = document.getElementById(currentHighlighted);
            if (prevBtn) {
                prevBtn.style.outline = '';
                prevBtn.style.transform = '';
            }
            
            const newBtn = document.getElementById(visibleButtons[newIndex]);
            if (newBtn) {
                newBtn.style.outline = '3px solid #FFD700';
                newBtn.style.outlineOffset = '3px';
                newBtn.style.transform = 'scale(1.1)';
                newBtn.style.transition = 'transform 0.1s, outline 0.1s';
            }
            
            gameState.highlightedActionBtn = visibleButtons[newIndex];
        }
    });
    
    window.addEventListener('resize', () => {
        const maxX = window.innerWidth - 50;
        const maxY = window.innerHeight - 50;
        gameState.playerX = Math.min(maxX, gameState.playerX || maxX / 2);
        gameState.playerY = Math.min(maxY, gameState.playerY || maxY / 2);
        
        const player = document.getElementById('phaser-player');
        if (player) {
            player.style.left = gameState.playerX + 'px';
            player.style.top = gameState.playerY + 'px';
        }
    });
    
    document.addEventListener('click', (e) => {
        if (gameState.controlMode !== 'button') return;
        
        const crafting = document.getElementById('crafting-ui');
        const message = document.getElementById('message-popup');
        const fuel = document.getElementById('fuel-popup');
        
        const craftingOpen = crafting && crafting.style.display === 'block';
        const messageOpen = message && message.style.display === 'block';
        const fuelOpen = fuel && fuel.style.display === 'block';
        
        if (!craftingOpen && !messageOpen && !fuelOpen) return;
        
        const clickedInPopup = e.target.closest('.popup');
        const clickedTouchCraft = e.target.closest('#touch-crafting');
        
        if (!clickedInPopup && !clickedTouchCraft) {
            closeAllPopups();
        }
    });
}

function movePlayerByVector(dx, dy) {
    const size = 50;
    const step = 15;
    
    let stepX = dx * step;
    let stepY = dy * step;
    
    if (dx !== 0 && dy !== 0) {
        const inv = 1 / Math.SQRT2;
        stepX *= inv;
        stepY *= inv;
    }
    
    let newX = (gameState.playerX || window.innerWidth / 2) + Math.round(stepX);
    let newY = (gameState.playerY || window.innerHeight / 2) + Math.round(stepY);
    
    newX = Math.max(25, Math.min(window.innerWidth - 25, newX));
    newY = Math.max(25, Math.min(window.innerHeight - 25, newY));
    
    if (isBlockedAt(newX - 25, newY - 25, size, size)) return;
    
    gameState.playerX = newX;
    gameState.playerY = newY;
    
    if (phaserPlayer) {
        phaserPlayer.setPosition(newX, newY);
    }
    
    const playerDiv = document.getElementById('phaser-player');
    if (playerDiv) {
        playerDiv.style.left = (newX - 25) + 'px';
        playerDiv.style.top = (newY - 25) + 'px';
    }
    
    checkNearCraftingTable();
    checkBreakingDistance();
    updateReclaimTableBtn();
    updateReclaimFurnaceBtn();
    updateHoleButtons();
}

function checkBreakingDistance() {
    breakingElements.forEach((_, el) => {
        const playerX = gameState.playerX || window.innerWidth / 2;
        const playerY = gameState.playerY || window.innerHeight / 2;
        
        const rect = el.getBoundingClientRect();
        const centerX = rect.left + rect.width / 2;
        const centerY = rect.top + rect.height / 2;
        const dist = Math.hypot(centerX - playerX, centerY - playerY);
        
        if (dist > 80) resetBreakingProgress(el);
    });
}

function setupJoystick() {
    const area = document.getElementById('touch-joystick-area');
    const thumb = document.getElementById('touch-joystick-thumb');
    
    area.ontouchstart = area.ontouchmove = area.ontouchend = null;
    
    area.addEventListener('touchstart', (e) => {
        if (gameState.controlMode !== 'button') return;
        e.preventDefault();
        
        const t = e.touches[0];
        const rect = area.getBoundingClientRect();
        const cx = rect.left + rect.width / 2;
        const cy = rect.top + rect.height / 2;
        
        gameState.joystick = { active: true, startX: cx, startY: cy, currentX: t.clientX, currentY: t.clientY };
        updateJoystickPosition();
    }, { passive: false });
    
    area.addEventListener('touchmove', (e) => {
        if (!gameState.joystick?.active) return;
        e.preventDefault();
        
        const t = e.touches[0];
        gameState.joystick.currentX = t.clientX;
        gameState.joystick.currentY = t.clientY;
        
        updateJoystickPosition();
        updatePlayerMovement();
    }, { passive: false });
    
    area.addEventListener('touchend', (e) => {
        if (!gameState.joystick?.active) return;
        e.preventDefault();
        
        gameState.joystick.active = false;
        if (thumb) thumb.style.transform = 'translate(0, 0)';
        stopContinuousMove();
    }, { passive: false });
    
    area.addEventListener('mousedown', (e) => {
        if (gameState.controlMode !== 'button') return;
        
        const rect = area.getBoundingClientRect();
        const cx = rect.left + rect.width / 2;
        const cy = rect.top + rect.height / 2;
        
        gameState.joystick = { active: true, startX: cx, startY: cy, currentX: e.clientX, currentY: e.clientY };
        updateJoystickPosition();
    });
    
    document.addEventListener('mousemove', (e) => {
        if (!gameState.joystick?.active) return;
        
        gameState.joystick.currentX = e.clientX;
        gameState.joystick.currentY = e.clientY;
        
        updateJoystickPosition();
        updatePlayerMovement();
    });
    
    document.addEventListener('mouseup', () => {
        if (!gameState.joystick?.active) return;
        
        gameState.joystick.active = false;
        if (thumb) thumb.style.transform = 'translate(0, 0)';
        stopContinuousMove();
    });
}

function updateJoystickPosition() {
    const thumb = document.getElementById('touch-joystick-thumb');
    const joystick = document.getElementById('touch-joystick');
    
    if (!thumb || !joystick || !gameState.joystick) return;
    
    const rect = joystick.getBoundingClientRect();
    const cx = rect.left + rect.width / 2;
    const cy = rect.top + rect.height / 2;
    
    const dx = gameState.joystick.currentX - gameState.joystick.startX;
    const dy = gameState.joystick.currentY - gameState.joystick.startY;
    const dist = Math.sqrt(dx * dx + dy * dy);
    const maxDist = 35;
    
    if (dist > maxDist) {
        const angle = Math.atan2(dy, dx);
        thumb.style.transform = `translate(${Math.cos(angle) * maxDist}px, ${Math.sin(angle) * maxDist}px)`;
    } else {
        thumb.style.transform = `translate(${dx}px, ${dy}px)`;
    }
}

function updatePlayerMovement() {
    if (!gameState.joystick?.active) return;
    
    const dx = gameState.joystick.currentX - gameState.joystick.startX;
    const dy = gameState.joystick.currentY - gameState.joystick.startY;
    const dist = Math.sqrt(dx * dx + dy * dy);
    
    if (dist < 10) {
        stopContinuousMove();
        return;
    }
    
    const angle = Math.atan2(dy, dx);
    let dir = '';
    
    if (angle > -Math.PI/4 && angle < Math.PI/4) dir = 'right';
    else if (angle >= Math.PI/4 && angle < 3*Math.PI/4) dir = 'down';
    else if (angle >= -3*Math.PI/4 && angle <= -Math.PI/4) dir = 'up';
    else dir = 'left';
    
    startContinuousMove(dir);
}

function stopContinuousMove() {
    if (gameState.touchInterval) clearInterval(gameState.touchInterval);
    gameState.touchInterval = null;
    gameState.currentDirection = null;
}

function startContinuousMove(direction) {
    if (gameState.currentDirection === direction) return;
    
    stopContinuousMove();
    gameState.currentDirection = direction;
    
    movePlayer(direction);
    gameState.touchInterval = setInterval(() => movePlayer(direction), 50);
}

function movePlayer(direction) {
    const step = 15;
    const size = 50;
    
    let newX = gameState.playerX || window.innerWidth / 2;
    let newY = gameState.playerY || window.innerHeight / 2;
    
    if (direction === 'up') newY = Math.max(25, newY - step);
    if (direction === 'down') newY = Math.min(window.innerHeight - 25, newY + step);
    if (direction === 'left') newX = Math.max(25, newX - step);
    if (direction === 'right') newX = Math.min(window.innerWidth - 25, newX + step);
    
    if (isBlockedAt(newX - 25, newY - 25, size, size)) return;
    
    gameState.playerX = newX;
    gameState.playerY = newY;
    
    if (phaserPlayer) {
        phaserPlayer.setPosition(newX, newY);
    }
    
    const playerDiv = document.getElementById('phaser-player');
    if (playerDiv) {
        playerDiv.style.left = (newX - 25) + 'px';
        playerDiv.style.top = (newY - 25) + 'px';
    }
    
    checkNearCraftingTable();
    checkBreakingDistance();
    updateReclaimTableBtn();
    updateReclaimFurnaceBtn();
    updateHoleButtons();
}

function gameLoop() {
    if (!gameState.isRunning) return;
    
    checkRefreshButtonPosition();
    updateReclaimTableBtn();
    updateReclaimFurnaceBtn();
    updateHoleButtons();
    
    requestAnimationFrame(gameLoop);
}

function downloadGameGuide() {
    const guideText = `绿色森林 - 游戏操作指南
========================

【游戏简介】
绿色森林是一款休闲生存类游戏，玩家需要在森林中采集资源、制作工具、探索地下世界。

【操作方式】
玩家可以选择两种控制方式：
1. 键盘控制：使用方向键或WASD移动，使用按键进行交互
2. 按钮控制：使用屏幕上的虚拟按钮移动和交互

【基本操作】

一、移动
- 键盘：方向键 ↑↓←→ 或 WASD
- 按钮：屏幕底部的方向按钮

二、采集资源
- 靠近资源后长按进行采集
- 可用资源包括：树叶、石头、树干
- 部分资源需要特定工具才能采集
- 挖掘时切换目标会打断当前挖掘（进度清零）

三、制作系统
- 按 C 键打开制作界面（键盘控制）
- 或点击屏幕上的制作按钮（按钮控制）
- 制作需要消耗相应材料

四、战斗系统
- 靠近动物后点击攻击
- 动物有生命值，需要多次攻击才能击杀
- 击杀动物可获得生肉

五、地下探索
1. 挖洞：按 O 键挖洞（键盘控制）或点击挖洞按钮（按钮控制），消耗镐耐久
2. 放置梯子：在洞旁边放置梯子
3. 进入地下：按 F 键或点击进入矿洞按钮（仅按钮模式显示）
4. 返回地面：移动到地下世界右上角的出口区域，按 F 键或点击返回地面按钮
5. 地下刷新：在地下世界也可以刷新地图，刷新后传送至右上角出口
6. 宝箱：每个地下地图有一个宝箱，靠近后按 F 键或点击打开宝箱按钮打开，获得1金币

【资源说明】

基础资源：
- 树枝：采集树叶获得，用于制作工具
- 藤蔓：采集树叶获得，用于制作梯子
- 木头：砍树获得，用于制作工具和建筑
- 石头：采集石头获得，用于制作石制工具

高级资源：
- 生肉：击杀动物获得
- 熟肉：在熔炉中烧制生肉获得
- 燃矿：地下世界挖掘获得，用作熔炉燃料（橙色矿石，绿色进度条）
- 硬石矿：地下世界挖掘获得，用于制作高级工具（灰色矿石）

【工具说明】

镐类：
- 木镐：用于挖洞（消耗2耐久）
- 石镐：用于挖洞（消耗1耐久），挖掘石头更快
- 硬石镐：用于挖洞（消耗1耐久），挖掘速度最快

斧类：
- 木斧：用于砍树
- 硬石斧：砍树速度更快

武器：
- 木剑：攻击动物
- 硬石剑：攻击力更强

【熔炉系统】
- 需要先制作熔炉并放置
- 靠近熔炉可以添加燃料和物品
- 燃料包括：木头、燃矿

【作弊模式】
在开始界面勾选"启用作弊模式"复选框即可开启作弊功能。

开启后可以使用以下指令：
/give [物品名] [数量] - 给予指定数量的物品
/health [数量] - 恢复指定数量的生命值（最大20）
/fuel [数量] - 增加熔炉燃料
/clear - 清空背包所有物品
/tp x,y - 瞬移到地图指定位置（支持 x,y 或 x y 格式）
/unlockmap [地图名] - 解锁地图(surface/underground)
/map [地图名] - 直接切换地图(surface/underground)
/refreshtimes [地图名] - 查询地图刷新次数
/help - 显示所有可用指令

打开指令面板方式：
- 键盘控制：按 T 键
- 按钮控制：点击屏幕上的 💬 按钮

可用物品名称（用于 /give 指令）：
基础材料：wood（木头）、stone（石头）、branch（树枝）、vine（藤蔓）、fullVine（藤蔓）
工具：pickaxe（木镐）、stonePickaxe（石镐）、hardStonePickaxe（硬石镐）、axe（木斧）、hardStoneAxe（硬石斧）、woodenSword（木剑）、hardStoneSword（硬石剑）、ladder（梯子）
建筑：craftingTable（工作台）、furnace（熔炉）
食物：rawMeat（生肉）、cookedMeat（熟肉）
矿石：fuelOre（燃矿）、hardStoneOre（硬石矿）

示例：
/give wood 10 - 获得10个木头
/give pickaxe 1 - 获得1个木镐
/health 20 - 恢复满生命值
/tp 500,300 - 瞬移到坐标(500, 300)
/map underground - 切换到地下世界

【游戏技巧】
1. 优先制作工具，工具能提高采集效率
2. 合理管理工具耐久，及时补充
3. 探索地下世界获取稀有资源（燃矿、硬石矿、宝箱金币）
4. 注意保持生命值，及时食用食物
5. 利用刷新地图获取更多资源
6. 传送（切换地图、刷新）后会出现在右上角安全区域

【快捷键汇总】
W/↑ - 向上移动
S/↓ - 向下移动
A/← - 向左移动
D/→ - 向右移动
C - 打开制作界面
I - 打开背包
T - 打开指令（作弊模式）
O - 挖洞（键盘控制）
F - 交互键（打开宝箱、收回工作台/熔炉、进入/退出矿洞）
M - 打开地图（按钮控制专用）

【控制模式差异】
键盘模式：
- 所有交互通过按键完成
- 无屏幕按钮显示（除菜单按钮）
- 挖洞使用 O 键
- 交互使用 F 键

按钮模式：
- 所有交互通过屏幕按钮完成
- 显示方向按钮和各种操作按钮
- 挖洞、放置梯子、进入矿洞等都有对应按钮
- 橙色圆形地图按钮位于屏幕顶部

========================
祝游戏愉快！
`;
    
    const blob = new Blob([guideText], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = '绿色森林游戏指南.txt';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
    
    showMessage('游戏指南已下载！');
}

function ensureCommandInput() {
    let cmdContainer = document.getElementById('command-container');
    let cmdInput = document.getElementById('command-input');
    
    if (!cmdContainer) {
        cmdContainer = document.createElement('div');
        cmdContainer.id = 'command-container';
        cmdContainer.style.position = 'fixed';
        cmdContainer.style.top = '50%';
        cmdContainer.style.left = '50%';
        cmdContainer.style.transform = 'translate(-50%, -50%)';
        cmdContainer.style.zIndex = 1000;
        cmdContainer.style.display = 'none';
        cmdContainer.style.background = 'rgba(0, 0, 0, 0.8)';
        cmdContainer.style.padding = '20px';
        cmdContainer.style.borderRadius = '8px';
        document.body.appendChild(cmdContainer);
        
        cmdInput = document.createElement('input');
        cmdInput.id = 'command-input';
        cmdInput.type = 'text';
        cmdInput.style.width = '300px';
        cmdInput.style.padding = '10px';
        cmdInput.style.fontSize = '16px';
        cmdInput.style.background = '#333';
        cmdInput.style.color = '#fff';
        cmdInput.style.border = '1px solid #555';
        cmdInput.style.borderRadius = '4px';
        cmdContainer.appendChild(cmdInput);
        
        cmdInput.addEventListener('keydown', (e) => {
            if (e.key === 'Enter') {
                executeCommand(cmdInput.value);
                cmdContainer.style.display = 'none';
                cmdInput.value = '';
            } else if (e.key === 'Escape') {
                cmdContainer.style.display = 'none';
                cmdInput.value = '';
            }
        });
    }
}

function executeCommand(command) {
    if (!command.startsWith('/')) return;
    
    const parts = command.trim().split(' ');
    const cmd = parts[0].toLowerCase();
    
    if (cmd === '/give' && parts.length >= 2) {
        const itemName = parts[1];
        const amount = parts.length >= 3 ? parseInt(parts[2]) : 1;
        
        const resource = RESOURCES.find(r => 
            r.name === itemName || r.key === itemName.toLowerCase()
        );
        
        if (resource) {
            updateResource(resource.key, amount);
            
            if (resource.durability && resource.max) {
                const currentDurability = gameState[resource.durability] || 0;
                const neededDurability = amount * resource.max;
                if (currentDurability < neededDurability) {
                    gameState[resource.durability] = neededDurability;
                }
            }
            
            updateInventoryPanel();
            showMessage(`获得了 ${amount} 个 ${resource.name}！`);
        } else {
            showMessage(`未知物品: ${itemName}`);
        }
    } else if (cmd === '/health') {
        const amount = parts.length >= 2 ? parseInt(parts[1]) : 20;
        gameState.health = Math.min(20, gameState.health + amount);
        updateHealthBar();
        showMessage(`生命值恢复了 ${amount} 点！`);
    } else if (cmd === '/fuel') {
        const amount = parts.length >= 2 ? parseInt(parts[2]) : 10;
        gameState.furnaceFuel += amount;
        updateInventoryPanel();
        showMessage(`熔炉燃料增加了 ${amount}！`);
    } else if (cmd === '/clear') {
        Object.keys(gameState.resources).forEach(key => {
            gameState.resources[key] = 0;
        });
        updateInventoryPanel();
        showMessage('物品已清空！');
    } else if (cmd === '/tp') {
        if (parts.length < 2) {
            showMessage('用法: /tp x,y 或 /tp x y');
            return;
        }
        
        const posStr = parts[1];
        let x, y;
        
        if (posStr.includes(',')) {
            const coords = posStr.split(',');
            x = parseInt(coords[0].trim());
            y = parseInt(coords[1].trim());
        } else if (parts.length >= 3) {
            x = parseInt(posStr);
            y = parseInt(parts[2]);
        }
        
        if (isNaN(x) || isNaN(y)) {
            showMessage('无效坐标！用法: /tp x,y 或 /tp x y');
            return;
        }
        
        const maxX = window.innerWidth - 50;
        const maxY = window.innerHeight - 50;
        
        x = Math.max(0, Math.min(maxX, x));
        y = Math.max(0, Math.min(maxY, y));
        
        gameState.playerX = x;
        gameState.playerY = y;
        
        const playerDiv = document.getElementById('phaser-player');
        if (playerDiv) {
            playerDiv.style.left = (x - 25) + 'px';
            playerDiv.style.top = (y - 25) + 'px';
        }
        
        showMessage(`已传送到 (${x}, ${y})！`);
    } else if (cmd === '/unlockmap') {
        if (parts.length < 2) {
            showMessage('用法: /unlockmap [地图名]');
            showMessage('可用地图: surface, underground');
            return;
        }
        
        const mapName = parts[1].toLowerCase();
        if (mapName === 'surface' || mapName === 'underground') {
            if (!gameState.unlockedMaps.includes(mapName)) {
                gameState.unlockedMaps.push(mapName);
                showMessage(`${mapName === 'surface' ? '地面世界' : '地下矿洞'}已解锁！`);
            } else {
                showMessage(`${mapName === 'surface' ? '地面世界' : '地下矿洞'}已经解锁！`);
            }
        } else {
            showMessage(`未知地图: ${mapName}`);
            showMessage('可用地图: surface, underground');
        }
    } else if (cmd === '/refreshtimes') {
        if (parts.length < 2) {
            showMessage('用法: /refreshtimes [地图名]');
            showMessage('可用地图: surface, underground');
            return;
        }
        
        const mapName = parts[1].toLowerCase();
        if (mapName === 'surface' || mapName === 'underground') {
            const count = gameState.refreshCounts[mapName] || 0;
            showMessage(`${mapName === 'surface' ? '地面世界' : '地下矿洞'} 刷新次数: ${count}`);
        } else {
            showMessage(`未知地图: ${mapName}`);
            showMessage('可用地图: surface, underground');
        }
    } else if (cmd === '/map') {
        if (parts.length < 2) {
            showMessage('用法: /map [地图名]');
            showMessage('可用地图: surface, underground');
            return;
        }
        
        const mapName = parts[1].toLowerCase();
        if (mapName === 'surface' || mapName === 'underground') {
            if (gameState.currentMap === mapName) {
                showMessage(`已经在${mapName === 'surface' ? '地面世界' : '地下矿洞'}！`);
                return;
            }
            
            saveCurrentMapState();
            
            if (!gameState.unlockedMaps.includes(mapName)) {
                gameState.unlockedMaps.push(mapName);
            }
            
            if (mapName === 'surface') {
                loadSurfaceMap();
                showMessage('已切换到地面世界！');
            } else if (mapName === 'underground') {
                const success = loadUndergroundMap();
                if (success) {
                    showMessage('已切换到地下矿洞！');
                }
            }
        } else {
            showMessage(`未知地图: ${mapName}`);
            showMessage('可用地图: surface, underground');
        }
    } else if (cmd === '/help') {
        const helpText = `
可用指令:
/give [物品名] [数量] - 给予物品
/health [数量] - 恢复生命值
/fuel [数量] - 增加熔炉燃料
/clear - 清空物品
/tp x,y - 瞬移到指定位置
/unlockmap [地图名] - 解锁地图(surface/underground)
/map [地图名] - 直接切换地图(surface/underground)
/refreshtimes [地图名] - 查询地图刷新次数
/help - 显示帮助
        `.trim();
        showMessage(helpText);
    } else {
        showMessage(`未知指令: ${cmd}`);
    }
}

document.addEventListener('DOMContentLoaded', () => {
    initGame();
});